<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'bookkeeper') {
    header("Location: login.php");
    exit();
}

$page_title = "Bookkeeper Dashboard";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Bookkeeper';

// Get financial metrics
$result = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM invoices WHERE status = 'pending' OR status = 'overdue'");
$outstanding_total = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM invoices WHERE status = 'paid' AND MONTH(paid_date) = MONTH(CURDATE()) AND YEAR(paid_date) = YEAR(CURDATE())");
$monthly_collection = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM invoices WHERE status = 'overdue'");
$overdue_count = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'client' AND is_active = 1");
$total_clients = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM invoices WHERE status = 'paid'");
$total_paid_invoices = $result->fetch_assoc()['total'];

// Monthly earnings for chart
$monthly_earnings = [];
for($i=1; $i<=12; $i++) {
    $monthly_earnings[$i] = 0;
}
$result = $conn->query("SELECT MONTH(paid_date) as month, COALESCE(SUM(amount), 0) as total 
                        FROM invoices 
                        WHERE status = 'paid' AND YEAR(paid_date) = YEAR(CURDATE()) 
                        GROUP BY MONTH(paid_date)");
while($row = $result->fetch_assoc()) {
    $monthly_earnings[$row['month']] = $row['total'];
}

// Get top clients by billing
$top_clients = $conn->query("SELECT u.full_name, COALESCE(SUM(i.amount), 0) as total_billed 
                             FROM invoices i 
                             JOIN users u ON i.client_id = u.id 
                             WHERE i.status = 'paid' 
                             GROUP BY i.client_id 
                             ORDER BY total_billed DESC LIMIT 5");

// Get recent invoices
$recent_invoices = $conn->query("SELECT i.*, u.full_name as client_name, c.case_number 
                                 FROM invoices i 
                                 JOIN users u ON i.client_id = u.id 
                                 LEFT JOIN cases c ON i.case_id = c.id 
                                 ORDER BY i.created_at DESC LIMIT 10");

// Get overdue invoices
$overdue_invoices = $conn->query("SELECT i.*, u.full_name as client_name, u.email as client_email, c.case_number 
                                  FROM invoices i 
                                  JOIN users u ON i.client_id = u.id 
                                  LEFT JOIN cases c ON i.case_id = c.id 
                                  WHERE i.status = 'overdue' 
                                  ORDER BY i.due_date ASC");

// Handle invoice creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_invoice'])) {
    $client_id = $_POST['client_id'];
    $case_id = $_POST['case_id'] ?: null;
    $amount = $_POST['amount'];
    $due_date = $_POST['due_date'];
    $description = $_POST['description'];
    
    $invoice_number = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
    
    $stmt = $conn->prepare("INSERT INTO invoices (client_id, case_id, invoice_number, amount, due_date, description, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("iissss", $client_id, $case_id, $invoice_number, $amount, $due_date, $description);
    
    if ($stmt->execute()) {
        $success = "Invoice created successfully! Invoice #: " . $invoice_number;
    } else {
        $error = "Error creating invoice: " . $conn->error;
    }
}

// Handle payment recording
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['record_payment'])) {
    $invoice_id = $_POST['invoice_id'];
    $payment_amount = $_POST['payment_amount'];
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];
    
    $inv = $conn->query("SELECT amount FROM invoices WHERE id = $invoice_id")->fetch_assoc();
    $remaining = $inv['amount'] - $payment_amount;
    $status = ($remaining <= 0) ? 'paid' : 'partial';
    
    $stmt = $conn->prepare("UPDATE invoices SET status = ?, paid_amount = paid_amount + ?, paid_date = NOW(), payment_method = ?, transaction_id = ? WHERE id = ?");
    $stmt->bind_param("sdssi", $status, $payment_amount, $payment_method, $transaction_id, $invoice_id);
    
    if ($stmt->execute()) {
        $success = "Payment recorded successfully!";
    } else {
        $error = "Error recording payment: " . $conn->error;
    }
}

// Handle invoice reminder
if (isset($_GET['reminder'])) {
    $invoice_id = $_GET['reminder'];
    $invoice = $conn->query("SELECT i.*, u.email, u.full_name FROM invoices i JOIN users u ON i.client_id = u.id WHERE i.id = $invoice_id")->fetch_assoc();
    $reminder_sent = "Reminder sent to " . $invoice['full_name'];
}

// Handle delete invoice
if (isset($_GET['delete'])) {
    $invoice_id = $_GET['delete'];
    $conn->query("DELETE FROM invoices WHERE id = $invoice_id");
    $success = "Invoice deleted successfully!";
}

// Get all clients for dropdown
$clients = $conn->query("SELECT id, full_name, email FROM users WHERE role = 'client' AND is_active = 1 ORDER BY full_name");
$cases = $conn->query("SELECT id, case_number, title FROM cases WHERE status = 'active' ORDER BY case_number");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Bookkeeper Dashboard | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
            --dark: #2D0A10;
            --accent: #8B2635;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: var(--secondary);
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: var(--secondary) !important;
        }

        /* Dashboard Container */
        .dashboard-container {
            background: var(--light);
            min-height: 100vh;
            margin-top: 70px;
        }

        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            min-height: calc(100vh - 70px);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 70px;
            left: 0;
            width: 250px;
            z-index: 100;
        }

        .sidebar .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            margin-bottom: 10px;
        }

        .sidebar .sidebar-header .logo-icon {
            width: 50px;
            height: 50px;
            background: var(--secondary);
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        .sidebar .sidebar-header .logo-icon i {
            color: var(--primary-dark);
            font-size: 1.5rem;
        }

        .sidebar .sidebar-header h6 {
            color: white;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar .sidebar-header small {
            color: rgba(255,255,255,0.7);
            font-size: 12px;
        }

        .sidebar .nav-link {
            color: rgba(255,255,255,0.85) !important;
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary) !important;
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark) !important;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .sidebar hr {
            border-color: rgba(212, 175, 55, 0.2);
            margin: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 20px 30px;
        }

        /* Page Header */
        .page-header {
            margin-bottom: 25px;
        }

        .page-header h1 {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 28px;
        }

        .page-header h1 i {
            color: var(--secondary);
            margin-right: 10px;
        }

        .page-header p {
            color: #6c757d;
            margin-bottom: 0;
        }

        /* Stat Cards */
        .stat-card {
            border-radius: 20px;
            border: none;
            overflow: hidden;
            transition: all 0.3s;
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .stat-card .card-body {
            padding: 20px;
            position: relative;
        }

        .stat-card h3 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 10px;
            opacity: 0.9;
        }

        .stat-card h2 {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 5px;
        }

        .stat-card .stat-icon {
            position: absolute;
            right: 20px;
            bottom: 20px;
            font-size: 2.5rem;
            opacity: 0.15;
        }

        .card-outstanding {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
        }

        .card-collection {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
        }

        .card-overdue {
            background: linear-gradient(135deg, #C72A2A, #8B2635);
            color: white;
        }

        .card-clients {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: white;
        }

        /* Section Cards */
        .section-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            overflow: hidden;
        }

        .section-card .card-header {
            background: white;
            border-bottom: 2px solid rgba(212, 175, 55, 0.2);
            padding: 15px 20px;
        }

        .section-card .card-header h5 {
            color: var(--primary-dark);
            font-weight: 700;
            margin: 0;
        }

        .section-card .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .section-card .card-body {
            padding: 20px;
        }

        /* Form Controls */
        .form-label {
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 8px;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        /* Buttons */
        .btn-gold {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark);
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        /* Table Styles */
        .data-table {
            width: 100%;
        }

        .data-table thead th {
            background: var(--primary-dark);
            color: white;
            font-weight: 600;
            padding: 12px 15px;
            border: none;
        }

        .data-table thead th:first-child {
            border-radius: 12px 0 0 0;
        }

        .data-table thead th:last-child {
            border-radius: 0 12px 0 0;
        }

        .data-table tbody tr {
            border-bottom: 1px solid rgba(212, 175, 55, 0.1);
            transition: all 0.2s;
        }

        .data-table tbody tr:hover {
            background: rgba(212, 175, 55, 0.05);
        }

        .data-table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            color: #4a5568;
        }

        /* Badges */
        .badge-paid {
            background: #10b981;
            color: white;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
        }

        .badge-pending {
            background: #f59e0b;
            color: white;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
        }

        .badge-overdue {
            background: #C72A2A;
            color: white;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            animation: pulse 2s infinite;
        }

        .badge-partial {
            background: #0ea5e9;
            color: white;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        /* Top Clients List */
        .client-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .client-list li {
            padding: 12px 0;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .client-list li:last-child {
            border-bottom: none;
        }

        .rank-badge {
            width: 28px;
            height: 28px;
            background: var(--secondary);
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: var(--primary-dark);
            margin-right: 10px;
        }

        /* Modal */
        .modal-header-custom {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .modal-header-custom .btn-close {
            background: white;
            opacity: 1;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
                position: fixed;
            }
            
            .sidebar.show {
                left: 0;
            }
            
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .stat-card h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="dashboard-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="sidebar-header">
                    <div class="logo-icon">
                        <i class="fas fa-calculator"></i>
                    </div>
                    <h6>Bookkeeper Portal</h6>
                    <small><?php echo htmlspecialchars($user_name); ?></small>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="bookkeeper_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#invoices">
                            <i class="fas fa-file-invoice"></i> Invoices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#create-invoice">
                            <i class="fas fa-plus-circle"></i> Create Invoice
                        </a>
                    </li>
                  
                  
                </ul>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h1><i class="fas fa-chart-line"></i> Financial Dashboard</h1>
                    <p>Track invoices, payments, and financial performance</p>
                </div>

                <!-- Alert Messages -->
                <?php if(isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" style="background: #d4edda; border-left: 4px solid #10b981; border-radius: 12px;">
                        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" style="background: #f8d7da; border-left: 4px solid #C72A2A; border-radius: 12px;">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Stats Row -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-outstanding">
                            <div class="card-body">
                                <h3><i class="fas fa-rupee-sign me-1"></i> Outstanding</h3>
                                <h2>₹<?php echo number_format($outstanding_total, 2); ?></h2>
                                <small>Pending + Overdue</small>
                                <i class="fas fa-rupee-sign stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-collection">
                            <div class="card-body">
                                <h3><i class="fas fa-calendar-alt me-1"></i> This Month</h3>
                                <h2>₹<?php echo number_format($monthly_collection, 2); ?></h2>
                                <small>Total collected</small>
                                <i class="fas fa-chart-line stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-overdue">
                            <div class="card-body">
                                <h3><i class="fas fa-exclamation-triangle me-1"></i> Overdue</h3>
                                <h2><?php echo $overdue_count; ?></h2>
                                <small>Requires attention</small>
                                <i class="fas fa-exclamation-triangle stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-clients">
                            <div class="card-body">
                                <h3><i class="fas fa-users me-1"></i> Active Clients</h3>
                                <h2><?php echo $total_clients; ?></h2>
                                <small>Total clients</small>
                                <i class="fas fa-users stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="row mb-4">
                    <div class="col-lg-8">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-line"></i> Monthly Earnings <?php echo date('Y'); ?></h5>
                            </div>
                            <div class="card-body">
                                <canvas id="earningsChart" height="250"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-trophy"></i> Top Paying Clients</h5>
                            </div>
                            <div class="card-body">
                                <?php if($top_clients && $top_clients->num_rows > 0): ?>
                                    <ul class="client-list">
                                        <?php 
                                        $rank = 1;
                                        while($client = $top_clients->fetch_assoc()): 
                                        ?>
                                            <li>
                                                <div>
                                                    <span class="rank-badge"><?php echo $rank; ?></span>
                                                    <strong><?php echo htmlspecialchars(substr($client['full_name'], 0, 20)); ?></strong>
                                                </div>
                                                <span style="color: var(--secondary); font-weight: 700;">
                                                    ₹<?php echo number_format($client['total_billed'], 2); ?>
                                                </span>
                                            </li>
                                        <?php 
                                            $rank++;
                                        endwhile; 
                                        ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted text-center py-3">No payment data available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Create Invoice Section -->
                <div class="section-card" id="create-invoice">
                    <div class="card-header">
                        <h5><i class="fas fa-plus-circle"></i> Create New Invoice</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Select Client *</label>
                                <select class="form-select" name="client_id" required>
                                    <option value="">Choose client...</option>
                                    <?php while($client = $clients->fetch_assoc()): ?>
                                        <option value="<?php echo $client['id']; ?>">
                                            <?php echo htmlspecialchars($client['full_name']); ?> (<?php echo htmlspecialchars($client['email']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Related Case</label>
                                <select class="form-select" name="case_id">
                                    <option value="">No case association</option>
                                    <?php 
                                    $cases->data_seek(0);
                                    while($case = $cases->fetch_assoc()): 
                                    ?>
                                        <option value="<?php echo $case['id']; ?>">
                                            <?php echo $case['case_number']; ?> - <?php echo substr($case['title'], 0, 30); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Amount (₹) *</label>
                                <input type="number" step="100" class="form-control" name="amount" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Due Date *</label>
                                <input type="date" class="form-control" name="due_date" min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="2" placeholder="Detailed description of services rendered..."></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="create_invoice" class="btn btn-gold">
                                    <i class="fas fa-file-invoice me-2"></i> Generate Invoice
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Overdue Invoices -->
                <?php if($overdue_invoices && $overdue_invoices->num_rows > 0): ?>
                    <div class="section-card" id="overdue">
                        <div class="card-header" style="border-bottom-color: #C72A2A;">
                            <h5><i class="fas fa-exclamation-triangle" style="color: #C72A2A;"></i> Overdue Invoices (<?php echo $overdue_invoices->num_rows; ?>)</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Invoice #</th>
                                            <th>Client</th>
                                            <th>Case</th>
                                            <th>Amount</th>
                                            <th>Due Date</th>
                                            <th>Days</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($invoice = $overdue_invoices->fetch_assoc()): 
                                            $days_overdue = (new DateTime($invoice['due_date']))->diff(new DateTime())->days;
                                        ?>
                                            <tr>
                                                <td><strong><?php echo $invoice['invoice_number']; ?></strong></td>
                                                <td><?php echo htmlspecialchars($invoice['client_name']); ?></td>
                                                <td><?php echo $invoice['case_number'] ?? 'N/A'; ?></td>
                                                <td>₹<?php echo number_format($invoice['amount'], 2); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($invoice['due_date'])); ?></td>
                                                <td><span class="badge-overdue"><?php echo $days_overdue; ?> days</span></td>
                                                <td>
                                                    <button class="btn btn-sm" style="background: #f59e0b; color: white; border: none; border-radius: 8px; padding: 5px 10px;" onclick="sendReminder(<?php echo $invoice['id']; ?>)">
                                                        <i class="fas fa-bell"></i>
                                                    </button>
                                                    <button class="btn btn-sm" style="background: #10b981; color: white; border: none; border-radius: 8px; padding: 5px 10px;" onclick="recordPayment(<?php echo $invoice['id']; ?>, <?php echo $invoice['amount']; ?>)">
                                                        <i class="fas fa-money-bill"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- All Invoices -->
                <div class="section-card" id="invoices">
                    <div class="card-header">
                        <h5><i class="fas fa-list"></i> All Invoices</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="invoicesTable" class="data-table table">
                                <thead>
                                    <tr>
                                        <th>Invoice #</th>
                                        <th>Client</th>
                                        <th>Case</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Status</th>
                                        <th>Due Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $all_invoices = $conn->query("SELECT i.*, u.full_name as client_name, c.case_number 
                                                                  FROM invoices i 
                                                                  JOIN users u ON i.client_id = u.id 
                                                                  LEFT JOIN cases c ON i.case_id = c.id 
                                                                  ORDER BY i.created_at DESC");
                                    if($all_invoices && $all_invoices->num_rows > 0):
                                    while($invoice = $all_invoices->fetch_assoc()): 
                                    ?>
                                        <tr>
                                            <td><strong><?php echo $invoice['invoice_number']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($invoice['client_name']); ?></td>
                                            <td><?php echo $invoice['case_number'] ?? '—'; ?></td>
                                            <td>₹<?php echo number_format($invoice['amount'], 2); ?></td>
                                            <td>₹<?php echo number_format($invoice['paid_amount'] ?? 0, 2); ?></td>
                                            <td>
                                                <?php
                                                $badge_class = 'badge-' . $invoice['status'];
                                                ?>
                                                <span class="<?php echo $badge_class; ?>">
                                                    <?php echo ucfirst($invoice['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($invoice['due_date'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm" style="background: var(--secondary); color: var(--primary-dark); border-radius: 8px; padding: 5px 10px; margin: 2px;" onclick="viewInvoice(<?php echo $invoice['id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if($invoice['status'] != 'paid'): ?>
                                                    <button class="btn btn-sm" style="background: #10b981; color: white; border-radius: 8px; padding: 5px 10px; margin: 2px;" onclick="recordPayment(<?php echo $invoice['id']; ?>, <?php echo $invoice['amount']; ?>)">
                                                        <i class="fas fa-money-bill"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn btn-sm" style="background: #f59e0b; color: white; border-radius: 8px; padding: 5px 10px; margin: 2px;" onclick="sendReminder(<?php echo $invoice['id']; ?>)">
                                                    <i class="fas fa-bell"></i>
                                                </button>
                                                <a href="?delete=<?php echo $invoice['id']; ?>" class="btn btn-sm" style="background: #C72A2A; color: white; border-radius: 8px; padding: 5px 10px; margin: 2px;" onclick="return confirm('Delete this invoice?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title"><i class="fas fa-money-bill"></i> Record Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="invoice_id" id="payment_invoice_id">
                    <div class="mb-3">
                        <label class="form-label">Invoice Amount</label>
                        <input type="text" class="form-control" id="invoice_amount" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Amount *</label>
                        <input type="number" step="100" class="form-control" name="payment_amount" id="payment_amount" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Method *</label>
                        <select class="form-select" name="payment_method" required>
                            <option value="">Select method...</option>
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="check">Check</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Transaction ID</label>
                        <input type="text" class="form-control" name="transaction_id" placeholder="Check #, Transaction ID, etc.">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="record_payment" class="btn btn-gold">Record Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Invoice Modal -->
<div class="modal fade" id="invoiceModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title"><i class="fas fa-file-invoice"></i> Invoice Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="invoiceDetails">
                <div class="text-center py-4">
                    <div class="spinner-border" style="color: #D4AF37;" role="status"></div>
                    <p class="mt-2">Loading invoice details...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-gold" onclick="window.print()">
                    <i class="fas fa-print"></i> Print
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
    $(document).ready(function() {
        if ($('#invoicesTable tbody tr').length > 0) {
            $('#invoicesTable').DataTable({
                order: [[6, 'desc']],
                pageLength: 15,
                language: {
                    search: "Search invoices:",
                    lengthMenu: "Show _MENU_ invoices",
                    info: "Showing _START_ to _END_ of _TOTAL_ invoices",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [
                    { orderable: false, targets: 7 }
                ]
            });
        }
    });
    
    const ctx = document.getElementById('earningsChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Collections (₹)',
                data: [
                    <?php 
                    for($i=1; $i<=12; $i++) {
                        echo isset($monthly_earnings[$i]) ? $monthly_earnings[$i] : 0;
                        echo $i < 12 ? ',' : '';
                    }
                    ?>
                ],
                backgroundColor: 'rgba(212, 175, 55, 0.7)',
                borderColor: '#D4AF37',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top', labels: { color: '#4A0E17' } },
                tooltip: { callbacks: { label: function(context) { return '₹' + context.raw.toLocaleString(); } } }
            },
            scales: {
                y: { beginAtZero: true, ticks: { callback: function(value) { return '₹' + value.toLocaleString(); }, color: '#4A0E17' }, grid: { color: '#e2e8f0' } },
                x: { ticks: { color: '#4A0E17' } }
            }
        }
    });
    
    function recordPayment(invoiceId, amount) {
        document.getElementById('payment_invoice_id').value = invoiceId;
        document.getElementById('invoice_amount').value = '₹' + amount.toLocaleString();
        document.getElementById('payment_amount').value = amount;
        new bootstrap.Modal(document.getElementById('paymentModal')).show();
    }
    
    function viewInvoice(invoiceId) {
        $.ajax({
            url: 'get_invoice.php',
            method: 'GET',
            data: { id: invoiceId },
            success: function(data) {
                document.getElementById('invoiceDetails').innerHTML = data;
                new bootstrap.Modal(document.getElementById('invoiceModal')).show();
            },
            error: function() {
                document.getElementById('invoiceDetails').innerHTML = '<div class="alert alert-danger">Error loading invoice details. Please try again.</div>';
            }
        });
    }
    
    function sendReminder(invoiceId) {
        if(confirm('Send payment reminder to client?')) {
            window.location.href = '?reminder=' + invoiceId;
        }
    }
    
    // Mobile sidebar toggle
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('overlay');
    
    // Create overlay if it doesn't exist
    let overlayEl = document.getElementById('overlay');
    if (!overlayEl) {
        overlayEl = document.createElement('div');
        overlayEl.id = 'overlay';
        overlayEl.style.position = 'fixed';
        overlayEl.style.top = '0';
        overlayEl.style.left = '0';
        overlayEl.style.width = '100%';
        overlayEl.style.height = '100%';
        overlayEl.style.background = 'rgba(0,0,0,0.5)';
        overlayEl.style.zIndex = '99';
        overlayEl.style.display = 'none';
        document.body.appendChild(overlayEl);
    }
    
    // You'll need to add a hamburger button in your header for mobile
    // For now, you can add a simple button
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-brand');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlayEl.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlayEl) {
        overlayEl.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlayEl.style.display = 'none';
        });
    }
</script>

</body>
</html>