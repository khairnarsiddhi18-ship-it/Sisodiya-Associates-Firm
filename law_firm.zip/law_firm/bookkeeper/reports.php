<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'bookkeeper') {
    header("Location: login.php");
    exit();
}

$page_title = "Financial Reports";
$user_id = $_SESSION['user_id'];

// Get date range from filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');
$report_type = isset($_GET['report_type']) ? $_GET['report_type'] : 'summary';

// Summary Statistics
$result = $conn->query("SELECT 
                         COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as total_paid,
                         COALESCE(SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0) as total_pending,
                         COALESCE(SUM(CASE WHEN status = 'overdue' THEN amount ELSE 0 END), 0) as total_overdue,
                         COALESCE(SUM(CASE WHEN status = 'partial' THEN amount ELSE 0 END), 0) as total_partial,
                         COUNT(*) as total_invoices,
                         COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_invoices,
                         COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_invoices,
                         COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_invoices
                         FROM invoices 
                         WHERE created_at BETWEEN '$start_date' AND '$end_date'");
$summary = $result->fetch_assoc();

// Monthly breakdown for selected period
$monthly_breakdown = $conn->query("SELECT 
                                    DATE_FORMAT(created_at, '%M %Y') as month,
                                    DATE_FORMAT(created_at, '%Y-%m') as month_key,
                                    COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as paid,
                                    COALESCE(SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0) as pending,
                                    COALESCE(SUM(CASE WHEN status = 'overdue' THEN amount ELSE 0 END), 0) as overdue
                                   FROM invoices 
                                   WHERE created_at BETWEEN '$start_date' AND '$end_date'
                                   GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                                   ORDER BY created_at ASC");

// Payment method breakdown
$payment_methods = $conn->query("SELECT 
                                  payment_method,
                                  COUNT(*) as count,
                                  COALESCE(SUM(amount), 0) as total
                                 FROM invoices 
                                 WHERE status = 'paid' AND payment_method IS NOT NULL
                                 GROUP BY payment_method
                                 ORDER BY total DESC");

// Top clients
$top_clients = $conn->query("SELECT 
                              u.full_name,
                              COUNT(i.id) as invoice_count,
                              COALESCE(SUM(i.amount), 0) as total_billed,
                              COALESCE(SUM(CASE WHEN i.status = 'paid' THEN i.amount ELSE 0 END), 0) as total_paid
                             FROM users u
                             LEFT JOIN invoices i ON u.id = i.client_id
                             WHERE u.role = 'client'
                             GROUP BY u.id
                             ORDER BY total_billed DESC
                             LIMIT 10");

// Recent transactions
$recent_transactions = $conn->query("SELECT i.*, u.full_name as client_name, c.case_number 
                                     FROM invoices i 
                                     JOIN users u ON i.client_id = u.id 
                                     LEFT JOIN cases c ON i.case_id = c.id 
                                     WHERE i.created_at BETWEEN '$start_date' AND '$end_date'
                                     ORDER BY i.created_at DESC 
                                     LIMIT 50");

// Yearly comparison
$yearly_comparison = $conn->query("SELECT 
                                    YEAR(created_at) as year,
                                    COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as total_revenue
                                   FROM invoices 
                                   WHERE status = 'paid'
                                   GROUP BY YEAR(created_at)
                                   ORDER BY year DESC");

require_once '../includes/header.php';
?>

<style>
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
        --dark: #2D0A10;
    }

    .dashboard-container {
        background: var(--light);
        min-height: 100vh;
        margin-top: 70px;
    }

    /* Sidebar */
    .sidebar {
        background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
        min-height: calc(100vh - 70px);
        box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    }

    .sidebar .sidebar-header {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid rgba(212, 175, 55, 0.2);
    }

    .sidebar .sidebar-header .logo-icon {
        width: 50px;
        height: 50px;
        background: var(--secondary);
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 10px;
    }

    .sidebar .sidebar-header .logo-icon i {
        color: var(--primary-dark);
        font-size: 1.5rem;
    }

    .sidebar .sidebar-header h6 {
        color: white;
        font-weight: 600;
        margin-bottom: 5px;
    }

    .sidebar .nav-link {
        color: rgba(255,255,255,0.85) !important;
        padding: 12px 20px;
        margin: 5px 10px;
        border-radius: 12px;
        transition: all 0.3s;
        font-weight: 500;
    }

    .sidebar .nav-link:hover {
        background: rgba(212, 175, 55, 0.15);
        color: var(--secondary) !important;
        transform: translateX(5px);
    }

    .sidebar .nav-link.active {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        color: var(--primary-dark) !important;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .sidebar .nav-link i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }

    /* Main Content */
    .main-content {
        padding: 20px 30px;
    }

    /* Page Header */
    .page-header {
        margin-bottom: 25px;
    }

    .page-header h1 {
        color: var(--primary-dark);
        font-weight: 700;
        font-size: 28px;
    }

    .page-header h1 i {
        color: var(--secondary);
        margin-right: 10px;
    }

    /* Filter Bar */
    .filter-bar {
        background: white;
        border-radius: 20px;
        padding: 20px;
        margin-bottom: 25px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }

    /* Stat Cards */
    .stat-card {
        border-radius: 20px;
        border: none;
        overflow: hidden;
        transition: all 0.3s;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    .stat-card .card-body {
        padding: 20px;
    }

    .stat-card h3 {
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 10px;
        opacity: 0.9;
    }

    .stat-card h2 {
        font-size: 28px;
        font-weight: 800;
        margin-bottom: 5px;
    }

    .card-primary-gradient {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
    }

    .card-success-gradient {
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
    }

    .card-warning-gradient {
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
    }

    .card-danger-gradient {
        background: linear-gradient(135deg, #C72A2A, #8B2635);
        color: white;
    }

    .card-info-gradient {
        background: linear-gradient(135deg, #0ea5e9, #0284c7);
        color: white;
    }

    /* Section Cards */
    .section-card {
        background: white;
        border-radius: 20px;
        border: none;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        margin-bottom: 25px;
        overflow: hidden;
    }

    .section-card .card-header {
        background: white;
        border-bottom: 2px solid rgba(212, 175, 55, 0.2);
        padding: 15px 20px;
    }

    .section-card .card-header h5 {
        color: var(--primary-dark);
        font-weight: 700;
        margin: 0;
    }

    .section-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .section-card .card-body {
        padding: 20px;
    }

    /* Table Styles */
    .data-table {
        width: 100%;
    }

    .data-table thead th {
        background: var(--primary-dark);
        color: white;
        font-weight: 600;
        padding: 12px 15px;
        border: none;
    }

    .data-table tbody tr {
        border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    }

    .data-table tbody tr:hover {
        background: rgba(212, 175, 55, 0.05);
    }

    .data-table tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }

    /* Badges */
    .badge-paid { background: #10b981; color: white; padding: 5px 12px; border-radius: 50px; font-size: 12px; }
    .badge-pending { background: #f59e0b; color: white; padding: 5px 12px; border-radius: 50px; font-size: 12px; }
    .badge-overdue { background: #C72A2A; color: white; padding: 5px 12px; border-radius: 50px; font-size: 12px; }
    .badge-partial { background: #0ea5e9; color: white; padding: 5px 12px; border-radius: 50px; font-size: 12px; }

    /* Buttons */
    .btn-gold {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        color: var(--primary-dark);
        font-weight: 600;
        padding: 8px 20px;
        border-radius: 10px;
        transition: all 0.3s;
    }

    .btn-gold:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .sidebar {
            position: fixed;
            left: -280px;
            transition: left 0.3s;
            z-index: 1000;
            top: 70px;
        }
        
        .sidebar.show {
            left: 0;
        }
        
        .main-content {
            padding: 15px;
        }
    }
</style>

<div class="dashboard-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="sidebar-header">
                    <div class="logo-icon">
                        <i class="fas fa-calculator"></i>
                    </div>
                    <h6>Bookkeeper Portal</h6>
                    <small><?php echo htmlspecialchars($_SESSION['user_name']); ?></small>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="bookkeeper_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookkeeper_dashboard.php#invoices">
                            <i class="fas fa-file-invoice"></i> Invoices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookkeeper_dashboard.php#create-invoice">
                            <i class="fas fa-plus-circle"></i> Create Invoice
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">
                            <i class="fas fa-chart-line"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <hr>
                        <a class="nav-link" href="../profile.php">
                            <i class="fas fa-user-circle"></i> Profile
                        </a>
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h1><i class="fas fa-chart-line"></i> Financial Reports</h1>
                    <p>Generate and view financial reports and analytics</p>
                </div>

                <!-- Filter Bar -->
                <div class="filter-bar">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label">Start Date</label>
                            <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">End Date</label>
                            <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Report Type</label>
                            <select class="form-select" name="report_type">
                                <option value="summary" <?php echo $report_type == 'summary' ? 'selected' : ''; ?>>Summary Report</option>
                                <option value="detailed" <?php echo $report_type == 'detailed' ? 'selected' : ''; ?>>Detailed Report</option>
                                <option value="clients" <?php echo $report_type == 'clients' ? 'selected' : ''; ?>>Client Report</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-gold w-100">
                                <i class="fas fa-filter me-2"></i> Generate Report
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Summary Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-primary-gradient">
                            <div class="card-body">
                                <h3><i class="fas fa-dollar-sign me-1"></i> Total Revenue</h3>
                                <h2>$<?php echo number_format($summary['total_paid'], 2); ?></h2>
                                <small>Paid invoices</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-warning-gradient">
                            <div class="card-body">
                                <h3><i class="fas fa-clock me-1"></i> Pending</h3>
                                <h2>$<?php echo number_format($summary['total_pending'], 2); ?></h2>
                                <small>Awaiting payment</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-danger-gradient">
                            <div class="card-body">
                                <h3><i class="fas fa-exclamation-triangle me-1"></i> Overdue</h3>
                                <h2>$<?php echo number_format($summary['total_overdue'], 2); ?></h2>
                                <small>Past due invoices</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card card-info-gradient">
                            <div class="card-body">
                                <h3><i class="fas fa-chart-line me-1"></i> Collection Rate</h3>
                                <h2>
                                    <?php 
                                    $total_billed = $summary['total_paid'] + $summary['total_pending'] + $summary['total_overdue'];
                                    $collection_rate = $total_billed > 0 ? ($summary['total_paid'] / $total_billed) * 100 : 0;
                                    echo number_format($collection_rate, 1); ?>%
                                </h2>
                                <small>Of total billed</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Invoice Statistics -->
                <div class="row mb-4">
                    <div class="col-md-6 mb-3">
                        <div class="stat-card" style="background: white; color: var(--primary-dark);">
                            <div class="card-body">
                                <h3><i class="fas fa-file-invoice"></i> Invoice Statistics</h3>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <p class="mb-1">Total Invoices</p>
                                        <h4><?php echo $summary['total_invoices']; ?></h4>
                                    </div>
                                    <div class="col-6">
                                        <p class="mb-1">Paid Invoices</p>
                                        <h4><?php echo $summary['paid_invoices']; ?></h4>
                                    </div>
                                    <div class="col-6">
                                        <p class="mb-1">Pending Invoices</p>
                                        <h4><?php echo $summary['pending_invoices']; ?></h4>
                                    </div>
                                    <div class="col-6">
                                        <p class="mb-1">Overdue Invoices</p>
                                        <h4><?php echo $summary['overdue_invoices']; ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="stat-card" style="background: white; color: var(--primary-dark);">
                            <div class="card-body">
                                <h3><i class="fas fa-chart-pie"></i> Average Values</h3>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <p class="mb-1">Avg Invoice Value</p>
                                        <h4>$<?php echo $summary['total_invoices'] > 0 ? number_format(($summary['total_paid'] + $summary['total_pending'] + $summary['total_overdue']) / $summary['total_invoices'], 2) : '0.00'; ?></h4>
                                    </div>
                                    <div class="col-6">
                                        <p class="mb-1">Avg Payment Value</p>
                                        <h4>$<?php echo $summary['paid_invoices'] > 0 ? number_format($summary['total_paid'] / $summary['paid_invoices'], 2) : '0.00'; ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Monthly Breakdown Chart -->
                <div class="section-card">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-bar"></i> Monthly Financial Breakdown</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="monthlyChart" height="300"></canvas>
                    </div>
                </div>

                <!-- Payment Methods Breakdown -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-credit-card"></i> Payment Methods</h5>
                            </div>
                            <div class="card-body">
                                <?php if($payment_methods && $payment_methods->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Method</th>
                                                    <th>Transactions</th>
                                                    <th class="text-end">Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($method = $payment_methods->fetch_assoc()): ?>
                                                    <tr>
                                                        <td>
                                                            <i class="fas fa-<?php 
                                                                echo $method['payment_method'] == 'credit_card' ? 'credit-card' : 
                                                                    ($method['payment_method'] == 'cash' ? 'money-bill' : 
                                                                    ($method['payment_method'] == 'bank_transfer' ? 'university' : 
                                                                    ($method['payment_method'] == 'check' ? 'check' : 'wallet'))); 
                                                            ?> me-2"></i>
                                                            <?php echo ucfirst(str_replace('_', ' ', $method['payment_method'])); ?>
                                                        </td>
                                                        <td><?php echo $method['count']; ?>个</td>
                                                        <td class="text-end">$<?php echo number_format($method['total'], 2); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted text-center py-3">No payment method data available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-trophy"></i> Yearly Revenue Comparison</h5>
                            </div>
                            <div class="card-body">
                                <?php if($yearly_comparison && $yearly_comparison->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr><th>Year</th><th class="text-end">Total Revenue</th><th>Growth</th></tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $prev_year_revenue = 0;
                                                while($year = $yearly_comparison->fetch_assoc()): 
                                                    $growth = $prev_year_revenue > 0 ? (($year['total_revenue'] - $prev_year_revenue) / $prev_year_revenue) * 100 : 0;
                                                ?>
                                                    <tr>
                                                        <td><strong><?php echo $year['year']; ?></strong></td>
                                                        <td class="text-end">$<?php echo number_format($year['total_revenue'], 2); ?></td>
                                                        <td>
                                                            <?php if($growth > 0): ?>
                                                                <span class="text-success">+<?php echo number_format($growth, 1); ?>% ▲</span>
                                                            <?php elseif($growth < 0): ?>
                                                                <span class="text-danger"><?php echo number_format($growth, 1); ?>% ▼</span>
                                                            <?php else: ?>
                                                                <span class="text-muted">0%</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php 
                                                    $prev_year_revenue = $year['total_revenue'];
                                                endwhile; 
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted text-center py-3">No yearly data available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Top Clients Table -->
                <div class="section-card">
                    <div class="card-header">
                        <h5><i class="fas fa-users"></i> Top Paying Clients</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="data-table table">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Client Name</th>
                                        <th>Invoices</th>
                                        <th>Total Billed</th>
                                        <th>Total Paid</th>
                                        <th>Payment Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $rank = 1;
                                    if($top_clients && $top_clients->num_rows > 0):
                                    while($client = $top_clients->fetch_assoc()): 
                                        $payment_rate = $client['total_billed'] > 0 ? ($client['total_paid'] / $client['total_billed']) * 100 : 0;
                                    ?>
                                        <tr>
                                            <td>
                                                <span class="rank-badge" style="width: 28px; height: 28px; background: <?php echo $rank == 1 ? '#D4AF37' : ($rank == 2 ? '#C0C0C0' : '#CD7F32'); ?>; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-weight: 700;">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td><strong><?php echo htmlspecialchars($client['full_name']); ?></strong></td>
                                            <td><?php echo $client['invoice_count']; ?>个</td>
                                            <td>$<?php echo number_format($client['total_billed'], 2); ?></td>
                                            <td>$<?php echo number_format($client['total_paid'], 2); ?></td>
                                            <td>
                                                <div class="progress" style="height: 6px; width: 100px;">
                                                    <div class="progress-bar" style="width: <?php echo $payment_rate; ?>%; background: #10b981;"></div>
                                                </div>
                                                <small><?php echo number_format($payment_rate, 1); ?>%</small>
                                             </td>
                                         </tr>
                                    <?php 
                                        $rank++;
                                    endwhile; 
                                    endif;
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="section-card">
                    <div class="card-header">
                        <h5><i class="fas fa-history"></i> Recent Transactions (Last 50)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="data-table table">
                                <thead>
                                    <tr>
                                        <th>Invoice #</th>
                                        <th>Client</th>
                                        <th>Case</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Due Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($recent_transactions && $recent_transactions->num_rows > 0): ?>
                                        <?php while($trans = $recent_transactions->fetch_assoc()): ?>
                                            <tr>
                                                <td><strong><?php echo $trans['invoice_number']; ?></strong></td>
                                                <td><?php echo htmlspecialchars($trans['client_name']); ?></td>
                                                <td><?php echo $trans['case_number'] ?? '—'; ?></td>
                                                <td>$<?php echo number_format($trans['amount'], 2); ?></td>
                                                <td><span class="badge-<?php echo $trans['status']; ?>"><?php echo ucfirst($trans['status']); ?></span></td>
                                                <td><?php echo date('M d, Y', strtotime($trans['created_at'])); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($trans['due_date'])); ?></td>
                                             </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center">No transactions found</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
    // Monthly Breakdown Chart
    const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
    
    <?php
    $months = [];
    $paid_data = [];
    $pending_data = [];
    $overdue_data = [];
    
    while($row = $monthly_breakdown->fetch_assoc()) {
        $months[] = $row['month'];
        $paid_data[] = $row['paid'];
        $pending_data[] = $row['pending'];
        $overdue_data[] = $row['overdue'];
    }
    ?>
    
    new Chart(monthlyCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [
                {
                    label: 'Paid',
                    data: <?php echo json_encode($paid_data); ?>,
                    backgroundColor: 'rgba(16, 185, 129, 0.7)',
                    borderColor: '#10b981',
                    borderWidth: 1,
                    borderRadius: 8
                },
                {
                    label: 'Pending',
                    data: <?php echo json_encode($pending_data); ?>,
                    backgroundColor: 'rgba(245, 158, 11, 0.7)',
                    borderColor: '#f59e0b',
                    borderWidth: 1,
                    borderRadius: 8
                },
                {
                    label: 'Overdue',
                    data: <?php echo json_encode($overdue_data); ?>,
                    backgroundColor: 'rgba(199, 42, 42, 0.7)',
                    borderColor: '#C72A2A',
                    borderWidth: 1,
                    borderRadius: 8
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top', labels: { color: '#4A0E17' } },
                tooltip: { callbacks: { label: function(context) { return '$' + context.raw.toLocaleString(); } } }
            },
            scales: {
                y: { beginAtZero: true, ticks: { callback: function(value) { return '$' + value.toLocaleString(); }, color: '#4A0E17' }, grid: { color: '#e2e8f0' } },
                x: { ticks: { color: '#4A0E17' } }
            }
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>