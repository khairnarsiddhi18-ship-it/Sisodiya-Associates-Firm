<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get invoice ID from URL
$invoice_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$format = isset($_GET['format']) ? $_GET['format'] : 'html'; // html, pdf, print

if ($invoice_id <= 0) {
    die("Invalid invoice ID.");
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Fetch invoice details with case and client information
$query = "
    SELECT 
        i.*,
        c.case_number,
        c.title as case_title,
        c.description as case_description,
        cl.id as client_id,
        cl.full_name as client_name,
        cl.email as client_email,
        cl.phone as client_phone,
        cl.address as client_address,
        l.id as lawyer_id,
        l.full_name as lawyer_name,
        l.email as lawyer_email,
        l.phone as lawyer_phone
    FROM invoices i
    JOIN cases c ON i.case_id = c.id
    JOIN users cl ON c.client_id = cl.id
    LEFT JOIN users l ON c.assigned_lawyer_id = l.id
    WHERE i.id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $invoice_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Invoice not found.");
}

$invoice = $result->fetch_assoc();

// Check authorization: Client can view their own invoices, Lawyer/Paralegal/Admin can view all
if ($user_role == 'client') {
    if ($invoice['client_id'] != $user_id) {
        die("You are not authorized to view this invoice.");
    }
}

// Fetch payment transactions for this invoice
$payments_query = "
    SELECT * FROM payments 
    WHERE invoice_id = ? 
    ORDER BY payment_date DESC
";
$payments_stmt = $conn->prepare($payments_query);
$payments_stmt->bind_param("i", $invoice_id);
$payments_stmt->execute();
$payments_result = $payments_stmt->get_result();
$payments = [];
$total_paid = 0;
while ($payment = $payments_result->fetch_assoc()) {
    $payments[] = $payment;
    if ($payment['payment_status'] == 'completed') {
        $total_paid += $payment['amount'];
    }
}

$balance_due = $invoice['amount'] - $total_paid;
$invoice_status = $balance_due <= 0 ? 'Paid' : ($total_paid > 0 ? 'Partial' : 'Unpaid');

// Handle PDF download if requested
if ($format == 'pdf') {
    require_once('tcpdf/tcpdf.php'); // Make sure TCPDF is installed
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Law Firm Management System');
    $pdf->SetAuthor('Law Firm');
    $pdf->SetTitle('Invoice #' . $invoice['invoice_number']);
    $pdf->SetSubject('Invoice for Legal Services');
    
    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // Add a page
    $pdf->AddPage();
    
    // Set font
    $pdf->SetFont('helvetica', '', 10);
    
    // Generate HTML content for PDF
    $html = generateInvoiceHTML($invoice, $payments, $total_paid, $balance_due, $invoice_status);
    
    // Output PDF
    $pdf->writeHTML($html, true, false, true, false, '');
    
    // Close and output PDF document
    $pdf->Output('Invoice_' . $invoice['invoice_number'] . '.pdf', 'D');
    exit();
}

// For HTML/Print view
function generateInvoiceHTML($invoice, $payments, $total_paid, $balance_due, $invoice_status) {
    $html = '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Invoice #' . htmlspecialchars($invoice['invoice_number']) . '</title>
        <style>
            @media print {
                body {
                    margin: 0;
                    padding: 20px;
                }
                .no-print {
                    display: none;
                }
                .invoice-container {
                    box-shadow: none;
                    margin: 0;
                    padding: 0;
                }
                .page-break {
                    page-break-before: always;
                }
            }
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: "Segoe UI", Arial, sans-serif;
                background: #f5f5f5;
                padding: 40px 20px;
            }
            
            .invoice-container {
                max-width: 1100px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .invoice-header {
                background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
                color: white;
                padding: 40px;
                position: relative;
            }
            
            .invoice-header::before {
                content: "⚖️";
                position: absolute;
                right: 40px;
                bottom: 40px;
                font-size: 80px;
                opacity: 0.1;
            }
            
            .law-firm-name {
                font-size: 32px;
                font-weight: 800;
                margin-bottom: 10px;
            }
            
            .law-firm-tagline {
                font-size: 14px;
                opacity: 0.8;
            }
            
            .invoice-title {
                font-size: 48px;
                font-weight: 800;
                margin-top: 20px;
                letter-spacing: 2px;
            }
            
            .invoice-number {
                font-size: 18px;
                margin-top: 10px;
                opacity: 0.9;
            }
            
            .invoice-details {
                padding: 40px;
                border-bottom: 1px solid #e2e8f0;
            }
            
            .bill-to-section {
                margin-bottom: 30px;
            }
            
            .section-title {
                font-size: 18px;
                font-weight: 700;
                color: #4A0E17;
                margin-bottom: 15px;
                padding-bottom: 8px;
                border-bottom: 2px solid #D4AF37;
                display: inline-block;
            }
            
            .client-info {
                background: #FDF8F0;
                padding: 20px;
                border-radius: 12px;
                margin-top: 15px;
            }
            
            .client-info p {
                margin: 8px 0;
                color: #4a5568;
            }
            
            .client-info strong {
                color: #4A0E17;
                width: 120px;
                display: inline-block;
            }
            
            .info-grid {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 30px;
                margin-bottom: 30px;
            }
            
            .info-box {
                background: #FDF8F0;
                padding: 20px;
                border-radius: 12px;
                flex: 1;
                min-width: 200px;
            }
            
            .info-box p {
                margin: 8px 0;
                color: #4a5568;
            }
            
            .info-box strong {
                color: #4A0E17;
                display: inline-block;
                width: 100px;
            }
            
            .status-badge {
                display: inline-block;
                padding: 6px 16px;
                border-radius: 50px;
                font-weight: 700;
                font-size: 14px;
            }
            
            .status-paid { background: #d4edda; color: #155724; }
            .status-unpaid { background: #f8d7da; color: #721c24; }
            .status-partial { background: #fff3cd; color: #856404; }
            
            .invoice-table {
                width: 100%;
                border-collapse: collapse;
                margin: 30px 0;
            }
            
            .invoice-table th {
                background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
                color: white;
                padding: 15px;
                text-align: left;
                font-weight: 600;
            }
            
            .invoice-table td {
                padding: 15px;
                border-bottom: 1px solid #e2e8f0;
                color: #4a5568;
            }
            
            .invoice-table tr:hover {
                background: #FDF8F0;
            }
            
            .totals-section {
                background: #FDF8F0;
                padding: 20px;
                border-radius: 12px;
                margin-top: 20px;
            }
            
            .totals-table {
                width: 100%;
                max-width: 400px;
                margin-left: auto;
            }
            
            .totals-table td {
                padding: 10px;
            }
            
            .totals-table td:last-child {
                text-align: right;
                font-weight: 600;
            }
            
            .grand-total {
                font-size: 20px;
                font-weight: 800;
                color: #4A0E17;
                border-top: 2px solid #D4AF37;
                padding-top: 10px;
                margin-top: 10px;
            }
            
            .payments-section {
                margin-top: 30px;
                padding-top: 20px;
                border-top: 1px solid #e2e8f0;
            }
            
            .payment-history-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            
            .payment-history-table th {
                background: #e2e8f0;
                padding: 12px;
                text-align: left;
                color: #4A0E17;
            }
            
            .payment-history-table td {
                padding: 12px;
                border-bottom: 1px solid #e2e8f0;
            }
            
            .terms-section {
                margin-top: 40px;
                padding: 20px;
                background: #FDF8F0;
                border-radius: 12px;
                font-size: 12px;
                color: #6c757d;
            }
            
            .footer {
                background: #2d3748;
                color: white;
                padding: 30px;
                text-align: center;
            }
            
            .action-buttons {
                text-align: center;
                padding: 20px;
                background: #f5f5f5;
            }
            
            .btn {
                display: inline-block;
                padding: 12px 24px;
                margin: 0 10px;
                border: none;
                border-radius: 12px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 600;
                text-decoration: none;
                transition: all 0.3s;
            }
            
            .btn-primary {
                background: linear-gradient(135deg, #D4AF37, #F5D76E);
                color: #4A0E17;
            }
            
            .btn-secondary {
                background: #6B1A2A;
                color: white;
            }
            
            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            }
            
            @media (max-width: 768px) {
                .invoice-header {
                    padding: 20px;
                }
                .invoice-title {
                    font-size: 32px;
                }
                .info-grid {
                    flex-direction: column;
                }
                .invoice-table {
                    font-size: 12px;
                }
                .invoice-table th,
                .invoice-table td {
                    padding: 8px;
                }
            }
        </style>
    </head>
    <body>
        <div class="invoice-container">
            <div class="invoice-header">
                <div class="law-firm-name">LAW FIRM & ASSOCIATES</div>
                <div class="law-firm-tagline">Advocates & Legal Consultants</div>
                <div class="invoice-title">INVOICE</div>
                <div class="invoice-number">#' . htmlspecialchars($invoice['invoice_number']) . '</div>
            </div>
            
            <div class="invoice-details">
                <div class="info-grid">
                    <div class="info-box">
                        <strong>Invoice Date:</strong> ' . date('F d, Y', strtotime($invoice['created_at'])) . '<br>
                        <strong>Due Date:</strong> ' . date('F d, Y', strtotime($invoice['due_date'])) . '<br>
                        <strong>Status:</strong> <span class="status-badge status-' . strtolower($invoice_status) . '">' . $invoice_status . '</span>
                    </div>
                    <div class="info-box">
                        <strong>Case Number:</strong> ' . htmlspecialchars($invoice['case_number']) . '<br>
                        <strong>Case Title:</strong> ' . htmlspecialchars($invoice['case_title']) . '<br>
                        <strong>Assigned Lawyer:</strong> ' . htmlspecialchars($invoice['lawyer_name'] ?? 'Not Assigned') . '
                    </div>
                </div>
                
                <div class="bill-to-section">
                    <div class="section-title">BILL TO</div>
                    <div class="client-info">
                        <p><strong>Client Name:</strong> ' . htmlspecialchars($invoice['client_name']) . '</p>
                        <p><strong>Email:</strong> ' . htmlspecialchars($invoice['client_email']) . '</p>
                        <p><strong>Phone:</strong> ' . htmlspecialchars($invoice['client_phone'] ?? 'N/A') . '</p>
                        <p><strong>Address:</strong> ' . nl2br(htmlspecialchars($invoice['client_address'] ?? 'N/A')) . '</p>
                    </div>
                </div>
                
                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>' . htmlspecialchars($invoice['description']) . '</td>
                            <td>1</td>
                            <td>' . number_format($invoice['amount'], 2) . '</td>
                            <td>' . number_format($invoice['amount'], 2) . '</td>
                        </tr>
                    </tbody>
                </table>
                
                <div class="totals-section">
                    <table class="totals-table">
                        <tr>
                            <td>Subtotal:</td>
                            <td>$' . number_format($invoice['amount'], 2) . '</td>
                        </tr>
                        <tr>
                            <td>Tax (if applicable):</td>
                            <td>$0.00</td>
                        </tr>
                        <tr>
                            <td>Total Paid:</td>
                            <td>$' . number_format($total_paid, 2) . '</td>
                        </tr>
                        <tr class="grand-total">
                            <td><strong>Balance Due:</strong></td>
                            <td><strong>$' . number_format($balance_due, 2) . '</strong></td>
                        </tr>
                    </table>
                </div>';
    
    if (!empty($payments)) {
        $html .= '
                <div class="payments-section">
                    <div class="section-title">PAYMENT HISTORY</div>
                    <table class="payment-history-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>';
        
        foreach ($payments as $payment) {
            $html .= '
                            <tr>
                                <td>' . date('M d, Y', strtotime($payment['payment_date'])) . '</td>
                                <td>' . ucfirst(htmlspecialchars($payment['payment_method'])) . '</td>
                                <td>' . htmlspecialchars($payment['transaction_id'] ?? 'N/A') . '</td>
                                <td>$' . number_format($payment['amount'], 2) . '</td>
                                <td><span class="status-badge status-' . ($payment['payment_status'] == 'completed' ? 'paid' : 'unpaid') . '">' . ucfirst($payment['payment_status']) . '</span></td>
                            </tr>';
        }
        
        $html .= '
                        </tbody>
                    </table>
                </div>';
    }
    
    $html .= '
                <div class="terms-section">
                    <strong>Terms & Conditions:</strong><br>
                    1. Payment is due within 30 days of invoice date.<br>
                    2. Late payments may incur a 5% monthly interest charge.<br>
                    3. Please include invoice number with your payment.<br>
                    4. For payment inquiries, contact accounts@lawfirm.com<br>
                    <br>
                    <strong>Payment Methods:</strong><br>
                    • Bank Transfer: Account Name: Law Firm, Account: 1234567890, Bank: Example Bank<br>
                    • Credit Card: Available through client portal<br>
                    • Cash/Check: Payable to "Law Firm & Associates"
                </div>
            </div>
            
            <div class="footer">
                <p>Law Firm & Associates | 123 Legal Street, Justice City, 12345</p>
                <p>Phone: (555) 123-4567 | Email: info@lawfirm.com | Website: www.lawfirm.com</p>
                <p style="margin-top: 10px; font-size: 11px;">Thank you for your business!</p>
            </div>
        </div>
        
        <div class="action-buttons no-print">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Invoice
            </button>
            <button onclick="downloadPDF()" class="btn btn-secondary">
                <i class="fas fa-file-pdf"></i> Download PDF
            </button>
            <a href="client_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <script>
            function downloadPDF() {
                window.location.href = "get_invoice.php?id=' . $invoice['id'] . '&format=pdf";
            }
            
            // Auto-print if print parameter is set
            ' . (isset($_GET['print']) ? 'window.print();' : '') . '
        </script>
    </body>
    </html>';
    
    return $html;
}

// Display HTML invoice
echo generateInvoiceHTML($invoice, $payments, $total_paid, $balance_due, $invoice_status);
?>