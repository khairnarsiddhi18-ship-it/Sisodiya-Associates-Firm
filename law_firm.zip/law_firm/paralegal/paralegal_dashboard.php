<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'paralegal') {
    header("Location: login.php");
    exit();
}

$page_title = "Paralegal Dashboard";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Paralegal';

// Metrics
$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE status = 'active' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$research_tasks = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM documents WHERE DATE(uploaded_at) = CURDATE()");
$doc_review = $result->fetch_assoc()['total'] ?? 0;

// Get all lawyer schedules for calendar
$lawyer_schedules = $conn->query("SELECT a.*, u.full_name as lawyer_name, c.full_name as client_name 
                                  FROM appointments a 
                                  JOIN users u ON a.lawyer_id = u.id 
                                  JOIN users c ON a.client_id = c.id 
                                  WHERE a.appointment_date >= CURDATE() 
                                  ORDER BY a.appointment_date, a.appointment_time LIMIT 20");

// Get cases for assignment
$active_cases = $conn->query("SELECT c.*, u.full_name as client_name 
                              FROM cases c 
                              JOIN users u ON c.client_id = u.id 
                              WHERE (c.status = 'pending' OR c.assigned_lawyer_id IS NULL OR c.assigned_lawyer_id = '')
                              ORDER BY c.created_at DESC");

// Get upcoming hearings for calendar
$upcoming_hearings = $conn->query("
    SELECT h.*, 
           c.case_number, 
           c.title as case_title,
           c.status as case_status,
           cl.full_name as client_name,
           l.full_name as lawyer_name
    FROM hearings h
    JOIN cases c ON h.case_id = c.id
    JOIN users cl ON c.client_id = cl.id
    LEFT JOIN users l ON c.assigned_lawyer_id = l.id
    WHERE h.hearing_date >= CURDATE()
    ORDER BY h.hearing_date, h.hearing_time
");

// Get all active lawyers for multi-assignment
$all_lawyers = $conn->query("SELECT id, full_name, specialization, email FROM users WHERE role = 'lawyer' AND is_active = 1 ORDER BY full_name");

// Walk-in client intake form handling
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['intake_submit'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $case_description = trim($_POST['case_description']);
    
    if (empty($full_name) || empty($email) || empty($case_description)) {
        $intake_error = "Please fill in all required fields.";
    } else {
        $temp_password = substr(md5(uniqid()), 0, 8);
        $password_hash = password_hash($temp_password, PASSWORD_DEFAULT);
        $username = strtolower(str_replace(' ', '_', $full_name)) . rand(100, 999);
        
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active) VALUES (?, ?, ?, ?, ?, 'client', 1)");
        $stmt->bind_param("ssssss", $username, $email, $password_hash, $full_name, $phone);
        
        if($stmt->execute()) {
            $client_id = $conn->insert_id;
            $case_number = 'CASE-' . date('Ymd') . '-' . rand(1000, 9999);
            $stmt2 = $conn->prepare("INSERT INTO cases (case_number, title, description, client_id, status) VALUES (?, 'Walk-in Case', ?, ?, 'pending')");
            $stmt2->bind_param("ssi", $case_number, $case_description, $client_id);
            $stmt2->execute();
            $intake_success = "Client registered successfully! Temporary password: <strong>$temp_password</strong>";
        } else {
            $intake_error = "Error registering client: " . $conn->error;
        }
    }
}

// Handle multiple lawyer assignment for case
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_lawyers_submit'])) {
    $case_id = intval($_POST['case_id']);
    $selected_lawyers = isset($_POST['lawyer_ids']) ? $_POST['lawyer_ids'] : [];
    
    if (empty($selected_lawyers)) {
        $assignment_error = "Please select at least one lawyer to assign.";
    } else {
        $conn->begin_transaction();
        
        try {
            $delete_stmt = $conn->prepare("DELETE FROM case_lawyer_assignments WHERE case_id = ?");
            $delete_stmt->bind_param("i", $case_id);
            $delete_stmt->execute();
            
            $insert_stmt = $conn->prepare("INSERT INTO case_lawyer_assignments (case_id, lawyer_id, assigned_date, status) VALUES (?, ?, NOW(), 'active')");
            $primary_lawyer = $selected_lawyers[0];
            
            foreach ($selected_lawyers as $lawyer_id) {
                $insert_stmt->bind_param("ii", $case_id, $lawyer_id);
                $insert_stmt->execute();
            }
            
            $update_case = $conn->prepare("UPDATE cases SET assigned_lawyer_id = ?, status = 'active' WHERE id = ?");
            $update_case->bind_param("ii", $primary_lawyer, $case_id);
            $update_case->execute();
            
            $conn->commit();
            $assignment_success = "Case assigned to " . count($selected_lawyers) . " lawyer(s) successfully!";
            
            $active_cases = $conn->query("SELECT c.*, u.full_name as client_name 
                                          FROM cases c 
                                          JOIN users u ON c.client_id = u.id 
                                          WHERE (c.status = 'pending' OR c.assigned_lawyer_id IS NULL OR c.assigned_lawyer_id = '')
                                          ORDER BY c.created_at DESC");
        } catch (Exception $e) {
            $conn->rollback();
            $assignment_error = "Error assigning lawyers: " . $e->getMessage();
        }
    }
}

// Handle removal of lawyer from case
if (isset($_GET['remove_lawyer']) && isset($_GET['case_id']) && isset($_GET['lawyer_id'])) {
    $case_id = intval($_GET['case_id']);
    $lawyer_id = intval($_GET['lawyer_id']);
    
    $delete_stmt = $conn->prepare("DELETE FROM case_lawyer_assignments WHERE case_id = ? AND lawyer_id = ?");
    $delete_stmt->bind_param("ii", $case_id, $lawyer_id);
    
    if ($delete_stmt->execute()) {
        $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM case_lawyer_assignments WHERE case_id = ?");
        $check_stmt->bind_param("i", $case_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $count = $result->fetch_assoc()['count'];
        
        if ($count == 0) {
            $update_case = $conn->prepare("UPDATE cases SET assigned_lawyer_id = NULL, status = 'pending' WHERE id = ?");
            $update_case->bind_param("i", $case_id);
            $update_case->execute();
        } else {
            $get_first = $conn->prepare("SELECT lawyer_id FROM case_lawyer_assignments WHERE case_id = ? LIMIT 1");
            $get_first->bind_param("i", $case_id);
            $get_first->execute();
            $first_result = $get_first->get_result();
            $first_lawyer = $first_result->fetch_assoc();
            $update_case = $conn->prepare("UPDATE cases SET assigned_lawyer_id = ? WHERE id = ?");
            $update_case->bind_param("ii", $first_lawyer['lawyer_id'], $case_id);
            $update_case->execute();
        }
        
        $assignment_success = "Lawyer removed from case successfully!";
    } else {
        $assignment_error = "Error removing lawyer from case.";
    }
    
    $active_cases = $conn->query("SELECT c.*, u.full_name as client_name 
                                  FROM cases c 
                                  JOIN users u ON c.client_id = u.id 
                                  WHERE (c.status = 'pending' OR c.assigned_lawyer_id IS NULL OR c.assigned_lawyer_id = '')
                                  ORDER BY c.created_at DESC");
}

// Get assigned lawyers for each case
$assigned_lawyers = [];
$result = $conn->query("SELECT cla.case_id, cla.lawyer_id, cla.assigned_date, u.full_name as lawyer_name, u.specialization 
                        FROM case_lawyer_assignments cla 
                        JOIN users u ON cla.lawyer_id = u.id 
                        ORDER BY cla.case_id, cla.assigned_date");
while ($row = $result->fetch_assoc()) {
    $assigned_lawyers[$row['case_id']][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Paralegal Dashboard | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
            --accent: #8B2635;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: var(--secondary);
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: var(--secondary) !important;
        }

        .dashboard-container {
            background: var(--light);
            min-height: 100vh;
            padding: 30px 0 50px;
            margin-top: 70px;
        }

        .sidebar {
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 60px;
            left: 0;
            width: 250px;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255,255,255,0.85) !important;
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary) !important;
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark) !important;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px 30px;
        }

        .metric-card {
            border-radius: 20px;
            padding: 0;
            overflow: hidden;
            transition: all 0.3s;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            height: 100%;
        }

        .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        }

        .metric-card .card-body {
            padding: 20px;
            position: relative;
        }

        .metric-card h5 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 10px;
            opacity: 0.9;
        }

        .metric-card h2 {
            font-size: 36px;
            font-weight: 800;
            margin: 0;
        }

        .metric-icon {
            position: absolute;
            right: 20px;
            bottom: 20px;
            font-size: 2.5rem;
            opacity: 0.15;
        }

        .card-research { background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%); color: white; }
        .card-review { background: linear-gradient(135deg, var(--secondary) 0%, var(--secondary-light) 100%); color: var(--primary-dark); }
        .card-calendar { background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%); color: white; }

        .section-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border: none;
            margin-bottom: 25px;
        }

        .section-card .card-header {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            color: white;
            border: none;
            padding: 15px 20px;
        }

        .section-card .card-header h5 {
            margin: 0;
            font-weight: 700;
        }

        .section-card .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .section-card .card-body {
            padding: 20px;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .btn-success-custom {
            background: #10b981;
            border: none;
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-outline-custom {
            border: 1.5px solid var(--secondary);
            color: var(--primary-dark);
            background: transparent;
            padding: 10px 20px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .btn-outline-custom:hover {
            background: var(--secondary);
            color: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-danger-custom {
            background: #dc2626;
            border: none;
            color: white;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .btn-danger-custom:hover {
            background: #b91c1c;
            transform: translateY(-1px);
        }

        .assignment-item {
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            padding: 15px;
            transition: all 0.3s;
        }

        .assignment-item:hover {
            background: rgba(212, 175, 55, 0.05);
        }

        .assigned-lawyers-list {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
        }

        .lawyer-badge {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin: 3px;
        }

        .lawyer-badge .remove-lawyer {
            color: #ff6b6b;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            margin-left: 5px;
        }

        .lawyer-badge .remove-lawyer:hover {
            color: #ff4444;
        }

        .alert-success-custom {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
            border-radius: 12px;
            padding: 12px 20px;
            margin-bottom: 20px;
        }

        .alert-danger-custom {
            background: #f8d7da;
            border-left: 4px solid #C72A2A;
            color: #721c24;
            border-radius: 12px;
            padding: 12px 20px;
            margin-bottom: 20px;
        }

        .checkbox-group {
            max-height: 200px;
            overflow-y: auto;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px;
        }

        .checkbox-item {
            padding: 8px 10px;
            margin: 5px 0;
            border-radius: 8px;
            transition: all 0.2s;
        }

        .checkbox-item:hover {
            background: rgba(212, 175, 55, 0.1);
        }

        .checkbox-item input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.1);
            cursor: pointer;
        }

        .checkbox-item label {
            cursor: pointer;
            margin: 0;
            display: inline-flex;
            flex-direction: column;
        }

        .lawyer-specialization {
            font-size: 11px;
            color: #6b7280;
            margin-left: 25px;
        }

        .calendar-container {
            background: white;
            border-radius: 16px;
            padding: 15px;
        }

        .fc {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: white;
            border-radius: 16px;
        }

        .fc .fc-toolbar {
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .fc .fc-toolbar-title {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 1.25rem;
        }

        .fc .fc-button {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            border: none;
            color: white;
            padding: 6px 12px;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .fc .fc-button:hover {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            transform: translateY(-1px);
        }

        .fc .fc-button-primary:not(:disabled).fc-button-active,
        .fc .fc-button-primary:not(:disabled):active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
        }

        .fc .fc-col-header-cell {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            padding: 8px 0;
        }

        .fc .fc-col-header-cell-cushion {
            color: white;
            font-weight: 600;
            text-decoration: none;
        }

        .fc .fc-daygrid-day {
            transition: background 0.2s;
            cursor: pointer;
        }

        .fc .fc-daygrid-day:hover {
            background: rgba(212, 175, 55, 0.05);
        }

        .fc .fc-daygrid-day-number {
            color: var(--primary-dark);
            font-weight: 500;
            padding: 5px;
        }

        .fc .fc-daygrid-day.has-hearing {
            background: rgba(212, 175, 55, 0.2);
            position: relative;
        }

        .fc .fc-day-today {
            background: rgba(212, 175, 55, 0.08) !important;
        }

        .fc .fc-day-today .fc-daygrid-day-number {
            background: var(--secondary);
            color: var(--primary-dark);
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .hearing-modal .modal-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .hearing-modal .modal-header .btn-close {
            background: white;
            opacity: 1;
        }

        .hearing-detail-card {
            background: var(--light);
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid var(--secondary);
        }

        .detail-row {
            display: flex;
            padding: 8px 0;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }

        .detail-label {
            width: 120px;
            font-weight: 600;
            color: var(--primary-dark);
        }

        .detail-value {
            flex: 1;
            color: #4a5568;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-closed { background: #d1ecf1; color: #0c5460; }

        .select-all-btn {
            font-size: 12px;
            padding: 4px 8px;
            margin-bottom: 10px;
        }

        .selected-count {
            font-size: 12px;
            color: var(--secondary);
            font-weight: 600;
            margin-top: 10px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show { left: 0; }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .metric-card h2 { font-size: 28px; }
            .fc .fc-toolbar { flex-direction: column; align-items: center; }
            .detail-row { flex-direction: column; }
            .detail-label { width: 100%; margin-bottom: 5px; }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="dashboard-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4 pb-2 border-bottom" style="border-color: rgba(212,175,55,0.3) !important;">
                        <div class="logo-icon-small mb-2" style="width: 50px; height: 50px; background: var(--secondary); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center;">
                            <i class="fas fa-gavel" style="color: var(--primary-dark); font-size: 1.5rem;"></i>
                        </div>
                        <h6 class="text-white mb-0">Paralegal Portal</h6>
                        <small class="text-white-50">Welcome, <?php echo htmlspecialchars($user_name); ?></small>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link active" href="paralegal_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="#calendar-section"><i class="fas fa-calendar-alt"></i> Global Calendar</a></li>
                        <li class="nav-item"><a class="nav-link" href="#intake"><i class="fas fa-user-plus"></i> Client Intake</a></li>
                        <li class="nav-item"><a class="nav-link" href="../cases.php"><i class="fas fa-briefcase"></i> Case Tracker</a></li>
                        
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4 main-content">
                <div class="pt-3 pb-2 mb-3">
                    <h1 class="h2" style="color: var(--primary-dark);">Paralegal Dashboard</h1>
                    <p class="text-muted">Manage research, documents, and client intake</p>
                </div>

                <?php if(isset($assignment_success)): ?>
                    <div class="alert-success-custom"><?php echo $assignment_success; ?></div>
                <?php endif; ?>
                <?php if(isset($assignment_error)): ?>
                    <div class="alert-danger-custom"><?php echo $assignment_error; ?></div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="metric-card card-research">
                            <div class="card-body">
                                <h5><i class="fas fa-tasks me-2"></i> Research Tasks</h5>
                                <h2><?php echo $research_tasks; ?></h2>
                                <small>Active cases this week</small>
                                <i class="fas fa-tasks metric-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="metric-card card-review">
                            <div class="card-body">
                                <h5><i class="fas fa-file-alt me-2"></i> Doc Review Queue</h5>
                                <h2><?php echo $doc_review; ?></h2>
                                <small>Documents uploaded today</small>
                                <i class="fas fa-file-alt metric-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="metric-card card-calendar">
                            <div class="card-body">
                                <h5><i class="fas fa-calendar me-2"></i> Calendar Updates</h5>
                                <h2><?php echo $lawyer_schedules ? $lawyer_schedules->num_rows : 0; ?></h2>
                                <small>Upcoming appointments</small>
                                <i class="fas fa-calendar-alt metric-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8" id="calendar-section">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-calendar-alt"></i> Global Calendar - Hearing Dates</h5>
                            </div>
                            <div class="card-body">
                                <div class="calendar-container">
                                    <div id="calendar"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="section-card">
                            <div class="card-header">
                                <h5><i class="fas fa-user-check"></i> Assign Cases to Lawyers (Multi-Select)</h5>
                            </div>
                            <div class="card-body p-0" style="max-height: 600px; overflow-y: auto;">
                                <?php if($active_cases && $active_cases->num_rows > 0): ?>
                                    <?php while($case = $active_cases->fetch_assoc()): ?>
                                        <?php 
                                        $case_id = $case['id'];
                                        $current_assignments = isset($assigned_lawyers[$case_id]) ? $assigned_lawyers[$case_id] : [];
                                        ?>
                                        <div class="assignment-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <strong style="color: var(--primary-dark);"><?php echo htmlspecialchars($case['case_number']); ?></strong>
                                                    <p class="small text-muted mb-1">Client: <?php echo htmlspecialchars($case['client_name']); ?></p>
                                                    <p class="small text-muted mb-0">Created: <?php echo date('M d, Y', strtotime($case['created_at'])); ?></p>
                                                </div>
                                                <span class="badge bg-warning text-dark">Pending</span>
                                            </div>
                                            
                                            <?php if(!empty($current_assignments)): ?>
                                                <div class="assigned-lawyers-list">
                                                    <small class="text-muted"><i class="fas fa-users"></i> Currently Assigned Lawyers:</small>
                                                    <div class="mt-1">
                                                        <?php foreach($current_assignments as $assignment): ?>
                                                            <span class="lawyer-badge">
                                                                <i class="fas fa-user-tie"></i> <?php echo htmlspecialchars($assignment['lawyer_name']); ?>
                                                                <?php if($assignment['specialization']): ?>
                                                                    <small>(<?php echo htmlspecialchars($assignment['specialization']); ?>)</small>
                                                                <?php endif; ?>
                                                                <a href="?remove_lawyer=1&case_id=<?php echo $case_id; ?>&lawyer_id=<?php echo $assignment['lawyer_id']; ?>" 
                                                                   class="remove-lawyer" 
                                                                   onclick="return confirm('Remove <?php echo addslashes($assignment['lawyer_name']); ?> from this case?')">
                                                                    <i class="fas fa-times-circle"></i>
                                                                </a>
                                                            </span>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <form method="POST" class="mt-3">
                                                <input type="hidden" name="case_id" value="<?php echo $case_id; ?>">
                                                <div class="mb-2">
                                                    <label class="form-label small fw-bold">Select Lawyers to Assign:</label>
                                                    <div class="checkbox-group">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary select-all-btn" onclick="toggleSelectAll(this, 'lawyer_ids_<?php echo $case_id; ?>')">
                                                            Select All
                                                        </button>
                                                        <?php 
                                                        $all_lawyers->data_seek(0);
                                                        while($lawyer = $all_lawyers->fetch_assoc()): 
                                                            $is_assigned = false;
                                                            foreach($current_assignments as $assignment) {
                                                                if($assignment['lawyer_id'] == $lawyer['id']) {
                                                                    $is_assigned = true;
                                                                    break;
                                                                }
                                                            }
                                                        ?>
                                                            <div class="checkbox-item">
                                                                <input type="checkbox" 
                                                                       name="lawyer_ids[]" 
                                                                       value="<?php echo $lawyer['id']; ?>" 
                                                                       id="lawyer_<?php echo $case_id . '_' . $lawyer['id']; ?>"
                                                                       class="lawyer-checkbox-<?php echo $case_id; ?>"
                                                                       <?php echo $is_assigned ? 'checked disabled' : ''; ?>>
                                                                <label for="lawyer_<?php echo $case_id . '_' . $lawyer['id']; ?>">
                                                                    <strong><?php echo htmlspecialchars($lawyer['full_name']); ?></strong>
                                                                    <?php if($lawyer['specialization']): ?>
                                                                        <span class="lawyer-specialization"><?php echo htmlspecialchars($lawyer['specialization']); ?></span>
                                                                    <?php endif; ?>
                                                                </label>
                                                            </div>
                                                        <?php endwhile; ?>
                                                    </div>
                                                    <div class="selected-count" id="selected_count_<?php echo $case_id; ?>">
                                                        0 lawyers selected
                                                    </div>
                                                </div>
                                                <button type="submit" name="assign_lawyers_submit" class="btn btn-primary-custom w-100 btn-sm">
                                                    <i class="fas fa-user-plus"></i> Assign Selected Lawyers
                                                </button>
                                            </form>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="text-center text-muted p-4">
                                        <i class="fas fa-check-circle fa-3x mb-3" style="color: var(--secondary); opacity: 0.5;"></i>
                                        <p>No pending cases for assignment.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="section-card mt-4" id="intake">
                            <div class="card-header">
                                <h5><i class="fas fa-user-plus"></i> Walk-in Client Intake</h5>
                            </div>
                            <div class="card-body">
                                <?php if(isset($intake_success)): ?>
                                    <div class="alert-success-custom"><?php echo $intake_success; ?></div>
                                <?php endif; ?>
                                <?php if(isset($intake_error)): ?>
                                    <div class="alert-danger-custom"><?php echo $intake_error; ?></div>
                                <?php endif; ?>
                                <form method="POST">
                                    <div class="mb-2"><input type="text" class="form-control" name="full_name" placeholder="Full Name *" required></div>
                                    <div class="mb-2"><input type="email" class="form-control" name="email" placeholder="Email *" required></div>
                                    <div class="mb-2"><input type="tel" class="form-control" name="phone" placeholder="Phone"></div>
                                    <div class="mb-2"><textarea class="form-control" name="case_description" rows="3" placeholder="Case Description *" required></textarea></div>
                                    <button type="submit" name="intake_submit" class="btn btn-primary-custom w-100">Register Client</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<div class="modal fade hearing-modal" id="hearingDetailModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-gavel" style="color: var(--secondary);"></i> Hearing Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="hearingDetailContent"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <a href="#" id="viewCaseLink" class="btn btn-primary-custom">View Full Case Details</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const hearingData = [
        <?php 
        $hearings_for_calendar = $conn->query("
            SELECT h.*, c.case_number, c.title, c.status, cl.full_name as client_name, l.full_name as lawyer_name
            FROM hearings h
            JOIN cases c ON h.case_id = c.id
            JOIN users cl ON c.client_id = cl.id
            LEFT JOIN users l ON c.assigned_lawyer_id = l.id
            WHERE h.hearing_date >= CURDATE()
            ORDER BY h.hearing_date
        ");
        if($hearings_for_calendar && $hearings_for_calendar->num_rows > 0):
            while($hearing = $hearings_for_calendar->fetch_assoc()):
                $hearing_json = json_encode([
                    'id' => $hearing['id'],
                    'case_id' => $hearing['case_id'],
                    'case_number' => $hearing['case_number'],
                    'title' => $hearing['title'],
                    'status' => $hearing['status'],
                    'hearing_date' => $hearing['hearing_date'],
                    'hearing_time' => $hearing['hearing_time'],
                    'venue' => $hearing['venue'],
                    'hearing_type' => $hearing['hearing_type'] ?? 'General',
                    'hearing_reason' => $hearing['hearing_reason'] ?? 'Not Specified',
                    'notes' => $hearing['notes'],
                    'client_name' => $hearing['client_name'],
                    'lawyer_name' => $hearing['lawyer_name'] ?? 'Not Assigned'
                ]);
        ?>
        {
            id: <?php echo $hearing['id']; ?>,
            title: '⚖️',
            start: '<?php echo $hearing['hearing_date'] . 'T' . $hearing['hearing_time']; ?>',
            backgroundColor: '#D4AF37',
            borderColor: '#D4AF37',
            textColor: '#4A0E17',
            extendedProps: <?php echo $hearing_json; ?>
        },
        <?php 
            endwhile;
        endif;
        ?>
    ];
    
    function toggleSelectAll(button, groupClass) {
        const checkboxes = document.querySelectorAll('.' + groupClass);
        const allChecked = Array.from(checkboxes).every(cb => cb.checked || cb.disabled);
        
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = !allChecked;
            }
        });
        
        checkboxes.forEach(cb => {
            const event = new Event('change');
            cb.dispatchEvent(event);
        });
        
        button.textContent = allChecked ? 'Select All' : 'Deselect All';
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        if (calendarEl) {
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek'
                },
                events: hearingData,
                eventClick: function(info) {
                    const hearing = info.event.extendedProps;
                    displayHearingDetails(hearing);
                },
                eventTimeFormat: { hour: 'numeric', minute: '2-digit', meridiem: 'short' },
                dayMaxEvents: true,
                weekends: true,
                height: 'auto',
                buttonText: { today: 'Today', month: 'Month', week: 'Week', day: 'Day' },
                dayCellDidMount: function(info) {
                    const dateStr = info.date.toISOString().split('T')[0];
                    const hasHearing = hearingData.some(event => event.start.startsWith(dateStr));
                    if (hasHearing) {
                        info.el.classList.add('has-hearing');
                    }
                }
            });
            calendar.render();
        }
    });
    
    function displayHearingDetails(hearing) {
        const modalBody = document.getElementById('hearingDetailContent');
        const viewCaseLink = document.getElementById('viewCaseLink');
        
        viewCaseLink.href = `case_details.php?id=${hearing.case_id}`;
        
        let statusClass = '';
        switch(hearing.status) {
            case 'active': statusClass = 'status-active'; break;
            case 'pending': statusClass = 'status-pending'; break;
            case 'closed': statusClass = 'status-closed'; break;
            default: statusClass = 'status-pending';
        }
        
        modalBody.innerHTML = `
            <div class="hearing-detail-card">
                <h5 style="color: var(--primary-dark); margin-bottom: 15px;"><i class="fas fa-gavel" style="color: var(--secondary);"></i> Hearing Information</h5>
                <div class="detail-row"><div class="detail-label">Case Number:</div><div class="detail-value"><strong>${escapeHtml(hearing.case_number)}</strong></div></div>
                <div class="detail-row"><div class="detail-label">Case Title:</div><div class="detail-value">${escapeHtml(hearing.title)}</div></div>
                <div class="detail-row"><div class="detail-label">Case Status:</div><div class="detail-value"><span class="status-badge ${statusClass}">${hearing.status.toUpperCase()}</span></div></div>
                <div class="detail-row"><div class="detail-label">Hearing Date:</div><div class="detail-value">${formatDate(hearing.hearing_date)} at ${formatTime(hearing.hearing_time)}</div></div>
                <div class="detail-row"><div class="detail-label">Venue:</div><div class="detail-value">${escapeHtml(hearing.venue)}</div></div>
                <div class="detail-row"><div class="detail-label">Hearing Type:</div><div class="detail-value">${escapeHtml(hearing.hearing_type)}</div></div>
                <div class="detail-row"><div class="detail-label">Hearing Reason:</div><div class="detail-value">${escapeHtml(hearing.hearing_reason)}</div></div>
                ${hearing.notes ? `<div class="detail-row"><div class="detail-label">Notes:</div><div class="detail-value">${escapeHtml(hearing.notes)}</div></div>` : ''}
            </div>
            <div class="hearing-detail-card">
                <h5 style="color: var(--primary-dark); margin-bottom: 15px;"><i class="fas fa-users" style="color: var(--secondary);"></i> Case Parties</h5>
                <div class="detail-row"><div class="detail-label">Client Name:</div><div class="detail-value">${escapeHtml(hearing.client_name)}</div></div>
                <div class="detail-row"><div class="detail-label">Assigned Lawyer:</div><div class="detail-value">${escapeHtml(hearing.lawyer_name)}</div></div>
            </div>
        `;
        
        new bootstrap.Modal(document.getElementById('hearingDetailModal')).show();
    }
    
    function formatDate(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    }
    
    function formatTime(timeStr) {
        const [hours, minutes] = timeStr.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minutes} ${ampm}`;
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
</script>

</body>
</html>