<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Case Management";
$user_role = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];

// Build query based on role
switch($user_role) {
    case 'admin':
        $cases_query = "SELECT c.*, cl.full_name as client_name, l.full_name as lawyer_name 
                       FROM cases c 
                       LEFT JOIN users cl ON c.client_id = cl.id 
                       LEFT JOIN users l ON c.assigned_lawyer_id = l.id 
                       ORDER BY c.created_at DESC";
        break;
    case 'lawyer':
        $cases_query = "SELECT c.*, cl.full_name as client_name 
                       FROM cases c 
                       JOIN users cl ON c.client_id = cl.id 
                       WHERE c.assigned_lawyer_id = $user_id 
                       ORDER BY c.created_at DESC";
        break;
    case 'client':
        $cases_query = "SELECT c.*, l.full_name as lawyer_name 
                       FROM cases c 
                       LEFT JOIN users l ON c.assigned_lawyer_id = l.id 
                       WHERE c.client_id = $user_id 
                       ORDER BY c.created_at DESC";
        break;
    default:
        $cases_query = "SELECT * FROM cases LIMIT 10";
}

$cases = $conn->query($cases_query);

require_once '../includes/header.php';
?>

<style>
    /* Page Specific Styles */
    .page-container {
        background: #FDF8F0;
        min-height: 100vh;
        padding: 30px 0 50px;
        margin-top: 70px;
    }

    .cases-card {
        background: white;
        border-radius: 20px;
        border: none;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        overflow: hidden;
    }

    .cases-card .card-header {
        background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
        color: white;
        border: none;
        padding: 18px 25px;
    }

    .cases-card .card-header h4 {
        margin: 0;
        font-weight: 700;
    }

    .cases-card .card-header h4 i {
        color: #D4AF37;
        margin-right: 10px;
    }

    .cases-card .card-header .btn-primary-custom {
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border: none;
        color: #4A0E17;
        font-weight: 600;
        padding: 8px 20px;
        border-radius: 12px;
        transition: all 0.3s;
    }

    .cases-card .card-header .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .cases-card .card-body {
        padding: 25px;
    }

    /* Table Styles */
    .data-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }

    .data-table thead th {
        background: #4A0E17;
        color: white;
        font-weight: 600;
        padding: 12px 15px;
        border: none;
    }

    .data-table thead th:first-child {
        border-radius: 12px 0 0 0;
    }

    .data-table thead th:last-child {
        border-radius: 0 12px 0 0;
    }

    .data-table tbody tr {
        transition: all 0.3s;
        border-bottom: 1px solid rgba(212, 175, 55, 0.15);
    }

    .data-table tbody tr:hover {
        background: rgba(212, 175, 55, 0.05);
        transform: scale(1.01);
    }

    .data-table tbody td {
        padding: 12px 15px;
        vertical-align: middle;
        color: #4A0E17;
    }

    /* Status Badges */
    .badge-status {
        padding: 6px 12px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 600;
    }

    .badge-active {
        background: #d4edda;
        color: #155724;
    }

    .badge-pending {
        background: #fff3cd;
        color: #856404;
    }

    .badge-closed {
        background: #e2e3e5;
        color: #383d41;
    }

    .badge-archived {
        background: #f8d7da;
        color: #721c24;
    }

    /* Progress Bar */
    .progress-custom {
        height: 25px;
        background: #e2e8f0;
        border-radius: 12px;
        overflow: hidden;
        min-width: 80px;
    }

    .progress-bar-custom {
        background: linear-gradient(90deg, #D4AF37, #F5D76E);
        color: #4A0E17;
        font-weight: 600;
        font-size: 12px;
        line-height: 25px;
        text-align: center;
        border-radius: 12px;
    }

    /* Action Buttons */
    .btn-action {
        padding: 5px 10px;
        margin: 0 2px;
        border-radius: 8px;
        transition: all 0.3s;
    }

    .btn-action:hover {
        transform: translateY(-2px);
    }

    .btn-view {
        background: #D4AF37;
        color: #4A0E17;
        border: none;
    }

    .btn-view:hover {
        background: #F5D76E;
        color: #4A0E17;
    }

    .btn-edit {
        background: #f59e0b;
        color: white;
        border: none;
    }

    .btn-edit:hover {
        background: #d97706;
    }

    .btn-delete {
        background: #C72A2A;
        color: white;
        border: none;
    }

    .btn-delete:hover {
        background: #8B2635;
    }

    /* DataTables Customization */
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #D4AF37 !important;
        color: #4A0E17 !important;
        border-color: #D4AF37 !important;
        border-radius: 8px !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        background: #F5D76E !important;
        color: #4A0E17 !important;
        border-radius: 8px !important;
    }

    .dataTables_wrapper .dataTables_filter input {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 6px 12px;
        margin-left: 8px;
    }

    .dataTables_wrapper .dataTables_filter input:focus {
        border-color: #D4AF37;
        outline: none;
    }

    .dataTables_wrapper .dataTables_length select {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 5px;
        margin: 0 5px;
    }

    @media (max-width: 768px) {
        .cases-card .card-header {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
        
        .cases-card .card-header .btn {
            width: 100%;
        }
        
        .data-table thead {
            display: none;
        }
        
        .data-table tbody tr {
            display: block;
            margin-bottom: 15px;
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
        }
        
        .data-table tbody td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .data-table tbody td:before {
            content: attr(data-label);
            font-weight: 600;
            color: #4A0E17;
            margin-right: 10px;
        }
        
        .progress-custom {
            width: 100%;
        }
    }
</style>

<div class="page-container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="cases-card">
                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                        <h4 class="mb-0"><i class="fas fa-briefcase"></i> Case Management</h4>
                        <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                            <a href="../add_case.php" class="btn btn-primary-custom">
                                <i class="fas fa-plus me-2"></i> Add New Case
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="casesTable" class="data-table table">
                                <thead>
                                    <tr>
                                        <th>Case #</th>
                                        <th>Title</th>
                                        <th>Client</th>
                                        <th>Assigned To</th>
                                        <th>Status</th>
                                        <th>Progress</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($case = $cases->fetch_assoc()): ?>
                                        <tr>
                                            <td data-label="Case #">
                                                <strong style="color: #D4AF37;"><?php echo $case['case_number']; ?></strong>
                                            </td>
                                            <td data-label="Title"><?php echo substr($case['title'], 0, 50); ?></td>
                                            <td data-label="Client"><?php echo $case['client_name'] ?? 'N/A'; ?></td>
                                            <td data-label="Assigned To"><?php echo $case['lawyer_name'] ?? 'Unassigned'; ?></td>
                                            <td data-label="Status">
                                                <span class="badge-status badge-<?php echo $case['status']; ?>">
                                                    <?php echo ucfirst($case['status']); ?>
                                                </span>
                                            </td>
                                            <td data-label="Progress">
                                                <div class="progress-custom">
                                                    <div class="progress-bar-custom" style="width: <?php echo $case['progress']; ?>%">
                                                        <?php echo $case['progress']; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td data-label="Created"><?php echo date('M d, Y', strtotime($case['created_at'])); ?></td>
                                            <td data-label="Actions">
                                                <a href="../case_details.php?id=<?php echo $case['id']; ?>" class="btn btn-action btn-view" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if(in_array($user_role, ['admin', 'lawyer'])): ?>
                                                    <a href="../edit_case.php?id=<?php echo $case['id']; ?>" class="btn btn-action btn-edit" title="Edit Case">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button onclick="deleteCase(<?php echo $case['id']; ?>)" class="btn btn-action btn-delete" title="Delete Case">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#casesTable').DataTable({
            pageLength: 25,
            order: [[6, 'desc']],
            language: {
                search: "Search cases:",
                lengthMenu: "Show _MENU_ cases",
                info: "Showing _START_ to _END_ of _TOTAL_ cases",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "→",
                    previous: "←"
                }
            },
            columnDefs: [
                { orderable: false, targets: 7 }
            ]
        });
    });
    
    function deleteCase(caseId) {
        if(confirm('⚠️ Are you sure you want to delete this case?\n\nThis action cannot be undone and will remove all related data including hearings, documents, and invoices.')) {
            window.location.href = 'delete_case.php?id=' + caseId;
        }
    }
</script>

<?php require_once '../includes/footer.php'; ?>