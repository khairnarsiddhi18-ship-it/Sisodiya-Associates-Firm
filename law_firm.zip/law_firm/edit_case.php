<?php
session_start();
require_once 'config/database.php';

if (!in_array($_SESSION['user_role'], ['admin', 'lawyer', 'paralegal'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Edit Case";
$case_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Set dashboard redirect based on role
switch($user_role) {
    case 'admin':
        $dashboard_url = 'admin/admin_dashboard.php';
        $dashboard_name = 'Admin Dashboard';
        break;
    case 'lawyer':
        $dashboard_url = 'lawyer/lawyer_dashboard.php';
        $dashboard_name = 'Lawyer Dashboard';
        break;
    case 'paralegal':
        $dashboard_url = 'paralegal/paralegal_dashboard.php';
        $dashboard_name = 'Paralegal Dashboard';
        break;
    default:
        $dashboard_url = 'dashboard.php';
        $dashboard_name = 'Dashboard';
}

// Fetch case details
$query = "SELECT c.*, u.full_name as client_name FROM cases c 
          LEFT JOIN users u ON c.client_id = u.id 
          WHERE c.id = $case_id";

if ($user_role == 'lawyer') {
    $query .= " AND c.assigned_lawyer_id = $user_id";
}

$result = $conn->query($query);
$case = $result->fetch_assoc();

if (!$case) {
    header("Location: cases.php?error=not_found");
    exit();
}

// Fetch next hearing details if exists
$next_hearing = $conn->query("SELECT * FROM hearings WHERE case_id = $case_id AND hearing_date >= CURDATE() ORDER BY hearing_date ASC LIMIT 1")->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $case_number = $_POST['case_number'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $client_id = $_POST['client_id'];
    $assigned_lawyer_id = $_POST['assigned_lawyer_id'];
    $status = $_POST['status'];
    $progress = $_POST['progress'];
    
    // Update case
    $stmt = $conn->prepare("UPDATE cases SET case_number=?, title=?, description=?, client_id=?, assigned_lawyer_id=?, status=?, progress=? WHERE id=?");
    $stmt->bind_param("sssiisii", $case_number, $title, $description, $client_id, $assigned_lawyer_id, $status, $progress, $case_id);
    
    if ($stmt->execute()) {
        // Handle hearing update/add
        $hearing_date = $_POST['hearing_date'];
        $hearing_time = $_POST['hearing_time'];
        $venue = $_POST['venue'];
        
        // Handle hearing type - if other, use custom value
        $hearing_type = $_POST['hearing_type'];
        if ($hearing_type == 'other' && !empty($_POST['hearing_type_custom'])) {
            $hearing_type = $_POST['hearing_type_custom'];
        }
        
        // Handle hearing reason - if other, use custom value
        $hearing_reason = $_POST['hearing_reason'];
        if ($hearing_reason == 'other' && !empty($_POST['hearing_reason_custom'])) {
            $hearing_reason = $_POST['hearing_reason_custom'];
        }
        
        $hearing_notes = $_POST['hearing_notes'];
        
        if (!empty($hearing_date) && !empty($hearing_time)) {
            // Check if hearing already exists
            $check_hearing = $conn->query("SELECT id FROM hearings WHERE case_id = $case_id AND hearing_date >= CURDATE() ORDER BY hearing_date LIMIT 1");
            
            if ($check_hearing->num_rows > 0) {
                // Update existing hearing
                $hearing_id = $check_hearing->fetch_assoc()['id'];
                $update_hearing = $conn->prepare("UPDATE hearings SET hearing_date=?, hearing_time=?, venue=?, hearing_type=?, hearing_reason=?, notes=? WHERE id=?");
                $update_hearing->bind_param("ssssssi", $hearing_date, $hearing_time, $venue, $hearing_type, $hearing_reason, $hearing_notes, $hearing_id);
                $update_hearing->execute();
            } else {
                // Insert new hearing
                $insert_hearing = $conn->prepare("INSERT INTO hearings (case_id, hearing_date, hearing_time, venue, hearing_type, hearing_reason, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $insert_hearing->bind_param("issssssi", $case_id, $hearing_date, $hearing_time, $venue, $hearing_type, $hearing_reason, $hearing_notes, $user_id);
                $insert_hearing->execute();
            }
        }
        
        header("Location: case_details.php?id=$case_id&msg=updated");
        exit();
    } else {
        $error = "Error updating case: " . $conn->error;
    }
}

// Get clients and lawyers for dropdowns
$clients = $conn->query("SELECT id, full_name, email FROM users WHERE role = 'client' ORDER BY full_name");
$lawyers = $conn->query("SELECT id, full_name FROM users WHERE role = 'lawyer' ORDER BY full_name");

require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
    }

    .page-container {
        background: var(--light);
        min-height: 100vh;
        padding: 30px 0 50px;
        margin-top: 70px;
    }

    .form-container {
        max-width: 1000px;
        margin: 0 auto;
    }

    .form-card {
        background: white;
        border-radius: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        overflow: hidden;
    }

    .form-header {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
        padding: 30px;
        text-align: center;
    }

    .form-header h2 {
        font-weight: 800;
        margin-bottom: 8px;
    }

    .form-header h2 i {
        color: var(--secondary);
    }

    .form-body {
        padding: 40px;
    }

    .section-title {
        color: var(--primary-dark);
        font-weight: 700;
        margin: 25px 0 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid rgba(212, 175, 55, 0.3);
    }

    .section-title i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .form-label {
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 8px;
    }

    .form-control, .form-select {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 12px 15px;
        transition: all 0.3s;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--secondary);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        outline: none;
    }

    .btn-submit {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 700;
        color: var(--primary-dark);
        transition: all 0.3s;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
    }

    .btn-cancel {
        background: #6c757d;
        border: none;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        color: white;
        transition: all 0.3s;
    }

    .btn-cancel:hover {
        background: #5a6268;
        transform: translateY(-2px);
    }

    .btn-dashboard {
        background: transparent;
        border: 2px solid var(--secondary);
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        color: var(--primary-dark);
        transition: all 0.3s;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }

    .btn-dashboard:hover {
        background: var(--secondary);
        color: var(--primary-dark);
        transform: translateY(-2px);
    }

    .progress-preview {
        margin-top: 10px;
        height: 8px;
        background: #e2e8f0;
        border-radius: 10px;
        overflow: hidden;
    }

    .progress-preview-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--secondary), var(--secondary-light));
        transition: width 0.3s;
        border-radius: 10px;
    }

    .alert-danger-custom {
        background: #f8d7da;
        border-left: 4px solid #C72A2A;
        color: #721c24;
        border-radius: 12px;
        padding: 12px 20px;
        margin-bottom: 20px;
    }

    .hearing-info-card {
        background: rgba(212, 175, 55, 0.05);
        border-radius: 15px;
        padding: 20px;
        margin-top: 10px;
        border: 1px solid rgba(212, 175, 55, 0.2);
    }

    .hearing-label {
        font-weight: 600;
        color: var(--primary-dark);
    }

    .current-hearing-alert {
        background: rgba(212, 175, 55, 0.1);
        border-left: 4px solid #D4AF37;
        border-radius: 12px;
        padding: 12px 15px;
        margin-bottom: 15px;
    }

    /* Custom Input for Other Option */
    .custom-input-group {
        margin-top: 10px;
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 768px) {
        .form-body {
            padding: 25px;
        }
        
        .btn-submit, .btn-cancel, .btn-dashboard {
            width: 100%;
            margin-bottom: 10px;
        }
        
        .d-flex.gap-3 {
            flex-direction: column;
            gap: 10px !important;
        }
    }
</style>

<div class="page-container">
    <div class="container form-container">
        <div class="form-card">
            <div class="form-header">
                <h2><i class="fas fa-edit me-2"></i>Edit Case</h2>
                <p class="mb-0 opacity-75">Update case information, hearing details, and more</p>
            </div>
            <div class="form-body">
                <?php if(isset($error)): ?>
                    <div class="alert-danger-custom">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <!-- Basic Information Section -->
                    <h5 class="section-title"><i class="fas fa-info-circle"></i> Basic Information</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Case Number</label>
                            <input type="text" class="form-control" name="case_number" 
                                   value="<?php echo htmlspecialchars($case['case_number']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Case Title</label>
                            <input type="text" class="form-control" name="title" 
                                   value="<?php echo htmlspecialchars($case['title']); ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="4" required><?php echo htmlspecialchars($case['description']); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Client</label>
                            <select class="form-select" name="client_id" required>
                                <option value="">Select Client...</option>
                                <?php while($client = $clients->fetch_assoc()): ?>
                                    <option value="<?php echo $client['id']; ?>" 
                                        <?php echo ($case['client_id'] == $client['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($client['full_name']); ?> (<?php echo htmlspecialchars($client['email']); ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Assigned Lawyer</label>
                            <select class="form-select" name="assigned_lawyer_id">
                                <option value="">Unassigned</option>
                                <?php while($lawyer = $lawyers->fetch_assoc()): ?>
                                    <option value="<?php echo $lawyer['id']; ?>"
                                        <?php echo ($case['assigned_lawyer_id'] == $lawyer['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($lawyer['full_name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" required>
                                <option value="pending" <?php echo $case['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="active" <?php echo $case['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="closed" <?php echo $case['status'] == 'closed' ? 'selected' : ''; ?>>Closed</option>
                                <option value="archived" <?php echo $case['status'] == 'archived' ? 'selected' : ''; ?>>Archived</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Progress: <span id="progressValue"><?php echo $case['progress']; ?></span>%</label>
                            <input type="range" class="form-range" name="progress" min="0" max="100" 
                                   value="<?php echo $case['progress']; ?>" 
                                   oninput="updateProgress(this.value)">
                            <div class="progress-preview">
                                <div class="progress-preview-fill" id="progressPreview" style="width: <?php echo $case['progress']; ?>%"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Next Hearing Section -->
                    <h5 class="section-title mt-4"><i class="fas fa-gavel"></i> Next Hearing Details</h5>
                    
                    <?php if($next_hearing): ?>
                        <div class="current-hearing-alert">
                            <i class="fas fa-info-circle" style="color: #D4AF37;"></i> 
                            <strong>Current Hearing:</strong> 
                            <?php echo date('F d, Y', strtotime($next_hearing['hearing_date'])); ?> at 
                            <?php echo date('g:i A', strtotime($next_hearing['hearing_time'])); ?> - 
                            <?php echo htmlspecialchars($next_hearing['hearing_type'] ?? 'General Hearing'); ?>
                            <br><small class="text-muted">Venue: <?php echo htmlspecialchars($next_hearing['venue']); ?></small>
                        </div>
                    <?php endif; ?>

                    <div class="hearing-info-card">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><i class="fas fa-calendar-alt"></i> Hearing Date</label>
                                <input type="date" class="form-control" name="hearing_date" 
                                       value="<?php echo $next_hearing ? $next_hearing['hearing_date'] : ''; ?>" 
                                       min="<?php echo date('Y-m-d'); ?>">
                                <small class="text-muted">Leave empty if no hearing scheduled</small>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><i class="fas fa-clock"></i> Hearing Time</label>
                                <input type="time" class="form-control" name="hearing_time" 
                                       value="<?php echo $next_hearing ? $next_hearing['hearing_time'] : ''; ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><i class="fas fa-map-marker-alt"></i> Venue / Court</label>
                                <input type="text" class="form-control" name="venue" 
                                       value="<?php echo $next_hearing ? htmlspecialchars($next_hearing['venue']) : ''; ?>" 
                                       placeholder="e.g., Superior Court, Room 302">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label"><i class="fas fa-tag"></i> Hearing Type / Purpose</label>
                                <select class="form-select" name="hearing_type" id="hearing_type_select" onchange="toggleCustomInput('type')">
                                    <option value="">Select Hearing Type...</option>
                                    <option value="initial_hearing" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'initial_hearing') ? 'selected' : ''; ?>>Initial Hearing</option>
                                    <option value="status_conference" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'status_conference') ? 'selected' : ''; ?>>Status Conference</option>
                                    <option value="motion_hearing" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'motion_hearing') ? 'selected' : ''; ?>>Motion Hearing</option>
                                    <option value="evidence_hearing" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'evidence_hearing') ? 'selected' : ''; ?>>Evidence Hearing</option>
                                    <option value="trial" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'trial') ? 'selected' : ''; ?>>Trial</option>
                                    <option value="pre_trial" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'pre_trial') ? 'selected' : ''; ?>>Pre-Trial Conference</option>
                                    <option value="settlement" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'settlement') ? 'selected' : ''; ?>>Settlement Conference</option>
                                    <option value="case_management" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'case_management') ? 'selected' : ''; ?>>Case Management Conference</option>
                                    <option value="oral_arguments" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'oral_arguments') ? 'selected' : ''; ?>>Oral Arguments</option>
                                    <option value="other" <?php echo ($next_hearing && $next_hearing['hearing_type'] == 'other') ? 'selected' : ''; ?>>Other (Enter Custom)</option>
                                </select>
                                <div id="hearing_type_custom_container" style="display: none;" class="custom-input-group">
                                    <input type="text" class="form-control" name="hearing_type_custom" id="hearing_type_custom" 
                                           placeholder="Enter custom hearing type..." value="<?php echo $next_hearing && !in_array($next_hearing['hearing_type'], ['initial_hearing', 'status_conference', 'motion_hearing', 'evidence_hearing', 'trial', 'pre_trial', 'settlement', 'case_management', 'oral_arguments', 'other']) ? htmlspecialchars($next_hearing['hearing_type']) : ''; ?>">
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label"><i class="fas fa-question-circle"></i> Hearing Reason</label>
                                <select class="form-select" name="hearing_reason" id="hearing_reason_select" onchange="toggleCustomInput('reason')">
                                    <option value="">Select Reason...</option>
                                    <option value="discovery" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'discovery') ? 'selected' : ''; ?>>Discovery Dispute</option>
                                    <option value="pleadings" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'pleadings') ? 'selected' : ''; ?>>Pleadings</option>
                                    <option value="witness" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'witness') ? 'selected' : ''; ?>>Witness Examination</option>
                                    <option value="expert_testimony" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'expert_testimony') ? 'selected' : ''; ?>>Expert Testimony</option>
                                    <option value="document_review" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'document_review') ? 'selected' : ''; ?>>Document Review</option>
                                    <option value="sentencing" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'sentencing') ? 'selected' : ''; ?>>Sentencing (Criminal)</option>
                                    <option value="judgment" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'judgment') ? 'selected' : ''; ?>>Final Judgment</option>
                                    <option value="appeal" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'appeal') ? 'selected' : ''; ?>>Appeal Hearing</option>
                                    <option value="mediation" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'mediation') ? 'selected' : ''; ?>>Mediation</option>
                                    <option value="other" <?php echo ($next_hearing && $next_hearing['hearing_reason'] == 'other') ? 'selected' : ''; ?>>Other (Enter Custom)</option>
                                </select>
                                <div id="hearing_reason_custom_container" style="display: none;" class="custom-input-group">
                                    <input type="text" class="form-control" name="hearing_reason_custom" id="hearing_reason_custom" 
                                           placeholder="Enter custom hearing reason..." value="<?php echo $next_hearing && !in_array($next_hearing['hearing_reason'], ['discovery', 'pleadings', 'witness', 'expert_testimony', 'document_review', 'sentencing', 'judgment', 'appeal', 'mediation', 'other']) ? htmlspecialchars($next_hearing['hearing_reason']) : ''; ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-sticky-note"></i> Hearing Notes / Instructions</label>
                            <textarea class="form-control" name="hearing_notes" rows="3" 
                                      placeholder="Any special instructions for the client or legal team..."><?php echo $next_hearing ? htmlspecialchars($next_hearing['notes']) : ''; ?></textarea>
                        </div>

                        <div class="alert alert-info mt-2" style="background: rgba(212,175,55,0.08); border: 1px solid rgba(212,175,55,0.2); border-radius: 10px;">
                            <i class="fas fa-info-circle" style="color: #D4AF37;"></i>
                            <small>Select "Other (Enter Custom)" to type your own hearing type or reason. This field is optional - you can leave it as "Other" if no custom value is needed.</small>
                        </div>
                    </div>

                    <div class="d-flex gap-3 mt-4">
                        <button type="submit" class="btn btn-submit flex-grow-1">
                            <i class="fas fa-save me-2"></i>Update Case
                        </button>
                        <a href="cases.php" class="btn btn-cancel">
                            <i class="fas fa-table-list me-2"></i>View All Cases
                        </a>
                        <a href="<?php echo $dashboard_url; ?>" class="btn btn-dashboard">
                            <i class="fas fa-tachometer-alt me-2"></i>Back to <?php echo $dashboard_name; ?>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function updateProgress(value) {
        document.getElementById('progressValue').innerText = value;
        document.getElementById('progressPreview').style.width = value + '%';
    }
    
    function toggleCustomInput(type) {
        if (type === 'type') {
            const select = document.getElementById('hearing_type_select');
            const container = document.getElementById('hearing_type_custom_container');
            const customInput = document.getElementById('hearing_type_custom');
            
            if (select.value === 'other') {
                container.style.display = 'block';
                customInput.required = false;  // Optional field
            } else {
                container.style.display = 'none';
                customInput.value = '';
            }
        } else if (type === 'reason') {
            const select = document.getElementById('hearing_reason_select');
            const container = document.getElementById('hearing_reason_custom_container');
            const customInput = document.getElementById('hearing_reason_custom');
            
            if (select.value === 'other') {
                container.style.display = 'block';
                customInput.required = false;  // Optional field
            } else {
                container.style.display = 'none';
                customInput.value = '';
            }
        }
    }
    
    // Initialize custom inputs on page load
    document.addEventListener('DOMContentLoaded', function() {
        toggleCustomInput('type');
        toggleCustomInput('reason');
    });
</script>

<?php require_once 'includes/footer.php'; ?>