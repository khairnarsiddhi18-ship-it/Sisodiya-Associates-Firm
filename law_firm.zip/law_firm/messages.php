<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Messages";
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Handle sending new message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $to_user_id = $_POST['to_user_id'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    $stmt = $conn->prepare("INSERT INTO messages (from_user_id, to_user_id, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $user_id, $to_user_id, $subject, $message);
    
    if ($stmt->execute()) {
        $success = "Message sent successfully!";
    } else {
        $error = "Error sending message: " . $conn->error;
    }
}

// Handle marking message as read
if (isset($_GET['read'])) {
    $msg_id = $_GET['read'];
    $conn->query("UPDATE messages SET is_read = 1 WHERE id = $msg_id AND to_user_id = $user_id");
    header("Location: messages.php");
    exit();
}

// Handle deleting message
if (isset($_GET['delete'])) {
    $msg_id = $_GET['delete'];
    $conn->query("DELETE FROM messages WHERE id = $msg_id AND (from_user_id = $user_id OR to_user_id = $user_id)");
    header("Location: messages.php");
    exit();
}

// Get unread count
$unread_result = $conn->query("SELECT COUNT(*) as total FROM messages WHERE to_user_id = $user_id AND is_read = 0");
$unread_count = $unread_result->fetch_assoc()['total'];

// Get conversations (unique users the current user has exchanged messages with)
$conversations = $conn->query("
    SELECT DISTINCT 
        CASE 
            WHEN m.from_user_id = $user_id THEN m.to_user_id
            ELSE m.from_user_id
        END as other_user_id,
        u.full_name,
        u.role,
        u.id as user_id,
        (SELECT message FROM messages WHERE 
            (from_user_id = $user_id AND to_user_id = other_user_id) OR 
            (from_user_id = other_user_id AND to_user_id = $user_id) 
         ORDER BY created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM messages WHERE 
            (from_user_id = $user_id AND to_user_id = other_user_id) OR 
            (from_user_id = other_user_id AND to_user_id = $user_id) 
         ORDER BY created_at DESC LIMIT 1) as last_message_time,
        (SELECT COUNT(*) FROM messages WHERE to_user_id = $user_id AND from_user_id = other_user_id AND is_read = 0) as unread_from_this
    FROM messages m
    JOIN users u ON (CASE WHEN m.from_user_id = $user_id THEN m.to_user_id ELSE m.from_user_id END) = u.id
    WHERE m.from_user_id = $user_id OR m.to_user_id = $user_id
    ORDER BY last_message_time DESC
");

// Get messages for selected conversation
$selected_user = isset($_GET['user']) ? (int)$_GET['user'] : 0;
$messages = null;
$selected_user_info = null;

if ($selected_user) {
    // Mark messages from this user as read
    $conn->query("UPDATE messages SET is_read = 1 WHERE from_user_id = $selected_user AND to_user_id = $user_id");
    
    // Get messages between users
    $messages = $conn->query("
        SELECT m.*, 
               u_from.full_name as from_name, u_from.role as from_role,
               u_to.full_name as to_name, u_to.role as to_role
        FROM messages m
        JOIN users u_from ON m.from_user_id = u_from.id
        JOIN users u_to ON m.to_user_id = u_to.id
        WHERE (m.from_user_id = $user_id AND m.to_user_id = $selected_user) 
           OR (m.from_user_id = $selected_user AND m.to_user_id = $user_id)
        ORDER BY m.created_at ASC
    ");
    
    // Get selected user info
    $user_info = $conn->query("SELECT full_name, role, email FROM users WHERE id = $selected_user");
    $selected_user_info = $user_info->fetch_assoc();
    
    // Update unread count
    $unread_result = $conn->query("SELECT COUNT(*) as total FROM messages WHERE to_user_id = $user_id AND is_read = 0");
    $unread_count = $unread_result->fetch_assoc()['total'];
}

// Get users that current user can message (based on role)
$allowed_users = [];
if ($user_role == 'client') {
    // Client can message their lawyer and paralegals
    $lawyers = $conn->query("SELECT id, full_name, role FROM users WHERE role IN ('lawyer', 'paralegal') AND is_active = 1");
    while($user = $lawyers->fetch_assoc()) {
        $allowed_users[] = $user;
    }
} elseif ($user_role == 'lawyer') {
    // Lawyer can message clients, paralegals, admin
    $users = $conn->query("SELECT id, full_name, role FROM users WHERE role IN ('client', 'paralegal', 'admin') AND is_active = 1");
    while($user = $users->fetch_assoc()) {
        $allowed_users[] = $user;
    }
} else {
    // Admin/Paralegal can message everyone
    $users = $conn->query("SELECT id, full_name, role FROM users WHERE is_active = 1 AND id != $user_id");
    while($user = $users->fetch_assoc()) {
        $allowed_users[] = $user;
    }
}

require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
    }

    body {
        background: var(--light);
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    .messages-container {
        max-width: 1400px;
        margin: 100px auto 30px;
        background: white;
        border-radius: 25px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        overflow: hidden;
        display: flex;
        min-height: 650px;
    }

    /* Conversations Sidebar */
    .conversations-sidebar {
        width: 320px;
        background: linear-gradient(180deg, #FDF8F0 0%, #fff 100%);
        border-right: 1px solid rgba(212, 175, 55, 0.2);
        display: flex;
        flex-direction: column;
    }

    .sidebar-header {
        padding: 20px;
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
    }

    .sidebar-header h5 i {
        color: var(--secondary);
    }

    .conversation-list {
        flex: 1;
        overflow-y: auto;
    }

    .conversation-item {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        cursor: pointer;
        transition: all 0.3s;
        position: relative;
    }

    .conversation-item:hover {
        background: rgba(212, 175, 55, 0.08);
    }

    .conversation-item.active {
        background: rgba(212, 175, 55, 0.12);
        border-left: 3px solid var(--secondary);
    }

    .conversation-name {
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 5px;
    }

    .conversation-name .badge {
        background: var(--secondary) !important;
        color: var(--primary-dark);
        font-size: 10px;
    }

    .conversation-last-msg {
        font-size: 0.85rem;
        color: #6c757d;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .conversation-time {
        font-size: 0.7rem;
        color: #999;
        position: absolute;
        right: 20px;
        top: 15px;
    }

    .unread-badge {
        background: #C72A2A;
        color: white;
        border-radius: 50px;
        padding: 2px 8px;
        font-size: 0.7rem;
        font-weight: 600;
        margin-left: 10px;
    }

    /* Chat Area */
    .chat-area {
        flex: 1;
        display: flex;
        flex-direction: column;
        background: white;
    }

    .chat-header {
        padding: 20px;
        background: white;
        border-bottom: 1px solid rgba(212, 175, 55, 0.2);
    }

    .chat-header h5 {
        color: var(--primary-dark);
        font-weight: 700;
    }

    .messages-list {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        background: var(--light);
    }

    .message {
        margin-bottom: 20px;
        display: flex;
    }

    .message.sent {
        justify-content: flex-end;
    }

    .message.received {
        justify-content: flex-start;
    }

    .message-bubble {
        max-width: 70%;
        padding: 12px 18px;
        border-radius: 20px;
        position: relative;
    }

    .message.sent .message-bubble {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        color: var(--primary-dark);
        border-bottom-right-radius: 5px;
    }

    .message.received .message-bubble {
        background: white;
        border: 1px solid rgba(212, 175, 55, 0.3);
        color: #2d3748;
        border-bottom-left-radius: 5px;
    }

    .message-meta {
        font-size: 0.7rem;
        margin-top: 5px;
        opacity: 0.7;
    }

    .message.sent .message-meta {
        color: var(--primary-dark);
    }

    .message-input-area {
        padding: 20px;
        background: white;
        border-top: 1px solid rgba(212, 175, 55, 0.2);
    }

    .message-input-area .input-group textarea,
    .message-input-area .input-group input {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px 15px;
        transition: all 0.3s;
    }

    .message-input-area .input-group textarea:focus,
    .message-input-area .input-group input:focus {
        border-color: var(--secondary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
    }

    .message-input-area .btn-primary {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        color: var(--primary-dark);
        font-weight: 600;
        border-radius: 12px;
        padding: 10px 25px;
    }

    .message-input-area .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .new-message-btn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        color: var(--primary-dark);
        font-size: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        transition: all 0.3s;
        z-index: 1000;
    }

    .new-message-btn:hover {
        transform: scale(1.1);
    }

    /* Modal Styles */
    .modal-header {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
        border: none;
    }

    .modal-header .btn-close {
        background: white;
        opacity: 1;
    }

    .modal-title i {
        color: var(--secondary);
    }

    .modal-footer .btn-primary {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        color: var(--primary-dark);
        font-weight: 600;
    }

    .modal-footer .btn-secondary {
        background: #6c757d;
        border: none;
    }

    /* Scrollbar */
    .messages-list::-webkit-scrollbar,
    .conversation-list::-webkit-scrollbar {
        width: 6px;
    }

    .messages-list::-webkit-scrollbar-track,
    .conversation-list::-webkit-scrollbar-track {
        background: #e2e8f0;
        border-radius: 3px;
    }

    .messages-list::-webkit-scrollbar-thumb,
    .conversation-list::-webkit-scrollbar-thumb {
        background: var(--secondary);
        border-radius: 3px;
    }

    @media (max-width: 768px) {
        .conversations-sidebar {
            width: 100%;
            position: absolute;
            z-index: 10;
            transform: translateX(-100%);
            transition: transform 0.3s;
        }
        
        .conversations-sidebar.show {
            transform: translateX(0);
        }
        
        .messages-container {
            margin: 70px 10px 10px;
        }

        .message-bubble {
            max-width: 85%;
        }
    }
</style>

<div class="messages-container">
    <!-- Conversations Sidebar -->
    <div class="conversations-sidebar" id="conversationsSidebar">
        <div class="sidebar-header">
            <h5 class="mb-0"><i class="fas fa-envelope me-2"></i> Messages</h5>
            <?php if($unread_count > 0): ?>
                <small class="text-white-50"><?php echo $unread_count; ?> unread messages</small>
            <?php endif; ?>
        </div>
        <div class="conversation-list">
            <?php if($conversations && $conversations->num_rows > 0): ?>
                <?php while($conv = $conversations->fetch_assoc()): ?>
                    <div class="conversation-item <?php echo ($selected_user == $conv['other_user_id']) ? 'active' : ''; ?>" 
                         onclick="window.location.href='messages.php?user=<?php echo $conv['other_user_id']; ?>'">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="conversation-name">
                                    <?php echo htmlspecialchars($conv['full_name']); ?>
                                    <span class="badge ms-1"><?php echo ucfirst($conv['role']); ?></span>
                                    <?php if($conv['unread_from_this'] > 0): ?>
                                        <span class="unread-badge"><?php echo $conv['unread_from_this']; ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="conversation-last-msg">
                                    <?php echo substr(htmlspecialchars($conv['last_message']), 0, 40); ?>
                                </div>
                            </div>
                            <div class="conversation-time">
                                <?php echo date('M d', strtotime($conv['last_message_time'])); ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center text-muted p-4">
                    <i class="fas fa-inbox fa-3x mb-3 d-block" style="color: var(--secondary); opacity: 0.5;"></i>
                    <p>No conversations yet</p>
                    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#newMessageModal">
                        Start a conversation
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Chat Area -->
    <div class="chat-area">
        <?php if($selected_user && $selected_user_info): ?>
            <div class="chat-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0"><?php echo htmlspecialchars($selected_user_info['full_name']); ?></h5>
                        <small class="text-muted"><?php echo ucfirst($selected_user_info['role']); ?> • <?php echo $selected_user_info['email']; ?></small>
                    </div>
                    <button class="btn btn-sm" style="border: 1px solid var(--secondary); color: var(--primary-dark);" onclick="toggleSidebar()">
                        <i class="fas fa-users"></i> Conversations
                    </button>
                </div>
            </div>
            
            <div class="messages-list" id="messagesList">
                <?php if($messages && $messages->num_rows > 0): ?>
                    <?php while($msg = $messages->fetch_assoc()): ?>
                        <div class="message <?php echo ($msg['from_user_id'] == $user_id) ? 'sent' : 'received'; ?>">
                            <div class="message-bubble">
                                <?php if($msg['subject']): ?>
                                    <strong><?php echo htmlspecialchars($msg['subject']); ?></strong><br>
                                <?php endif; ?>
                                <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                <div class="message-meta">
                                    <?php echo date('M d, Y g:i A', strtotime($msg['created_at'])); ?>
                                    <?php if($msg['from_user_id'] == $user_id): ?>
                                        <?php if($msg['is_read']): ?>
                                            <i class="fas fa-check-double" style="color: #10b981;" title="Read"></i>
                                        <?php else: ?>
                                            <i class="fas fa-check" style="color: var(--secondary);" title="Sent"></i>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center text-muted mt-5">
                        <i class="fas fa-comment-dots fa-4x mb-3" style="color: var(--secondary); opacity: 0.5;"></i>
                        <p>No messages yet. Send a message to start the conversation!</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="message-input-area">
                <form method="POST" id="replyForm">
                    <input type="hidden" name="to_user_id" value="<?php echo $selected_user; ?>">
                    <div class="input-group">
                        <input type="text" class="form-control" name="subject" placeholder="Subject (optional)" style="max-width: 200px;">
                        <textarea class="form-control" name="message" rows="2" placeholder="Type your message here..." required></textarea>
                        <button type="submit" name="send_message" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Send
                        </button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="d-flex align-items-center justify-content-center h-100 text-center">
                <div>
                    <i class="fas fa-envelope-open-text fa-5x mb-4" style="color: var(--secondary); opacity: 0.5;"></i>
                    <h4 style="color: var(--primary-dark);">Select a conversation</h4>
                    <p class="text-muted">Choose a conversation from the sidebar or start a new one</p>
                    <button class="btn" style="background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); color: var(--primary-dark); border: none; padding: 10px 25px; border-radius: 12px;" data-bs-toggle="modal" data-bs-target="#newMessageModal">
                        <i class="fas fa-plus"></i> New Message
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- New Message Modal -->
<div class="modal fade" id="newMessageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i> New Message</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">To:</label>
                        <select class="form-select" name="to_user_id" required>
                            <option value="">Select recipient...</option>
                            <?php foreach($allowed_users as $user): ?>
                                <option value="<?php echo $user['id']; ?>" <?php echo ($selected_user == $user['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($user['full_name']); ?> (<?php echo ucfirst($user['role']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject:</label>
                        <input type="text" class="form-control" name="subject" placeholder="Brief subject line">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message:</label>
                        <textarea class="form-control" name="message" rows="5" placeholder="Type your message here..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="send_message" class="btn btn-primary">Send Message</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Floating Action Button for Mobile -->
<button class="new-message-btn d-md-none" data-bs-toggle="modal" data-bs-target="#newMessageModal">
    <i class="fas fa-plus"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Auto-scroll to bottom of messages
    const messagesList = document.getElementById('messagesList');
    if(messagesList) {
        messagesList.scrollTop = messagesList.scrollHeight;
    }
    
    // Auto-refresh messages every 10 seconds
    let autoRefresh = setInterval(function() {
        const currentUser = <?php echo $selected_user; ?>;
        if(currentUser > 0) {
            $.ajax({
                url: 'get_messages.php',
                method: 'GET',
                data: { user: currentUser, last_check: Date.now() },
                success: function(response) {
                    if(response.new_messages) {
                        location.reload();
                    }
                }
            });
        }
    }, 10000);
    
    function toggleSidebar() {
        document.getElementById('conversationsSidebar').classList.toggle('show');
    }
    
    // Stop auto-refresh on page unload
    window.addEventListener('beforeunload', function() {
        clearInterval(autoRefresh);
    });
</script>

<?php require_once 'includes/footer.php'; ?>