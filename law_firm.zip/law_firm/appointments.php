<?php
session_start();
require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $conn->prepare("INSERT INTO appointments (client_id, lawyer_id, appointment_date, appointment_time, notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $_SESSION['user_id'], $_POST['lawyer_id'], $_POST['appointment_date'], $_POST['appointment_time'], $_POST['notes']);
    $stmt->execute();
}
header("Location: client_dashboard.php");
?>