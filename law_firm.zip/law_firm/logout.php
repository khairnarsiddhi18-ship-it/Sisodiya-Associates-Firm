<?php
session_start();
require_once 'config/database.php';

// Log logout
if(isset($_SESSION['user_id'])) {
    $log = $conn->prepare("INSERT INTO system_logs (user_id, action) VALUES (?, 'logout')");
    $log->bind_param("i", $_SESSION['user_id']);
    $log->execute();
}

session_destroy();
header("Location: index.php");
exit();
?>