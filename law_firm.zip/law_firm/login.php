<?php
session_start();
require_once 'config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if it's forgot password request
    if (isset($_POST['forgot_password'])) {
        $email = $_POST['email'];
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT id, full_name, role FROM users WHERE email = ? AND is_active = 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database
            $insert_token = $conn->prepare("INSERT INTO password_resets (user_id, token, expiry) VALUES (?, ?, ?) 
                                           ON DUPLICATE KEY UPDATE token = ?, expiry = ?");
            $insert_token->bind_param("issss", $user['id'], $token, $expiry, $token, $expiry);
            $insert_token->execute();
            
            // In a real application, send email here
            // For demo, we'll show the reset link
            $reset_link = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/reset_password.php?token=" . $token;
            
            $success = "Password reset link has been generated! <br><small class='text-muted'>Demo Link: <a href='$reset_link' target='_blank'>Click here to reset password</a></small>";
        } else {
            $error = "No account found with this email address!";
        }
    }
    // Regular login
    else {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $role = $_POST['role'];
        
        // Map form role to database role
        $role_mapping = [
            'admin' => 'admin',
            'lawyer' => 'lawyer',
            'client' => 'client',
            'paralegal' => 'paralegal',
            'bookkeeper' => 'bookkeeper'
        ];
        
        $db_role = $role_mapping[$role] ?? $role;
        
        // First, check if user exists with this email and role
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = ? AND is_active = 1");
        $stmt->bind_param("ss", $email, $db_role);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            // Check password (supports both MD5 and password_hash)
            $password_valid = false;
            
            // Check if using MD5
            if ($user['password_hash'] === md5($password)) {
                $password_valid = true;
            }
            // Check if using password_hash
            elseif (password_verify($password, $user['password_hash'])) {
                $password_valid = true;
            }
            
            if ($password_valid) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_username'] = $user['username'];
                
                // Log the login
                $log = $conn->prepare("INSERT INTO system_logs (user_id, action, ip_address) VALUES (?, 'login', ?)");
                $ip = $_SERVER['REMOTE_ADDR'];
                $log->bind_param("is", $user['id'], $ip);
                $log->execute();
                
                // Redirect based on role
                switch($user['role']) {
                    case 'admin': 
                        header("Location: admin/admin_dashboard.php"); 
                        break;
                    case 'lawyer': 
                        header("Location: lawyer/lawyer_dashboard.php"); 
                        break;
                    case 'client': 
                        header("Location: client/client_dashboard.php"); 
                        break;
                    case 'paralegal': 
                        header("Location: paralegal/paralegal_dashboard.php"); 
                        break;
                    case 'bookkeeper': 
                        header("Location: bookkeeper/bookkeeper_dashboard.php"); 
                        break;
                    default: 
                        header("Location: dashboard.php");
                }
                exit();
            } else {
                $error = "Invalid password!";
            }
        } else {
            // Check if user exists with different role
            $check_user = $conn->prepare("SELECT role FROM users WHERE email = ?");
            $check_user->bind_param("s", $email);
            $check_user->execute();
            $check_result = $check_user->get_result();
            
            if ($check_result->num_rows > 0) {
                $existing = $check_result->fetch_assoc();
                $error = "Account exists but with role: " . ucfirst($existing['role']) . ". Please select correct role.";
            } else {
                $error = "No account found with these credentials!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Sisodiya Associates</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Gradient Background */
        .gradient-bg {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 0;
        }

        .gradient-bg::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            top: -50%;
            left: -50%;
            background: radial-gradient(circle, rgba(212,175,55,0.08) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: moveGrid 20s linear infinite;
        }

        @keyframes moveGrid {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        /* Floating Particles */
        .particle {
            position: absolute;
            background: rgba(212, 175, 55, 0.15);
            border-radius: 50%;
            pointer-events: none;
            animation: floatParticle linear infinite;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% {
                transform: translateY(-100vh) rotate(360deg);
                opacity: 0;
            }
        }

        /* Main Container */
        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        /* Login Card */
        .login-card {
            display: flex;
            max-width: 1200px;
            width: 100%;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 40px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            animation: slideIn 0.6s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Left Side - Brand Section (Burgundy Theme) */
        .brand-section {
            flex: 1;
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            padding: 50px;
            color: white;
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .brand-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(212,175,55,0.15) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .logo {
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
            text-align: center;
        }

        /* Logo Image - Round Circle */
        .logo-image-container {
            width: 120px;
            height: 120px;
            margin: 0 auto 25px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-image {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #D4AF37;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            transition: all 0.3s;
            background: white;
        }

        .logo-image:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
        }

        /* Fallback if image doesn't exist */
        .logo-fallback {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid #D4AF37;
        }

        .logo-fallback i {
            font-size: 50px;
            color: #4A0E17;
        }

        .brand-section h1 {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 15px;
            position: relative;
            z-index: 1;
            text-align: center;
        }

        .brand-section h1 span {
            color: #D4AF37;
        }

        .brand-section p {
            font-size: 16px;
            opacity: 0.9;
            line-height: 1.6;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
            text-align: center;
        }

        .features {
            position: relative;
            z-index: 1;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }

        .feature-icon {
            width: 40px;
            height: 40px;
            background: rgba(212, 175, 55, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: #D4AF37;
        }

        .feature-text {
            font-size: 14px;
        }

        .feature-text strong {
            display: block;
            margin-bottom: 3px;
        }

        /* Right Side - Form Section */
        .form-section {
            flex: 1;
            padding: 50px;
            background: white;
        }

        .form-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .form-header h2 {
            font-size: 28px;
            font-weight: 800;
            color: #4A0E17;
            margin-bottom: 8px;
        }

        .form-header p {
            color: #718096;
            font-size: 14px;
        }

        /* Form Styles */
        .input-group {
            margin-bottom: 25px;
        }

        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 13px;
            color: #4A0E17;
        }

        .input-label i {
            margin-right: 8px;
            color: #D4AF37;
        }

        .input-field {
            position: relative;
        }

        .input-field input,
        .input-field select {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 16px;
            font-size: 14px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            transition: all 0.3s;
            background: white;
        }

        .input-field select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%234A0E17'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            background-size: 20px;
        }

        .input-field input:focus,
        .input-field select:focus {
            outline: none;
            border-color: #D4AF37;
            box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.1);
        }

        /* Role Badge */
        .role-badge {
            display: inline-block;
            margin-top: 8px;
            padding: 4px 12px;
            background: #FDF8F0;
            border-radius: 20px;
            font-size: 11px;
            color: #4A0E17;
        }

        .role-badge i {
            margin-right: 5px;
            font-size: 10px;
            color: #D4AF37;
        }

        /* Password Toggle */
        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #a0aec0;
            transition: color 0.3s;
            z-index: 2;
            background: white;
            padding-left: 8px;
        }

        .password-toggle:hover {
            color: #D4AF37;
        }

        /* Login Button - Gold Gradient */
        .login-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            border-radius: 16px;
            color: #4A0E17;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
            position: relative;
            overflow: hidden;
        }

        .login-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }

        .login-btn:hover::before {
            left: 100%;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(212, 175, 55, 0.4);
        }

        /* Forgot Password Link */
        .forgot-password {
            text-align: right;
            margin-top: 8px;
        }

        .forgot-password a {
            color: #D4AF37;
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .forgot-password a:hover {
            color: #4A0E17;
            text-decoration: underline;
        }

        /* Register Link */
        .register-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .register-link a {
            color: #D4AF37;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: color 0.3s;
        }

        .register-link a:hover {
            color: #4A0E17;
        }

        /* Error Alert */
        .alert-error {
            background: #fed7d7;
            border-left: 4px solid #C72A2A;
            color: #c53030;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            animation: shake 0.5s ease-out;
        }

        /* Success Alert */
        .alert-success {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Forgot Password Modal */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .forgot-modal {
            background: white;
            border-radius: 30px;
            max-width: 450px;
            width: 90%;
            padding: 30px;
            transform: scale(0.9);
            transition: transform 0.3s;
        }

        .modal-overlay.active .forgot-modal {
            transform: scale(1);
        }

        .forgot-modal h3 {
            color: #4A0E17;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .forgot-modal p {
            color: #718096;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .modal-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }

        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e2e8f0;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-cancel:hover {
            background: #cbd5e0;
        }

        .btn-submit {
            flex: 1;
            padding: 12px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            border-radius: 12px;
            font-weight: 600;
            color: #4A0E17;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
        }

        /* Loading State */
        .login-btn.loading {
            pointer-events: none;
            opacity: 0.7;
        }

        .login-btn.loading::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            top: 50%;
            right: 20px;
            margin-top: -9px;
            border: 2px solid #4A0E17;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .brand-section {
                display: none;
            }
            
            .form-section {
                flex: 1;
            }
            
            .login-card {
                max-width: 500px;
            }
        }

        @media (max-width: 480px) {
            .form-section {
                padding: 30px 25px;
            }
            
            .form-header h2 {
                font-size: 24px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #D4AF37;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<div class="gradient-bg"></div>

<!-- Floating Particles -->
<script>
    function createParticles() {
        const particleCount = 50;
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            const size = Math.random() * 4 + 2;
            particle.style.width = size + 'px';
            particle.style.height = size + 'px';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDuration = Math.random() * 10 + 10 + 's';
            particle.style.animationDelay = Math.random() * 10 + 's';
            document.body.appendChild(particle);
        }
    }
    createParticles();
</script>

<!-- Forgot Password Modal -->
<div class="modal-overlay" id="forgotModal">
    <div class="forgot-modal">
        <h3><i class="fas fa-key" style="color: #D4AF37;"></i> Forgot Password?</h3>
        <p>Enter your email address and we'll send you a link to reset your password.</p>
        <form method="POST" id="forgotForm">
            <div class="input-field">
                <input type="email" name="email" id="reset_email" placeholder="Enter your registered email" required style="width: 100%;">
            </div>
            <div class="modal-buttons">
                <button type="button" class="btn-cancel" onclick="closeForgotModal()">Cancel</button>
                <button type="submit" name="forgot_password" class="btn-submit">Send Reset Link</button>
            </div>
        </form>
    </div>
</div>

<div class="login-wrapper">
    <div class="login-card">
        <!-- Left Side - Brand Section (Burgundy Theme) -->
        <div class="brand-section">
            <div class="logo">
                <div class="logo-image-container">
                    <?php 
                    // Check if logo image exists
                    $logo_path = 'assets/logo.jpeg';
                    if (file_exists($logo_path)): 
                    ?>
                        <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="logo-image">
                    <?php else: ?>
                        <div class="logo-fallback">
                            <i class="fas fa-gavel"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <h1>Sisodiya<br><span>Associates</span></h1>
                <p>Excellence in legal representation since 1998</p>
            </div>
            
            <div class="features">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="feature-text">
                        <strong>Award Winning</strong>
                        <span>Recognized as top law firm 2026</span>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="feature-text">
                        <strong>50+ Attorneys</strong>
                        <span>Experts across multiple domains</span>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="feature-text">
                        <strong>24/7 Support</strong>
                        <span>Always here for your legal needs</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Form Section -->
        <div class="form-section">
            <div class="form-header">
                <h2>Welcome Back</h2>
                <p>Sign in to access your dashboard</p>
            </div>

            <?php if($error): ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if($success): ?>
                <div class="alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" id="loginForm">
                <div class="input-group">
                    <label class="input-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <div class="input-field">
                        <input type="email" name="email" id="email" 
                               placeholder="Enter your email" required autocomplete="off">
                    </div>
                </div>

                <div class="input-group">
                    <label class="input-label">
                        <i class="fas fa-user-tag"></i> Login As
                    </label>
                    <div class="input-field">
                        <select name="role" id="role" required>
                            <option value="">Select your role</option>
                            <option value="admin">Administrator</option>
                            <option value="lawyer">Lawyer</option>
                            <option value="client">Client</option>
                            <option value="paralegal">Paralegal</option>
                            <option value="bookkeeper">Book Keeper</option>
                        </select>
                    </div>
                    <div class="role-badge" id="roleHint">
                        <i class="fas fa-info-circle"></i> Select the role you registered with
                    </div>
                </div>

                <div class="input-group">
                    <label class="input-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="input-field">
                        <input type="password" name="password" id="password" 
                               placeholder="Enter your password" required>
                        <span class="password-toggle" onclick="togglePassword()">
                            <i class="far fa-eye" id="toggleIcon"></i>
                        </span>
                    </div>
                </div>

                <!-- Forgot Password Link -->
                <div class="forgot-password">
                    <a href="javascript:void(0)" onclick="openForgotModal()">
                        <i class="fas fa-key"></i> Forgot Password?
                    </a>
                </div>

                <button type="submit" class="login-btn" id="loginBtn">
                    <i class="fas fa-arrow-right-to-bracket"></i> Sign In
                </button>
            </form>

            <div class="register-link">
                <a href="register.php">
                    <i class="fas fa-user-plus"></i> Don't have an account? Register here
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    // Toggle password visibility
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }
    
    // Forgot Password Modal Functions
    function openForgotModal() {
        document.getElementById('forgotModal').classList.add('active');
        document.getElementById('reset_email').focus();
    }
    
    function closeForgotModal() {
        document.getElementById('forgotModal').classList.remove('active');
        document.getElementById('reset_email').value = '';
    }
    
    // Close modal when clicking outside
    document.getElementById('forgotModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeForgotModal();
        }
    });
    
    // Update role hint on role change
    document.getElementById('role').addEventListener('change', function() {
        const roleHint = document.getElementById('roleHint');
        const selectedRole = this.value;
        
        const roleMessages = {
            'admin': 'Administrator with full system access',
            'lawyer': 'Manage cases, clients, and legal documents',
            'client': 'View your cases, documents, and billing',
            'paralegal': 'Manage research, documents, and client intake',
            'bookkeeper': 'Handle invoices, payments, and financial reports'
        };
        
        if (selectedRole && roleMessages[selectedRole]) {
            roleHint.innerHTML = '<i class="fas fa-info-circle"></i> ' + roleMessages[selectedRole];
            roleHint.style.background = '#FDF8F0';
        } else {
            roleHint.innerHTML = '<i class="fas fa-info-circle"></i> Select the role you registered with';
            roleHint.style.background = '';
        }
    });
    
    // Loading state on form submit
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        const email = document.getElementById('email').value;
        const role = document.getElementById('role').value;
        const password = document.getElementById('password').value;
        
        if (!email || !role || !password) {
            e.preventDefault();
            return;
        }
        
        const btn = document.getElementById('loginBtn');
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
    });
    
    // Input focus effects
    document.querySelectorAll('input, select').forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.01)';
        });
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
    
    // Enter key submit
    document.getElementById('password').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('loginForm').submit();
        }
    });
    
    // For forgot form submission
    document.getElementById('forgotForm').addEventListener('submit', function() {
        const btn = document.querySelector('#forgotForm .btn-submit');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        btn.disabled = true;
    });
</script>
</body>
</html>