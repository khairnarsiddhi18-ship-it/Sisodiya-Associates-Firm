<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user name with fallback
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Admin';

// Get metrics
$metrics = [];
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'lawyer' AND is_active = 1");
$metrics['active_lawyers'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'client' AND is_active = 1");
$metrics['total_clients'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM system_logs WHERE DATE(created_at) = CURDATE()");
$metrics['today_logs'] = $result->fetch_assoc()['total'];

// Get monthly earnings
$earnings = [];
for($i=1; $i<=12; $i++) {
    $earnings[$i] = 0;
}
$result = $conn->query("SELECT MONTH(paid_date) as month, SUM(amount) as total FROM invoices WHERE status = 'paid' AND YEAR(paid_date) = YEAR(CURDATE()) GROUP BY MONTH(paid_date)");
while($row = $result->fetch_assoc()) {
    $earnings[$row['month']] = $row['total'];
}

// Get additional metrics
$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE status = 'active'");
$metrics['active_cases'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE status = 'pending' OR status = 'overdue'");
$metrics['pending_invoices'] = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = CURDATE()");
$metrics['new_today'] = $result->fetch_assoc()['total'];

// Get practice areas count
$result = $conn->query("SELECT COUNT(*) as total FROM practice_areas WHERE is_active = 1");
$metrics['practice_areas'] = $result->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --accent: #8B2635;
            --light: #FDF8F0;
            --dark: #2D0A10;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--light);
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 70px 0 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        /* Sidebar Logo Section */
        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-image {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            background: white;
        }

        .sidebar-logo-image:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding-top: 70px;
        }

        /* Stat Cards */
        .stat-card {
            border-radius: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
            overflow: hidden;
            position: relative;
            border: none;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        .stat-card .card-body {
            padding: 1.5rem;
        }

        .stat-icon {
            position: absolute;
            right: 20px;
            bottom: 20px;
            font-size: 3rem;
            opacity: 0.15;
        }

        /* Gradient Cards */
        .bg-lawyers {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
        }
        .bg-clients {
            background: linear-gradient(135deg, #6B1A2A 0%, #8B2635 100%);
        }
        .bg-cases {
            background: linear-gradient(135deg, #8B2635 0%, #4A0E17 100%);
        }
        .bg-invoices {
            background: linear-gradient(135deg, #D4AF37 0%, #F5D76E 100%);
            color: var(--primary-dark);
        }
        .bg-invoices h6, .bg-invoices h2, .bg-invoices small {
            color: var(--primary-dark);
        }
        .bg-practice-areas {
            background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
            color: white;
        }

        /* Card Headers */
        .card-header-custom {
            background: white;
            border-bottom: 2px solid rgba(212, 175, 55, 0.2);
            padding: 15px 20px;
        }

        .card-header-custom h5 {
            color: var(--primary-dark);
            font-weight: 700;
            margin: 0;
        }

        .card-header-custom h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        /* Buttons */
        .btn-outline-primary-custom {
            border: 1px solid var(--secondary);
            color: var(--primary-dark);
            background: transparent;
            transition: all 0.3s;
        }

        .btn-outline-primary-custom:hover {
            background: var(--secondary);
            color: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-outline-success-custom {
            border: 1px solid #10b981;
            color: #10b981;
            background: transparent;
            transition: all 0.3s;
        }

        .btn-outline-success-custom:hover {
            background: #10b981;
            color: white;
            transform: translateY(-2px);
        }

        .btn-outline-info-custom {
            border: 1px solid #3b82f6;
            color: #3b82f6;
            background: transparent;
            transition: all 0.3s;
        }

        .btn-outline-info-custom:hover {
            background: #3b82f6;
            color: white;
            transform: translateY(-2px);
        }

        .btn-outline-warning-custom {
            border: 1px solid #f59e0b;
            color: #f59e0b;
            background: transparent;
            transition: all 0.3s;
        }

        .btn-outline-warning-custom:hover {
            background: #f59e0b;
            color: white;
            transform: translateY(-2px);
        }

        /* Activity Log */
        .activity-item {
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            padding-bottom: 10px;
            margin-bottom: 10px;
        }

        .activity-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--secondary);
            border-radius: 4px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
                padding-top: 70px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-admin fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand text-white fw-bold fs-4" href="#">
                <i class="fas fa-gavel me-2" style="color: var(--secondary);"></i>Sisodiya Associates
            </a>
            <div class="dropdown">
                <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                    <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                    <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="position-sticky pt-3">
                    <!-- Logo Section -->
                   
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="lawyer_management.php">
                                <i class="fas fa-gavel"></i> Lawyer Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_attorneys.php">
                                <i class="fas fa-user-tie"></i> Manage Attorneys
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_practice_areas.php">
                                <i class="fas fa-briefcase"></i> Practice Areas
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="client_master.php">
                                <i class="fas fa-user-friends"></i> Client Master
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_contact.php">
                                <i class="fas fa-address-card"></i> Contact Info
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="analytics.php">
                                <i class="fas fa-chart-line"></i> Analytics
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../cases.php">
                                <i class="fas fa-briefcase"></i> All Cases
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../invoices.php">
                                <i class="fas fa-file-invoice-dollar"></i> Invoices
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <hr style="border-color: rgba(212,175,55,0.3);">
                            <a class="nav-link" href="../profile.php">
                                <i class="fas fa-user-circle"></i> Profile Settings
                            </a>
                            <a class="nav-link" href="../logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4 main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <div>
                        <h1 class="h2" style="color: var(--primary-dark);">Dashboard</h1>
                        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($user_name); ?>!</p>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm" style="border: 1px solid var(--secondary); color: var(--primary-dark);" onclick="window.location.reload()">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                            <button type="button" class="btn btn-sm" style="border: 1px solid var(--secondary); color: var(--primary-dark);" onclick="window.print()">
                                <i class="fas fa-print"></i> Print
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Metrics Row -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card text-white bg-lawyers">
                            <div class="card-body">
                                <h6 class="card-title">Active Lawyers</h6>
                                <h2 class="mb-0"><?php echo $metrics['active_lawyers']; ?></h2>
                                <small><i class="fas fa-user-tie"></i> Currently practicing</small>
                                <i class="fas fa-gavel stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card text-white bg-clients">
                            <div class="card-body">
                                <h6 class="card-title">Total Clients</h6>
                                <h2 class="mb-0"><?php echo $metrics['total_clients']; ?></h2>
                                <small><i class="fas fa-user-plus"></i> Registered clients</small>
                                <i class="fas fa-users stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card text-white bg-cases">
                            <div class="card-body">
                                <h6 class="card-title">Active Cases</h6>
                                <h2 class="mb-0"><?php echo $metrics['active_cases']; ?></h2>
                                <small><i class="fas fa-briefcase"></i> In progress</small>
                                <i class="fas fa-gavel stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card bg-invoices">
                            <div class="card-body">
                                <h6 class="card-title">Pending Invoices</h6>
                                <h2 class="mb-0">₹<?php echo number_format($metrics['pending_invoices'], 2); ?></h2>
                                <small><i class="fas fa-clock"></i> Awaiting payment</small>
                                <i class="fas fa-rupee-sign stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Second Row Metrics -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="card stat-card bg-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">System Logs (Today)</h6>
                                        <h3 class="mb-0" style="color: var(--primary-dark);"><?php echo $metrics['today_logs']; ?></h3>
                                    </div>
                                    <i class="fas fa-chart-line fa-2x" style="color: var(--secondary);"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card stat-card bg-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">New Today</h6>
                                        <h3 class="mb-0" style="color: var(--primary-dark);"><?php echo $metrics['new_today']; ?></h3>
                                    </div>
                                    <i class="fas fa-user-plus fa-2x" style="color: #10b981;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card stat-card bg-practice-areas">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Practice Areas</h6>
                                        <h2 class="mb-0"><?php echo $metrics['practice_areas']; ?></h2>
                                        <small>Active practice areas</small>
                                    </div>
                                    <i class="fas fa-briefcase fa-2x" style="opacity: 0.8;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Firm Analytics Chart -->
                <div class="card mb-4">
                    <div class="card-header-custom">
                        <h5><i class="fas fa-chart-line"></i> Monthly Earnings <?php echo date('Y'); ?></h5>
                    </div>
                    <div class="card-body">
                        <canvas id="earningsChart" height="80"></canvas>
                    </div>
                </div>

                <!-- Recent Activity & Quick Actions -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header-custom">
                                <h5><i class="fas fa-history"></i> Recent System Activities</h5>
                            </div>
                            <div class="card-body" style="max-height: 350px; overflow-y: auto;">
                                <?php
                                $recent_logs = $conn->query("
                                    SELECT sl.*, u.full_name, u.role 
                                    FROM system_logs sl 
                                    JOIN users u ON sl.user_id = u.id 
                                    ORDER BY sl.created_at DESC 
                                    LIMIT 10
                                ");
                                if($recent_logs->num_rows > 0):
                                    while($log = $recent_logs->fetch_assoc()):
                                ?>
                                    <div class="activity-item">
                                        <small class="text-muted"><?php echo date('M d, Y g:i A', strtotime($log['created_at'])); ?></small>
                                        <p class="mb-0">
                                            <strong style="color: var(--primary-dark);"><?php echo htmlspecialchars($log['full_name']); ?></strong> 
                                            <span class="badge" style="background: var(--secondary); color: var(--primary-dark);"><?php echo ucfirst($log['role']); ?></span>
                                            <br>
                                            <span class="text-muted"><?php echo ucfirst($log['action']); ?></span>
                                        </p>
                                    </div>
                                <?php 
                                    endwhile;
                                else:
                                ?>
                                    <p class="text-muted text-center">No recent activities</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header-custom">
                                <h5><i class="fas fa-tasks"></i> Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="manage_attorneys.php" class="btn btn-outline-primary-custom">
                                        <i class="fas fa-user-tie"></i> Add / Manage Attorneys
                                    </a>
                                    <a href="manage_practice_areas.php" class="btn btn-outline-info-custom">
                                        <i class="fas fa-briefcase"></i> Add / Manage Practice Areas
                                    </a>
                                    <a href="manage_contact.php" class="btn btn-outline-primary-custom">
                                        <i class="fas fa-address-card"></i> Update Contact Info
                                    </a>
                                    <a href="../add_case.php" class="btn btn-outline-success-custom">
                                        <i class="fas fa-briefcase"></i> Create New Case
                                    </a>
                                    <a href="client_master.php" class="btn btn-outline-info-custom">
                                        <i class="fas fa-users"></i> View All Clients
                                    </a>
                                    <a href="../invoices.php?create=1" class="btn btn-outline-warning-custom">
                                        <i class="fas fa-file-invoice"></i> Generate Invoice
                                    </a>
                                    <a href="analytics.php" class="btn" style="border: 1px solid var(--primary); color: var(--primary);">
                                        <i class="fas fa-chart-bar"></i> View Full Analytics
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
        const ctx = document.getElementById('earningsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Earnings (₹)',
                    data: [
                        <?php 
                        for($i=1; $i<=12; $i++) {
                            $value = isset($earnings[$i]) ? $earnings[$i] : 0;
                            echo $value;
                            echo $i < 12 ? ',' : '';
                        }
                        ?>
                    ],
                    borderColor: '#D4AF37',
                    backgroundColor: 'rgba(212, 175, 55, 0.1)',
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#D4AF37',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#4A0E17'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₹' + context.raw.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            },
                            color: '#4A0E17'
                        },
                        grid: {
                            color: '#e0e0e0'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#4A0E17'
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Mobile sidebar toggle
        const menuBtn = document.querySelector('.navbar-toggler');
        const sidebar = document.querySelector('.sidebar');
        if (window.innerWidth <= 768) {
            const navbarBrand = document.querySelector('.navbar-brand');
            if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
                const btn = document.createElement('button');
                btn.className = 'btn btn-sm ms-2 mobile-menu-btn';
                btn.innerHTML = '<i class="fas fa-bars"></i>';
                btn.style.background = '#D4AF37';
                btn.style.color = '#4A0E17';
                btn.style.border = 'none';
                btn.style.borderRadius = '8px';
                btn.style.padding = '5px 10px';
                btn.onclick = function() {
                    sidebar.classList.toggle('show');
                };
                navbarBrand.parentElement.insertBefore(btn, navbarBrand.nextSibling);
            }
        }
    </script>
</body>
</html>