<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$page_title = "Manage Contact Information";
$user_name = $_SESSION['user_name'] ?? 'Admin';
$success = '';
$error = '';

// Create contact_info table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS `contact_info` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `type` varchar(50) NOT NULL,
    `value` text NOT NULL,
    `icon` varchar(50) DEFAULT NULL,
    `display_order` int(11) DEFAULT 0,
    `is_active` tinyint(1) DEFAULT 1,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Insert default data if empty
$check = $conn->query("SELECT COUNT(*) as count FROM contact_info");
$count = $check->fetch_assoc()['count'];
if ($count == 0) {
    $default_data = [
        ['address', '123 Legal Street, Suite 100, New York, NY 10001', 'fas fa-map-marker-alt', 1],
        ['phone', 'Phone: (555) 123-4567<br>Fax: (555) 123-4568<br>24/7 Emergency: (555) 123-4569', 'fas fa-phone-alt', 2],
        ['email', 'General: info@sisodiyaassociates.com<br>Support: support@sisodiyaassociates.com<br>Billing: billing@sisodiyaassociates.com', 'fas fa-envelope', 3],
        ['hours', 'Monday - Friday: 9:00 AM - 6:00 PM<br>Saturday: 10:00 AM - 2:00 PM<br>Sunday: Closed<br>Emergency: 24/7 Available', 'fas fa-clock', 4],
        ['map_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bbafd23%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1699999999999!5m2!1sen!2sus', 'fas fa-map', 5]
    ];
    
    $stmt = $conn->prepare("INSERT INTO contact_info (type, value, icon, display_order) VALUES (?, ?, ?, ?)");
    foreach ($default_data as $data) {
        $stmt->bind_param("sssi", $data[0], $data[1], $data[2], $data[3]);
        $stmt->execute();
    }
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_contact'])) {
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $hours = $_POST['hours'];
    $map_embed = $_POST['map_embed'];
    
    $conn->query("UPDATE contact_info SET value = '$address' WHERE type = 'address'");
    $conn->query("UPDATE contact_info SET value = '$phone' WHERE type = 'phone'");
    $conn->query("UPDATE contact_info SET value = '$email' WHERE type = 'email'");
    $conn->query("UPDATE contact_info SET value = '$hours' WHERE type = 'hours'");
    $conn->query("UPDATE contact_info SET value = '$map_embed' WHERE type = 'map_embed'");
    
    $success = "Contact information updated successfully!";
}

// Get current contact info
$address = $conn->query("SELECT value FROM contact_info WHERE type = 'address'")->fetch_assoc()['value'] ?? '';
$phone = $conn->query("SELECT value FROM contact_info WHERE type = 'phone'")->fetch_assoc()['value'] ?? '';
$email = $conn->query("SELECT value FROM contact_info WHERE type = 'email'")->fetch_assoc()['value'] ?? '';
$hours = $conn->query("SELECT value FROM contact_info WHERE type = 'hours'")->fetch_assoc()['value'] ?? '';
$map_embed = $conn->query("SELECT value FROM contact_info WHERE type = 'map_embed'")->fetch_assoc()['value'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contact Info | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        .form-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .form-card .card-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
            padding: 15px 20px;
        }

        .form-card .card-header h4 {
            margin: 0;
            font-weight: 700;
        }

        .form-card .card-header h4 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .form-card .card-body {
            padding: 25px;
        }

        .form-label {
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 8px;
        }

        .form-label i {
            color: var(--secondary);
            margin-right: 6px;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        .btn-gold {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark);
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .btn-secondary-custom {
            background: #6c757d;
            border: none;
            color: white;
            padding: 10px 25px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .preview-box {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 15px;
            margin-top: 10px;
            border: 1px solid #e2e8f0;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
            
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Sidebar -->
<nav class="sidebar">
    <div class="position-sticky">
        <!-- Sidebar Logo -->
        
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="lawyer_management.php">
                    <i class="fas fa-gavel"></i> Lawyer Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_attorneys.php">
                    <i class="fas fa-user-tie"></i> Manage Attorneys
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_practice_areas.php">
                    <i class="fas fa-briefcase"></i> Practice Areas
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="client_master.php">
                    <i class="fas fa-user-friends"></i> Client Master
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_contact.php">
                    <i class="fas fa-address-card"></i> Contact Info
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="analytics.php">
                    <i class="fas fa-chart-line"></i> Analytics
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../cases.php">
                    <i class="fas fa-briefcase"></i> All Cases
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i> Invoices
                </a>
            </li>
            <li class="nav-item mt-4">
                <hr style="border-color: rgba(212,175,55,0.3);">
                <a class="nav-link" href="../profile.php">
                    <i class="fas fa-user-circle"></i> Profile Settings
                </a>
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</nav>

<!-- Main Content -->
<main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2" style="color: var(--primary-dark);">
            <i class="fas fa-address-card me-2" style="color: var(--secondary);"></i> Manage Contact Information
        </h1>
    </div>

    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="card-header">
            <h4><i class="fas fa-edit"></i> Edit Contact Details</h4>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-map-marker-alt"></i> Address</label>
                    <textarea class="form-control" name="address" rows="3" required><?php echo htmlspecialchars($address); ?></textarea>
                    <small class="text-muted">Enter complete office address. Use &lt;br&gt; for line breaks.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-phone-alt"></i> Phone Numbers</label>
                    <textarea class="form-control" name="phone" rows="3" required><?php echo htmlspecialchars($phone); ?></textarea>
                    <small class="text-muted">Format: Phone: (555) 123-4567&lt;br&gt;Fax: (555) 123-4568</small>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-envelope"></i> Email Addresses</label>
                    <textarea class="form-control" name="email" rows="3" required><?php echo htmlspecialchars($email); ?></textarea>
                    <small class="text-muted">Format: General: info@sisodiyaassociates.com&lt;br&gt;Support: support@sisodiyaassociates.com</small>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-clock"></i> Office Hours</label>
                    <textarea class="form-control" name="hours" rows="4" required><?php echo htmlspecialchars($hours); ?></textarea>
                    <small class="text-muted">Format: Monday - Friday: 9:00 AM - 6:00 PM&lt;br&gt;Saturday: 10:00 AM - 2:00 PM</small>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-map"></i> Google Map Embed Code</label>
                    <textarea class="form-control" name="map_embed" rows="4"><?php echo htmlspecialchars($map_embed); ?></textarea>
                    <small class="text-muted">Paste the Google Maps embed iframe code here.</small>
                </div>

                <div class="d-flex gap-3">
                    <button type="submit" name="update_contact" class="btn btn-gold">
                        <i class="fas fa-save me-2"></i> Save Changes
                    </button>
                    <a href="../contact.php" class="btn btn-secondary-custom" target="_blank">
                        <i class="fas fa-eye me-2"></i> Preview Contact Page
                    </a>
                </div>
            </form>
        </div>
    </div>

    <div class="form-card">
        <div class="card-header">
            <h4><i class="fas fa-info-circle"></i> Preview</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="preview-box">
                        <h6><i class="fas fa-map-marker-alt" style="color: #D4AF37;"></i> Address</h6>
                        <p><?php echo nl2br(htmlspecialchars($address)); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="preview-box">
                        <h6><i class="fas fa-phone-alt" style="color: #D4AF37;"></i> Phone</h6>
                        <p><?php echo $phone; ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="preview-box">
                        <h6><i class="fas fa-envelope" style="color: #D4AF37;"></i> Email</h6>
                        <p><?php echo $email; ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="preview-box">
                        <h6><i class="fas fa-clock" style="color: #D4AF37;"></i> Office Hours</h6>
                        <p><?php echo $hours; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Mobile sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    let overlay = document.getElementById('overlay');
    
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }
    
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>
</body>
</html>