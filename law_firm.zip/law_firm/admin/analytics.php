<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$user_name = $_SESSION['user_name'] ?? 'Admin';

// Get yearly earnings data
$yearly_earnings = [];
$result = $conn->query("SELECT YEAR(paid_date) as year, SUM(amount) as total 
                        FROM invoices 
                        WHERE status = 'paid' 
                        GROUP BY YEAR(paid_date) 
                        ORDER BY year DESC");
while($row = $result->fetch_assoc()) {
    $yearly_earnings[$row['year']] = $row['total'];
}

// Get monthly earnings for current year
$monthly_earnings = [];
for($i=1; $i<=12; $i++) {
    $monthly_earnings[$i] = 0;
}
$result = $conn->query("SELECT MONTH(paid_date) as month, SUM(amount) as total 
                        FROM invoices 
                        WHERE status = 'paid' AND YEAR(paid_date) = YEAR(CURDATE())
                        GROUP BY MONTH(paid_date)");
while($row = $result->fetch_assoc()) {
    $monthly_earnings[$row['month']] = $row['total'];
}

// Get case statistics by status
$case_stats = [];
$result = $conn->query("SELECT status, COUNT(*) as total FROM cases GROUP BY status");
while($row = $result->fetch_assoc()) {
    $case_stats[$row['status']] = $row['total'];
}

// Get lawyer performance
$lawyer_performance = $conn->query("
    SELECT u.id, u.full_name, 
           COUNT(DISTINCT c.id) as total_cases,
           SUM(CASE WHEN c.status = 'active' THEN 1 ELSE 0 END) as active_cases,
           SUM(CASE WHEN c.status = 'closed' THEN 1 ELSE 0 END) as closed_cases,
           COALESCE(SUM(t.hours), 0) as billable_hours,
           COALESCE(SUM(i.amount), 0) as revenue_generated
    FROM users u
    LEFT JOIN cases c ON c.assigned_lawyer_id = u.id
    LEFT JOIN timesheets t ON t.user_id = u.id AND t.case_id = c.id
    LEFT JOIN invoices i ON i.case_id = c.id AND i.status = 'paid'
    WHERE u.role = 'lawyer'
    GROUP BY u.id, u.full_name
    ORDER BY revenue_generated DESC
");

// Get monthly new clients
$new_clients = [];
for($i=1; $i<=12; $i++) {
    $new_clients[$i] = 0;
}
$result = $conn->query("SELECT MONTH(created_at) as month, COUNT(*) as total 
                        FROM users 
                        WHERE role = 'client' AND YEAR(created_at) = YEAR(CURDATE())
                        GROUP BY MONTH(created_at)");
while($row = $result->fetch_assoc()) {
    $new_clients[$row['month']] = $row['total'];
}

// Get top practice areas (based on case distribution)
$practice_areas = [];
$result = $conn->query("SELECT 
    CASE 
        WHEN title LIKE '%Corporate%' OR title LIKE '%Business%' THEN 'Corporate Law'
        WHEN title LIKE '%Real Estate%' OR title LIKE '%Property%' THEN 'Real Estate'
        WHEN title LIKE '%Medical%' OR title LIKE '%Malpractice%' THEN 'Medical Malpractice'
        WHEN title LIKE '%Criminal%' OR title LIKE '%Defense%' THEN 'Criminal Defense'
        WHEN title LIKE '%Family%' OR title LIKE '%Divorce%' THEN 'Family Law'
        WHEN title LIKE '%Immigration%' OR title LIKE '%Visa%' THEN 'Immigration Law'
        ELSE 'Other'
    END as area,
    COUNT(*) as total
    FROM cases 
    GROUP BY area");
while($row = $result->fetch_assoc()) {
    $practice_areas[$row['area']] = $row['total'];
}

// Get system logs summary
$system_logs = $conn->query("
    SELECT DATE(created_at) as date, COUNT(*) as total 
    FROM system_logs 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firm Analytics - Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --accent: #8B2635;
            --light: #FDF8F0;
            --dark: #2D0A10;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body { 
            background: var(--light); 
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        /* Chart Containers */
        .chart-container { 
            background: white; 
            border-radius: 20px; 
            padding: 20px; 
            margin-bottom: 25px; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border: 1px solid rgba(212, 175, 55, 0.2);
        }

        .chart-title { 
            font-size: 1.1rem; 
            font-weight: 700; 
            margin-bottom: 20px; 
            color: var(--primary-dark);
            border-left: 3px solid var(--secondary);
            padding-left: 12px;
        }

        .chart-title i {
            color: var(--secondary);
            margin-right: 8px;
        }

        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .table thead th {
            background: var(--primary-dark);
            color: white;
            font-weight: 600;
            border: none;
            padding: 12px;
        }

        .table tbody tr:hover {
            background: rgba(212, 175, 55, 0.05);
        }

        .badge-active {
            background: #10b981;
            color: white;
            padding: 5px 10px;
            border-radius: 50px;
        }

        .badge-closed {
            background: #6c757d;
            color: white;
            padding: 5px 10px;
            border-radius: 50px;
        }

        /* Progress Bar */
        .progress-custom {
            height: 8px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-bar-custom {
            background: linear-gradient(90deg, var(--secondary), var(--secondary-light));
            border-radius: 10px;
        }

        /* DataTables Customization */
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--secondary) !important;
            color: var(--primary-dark) !important;
            border-color: var(--secondary) !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: var(--secondary-light) !important;
            color: var(--primary-dark) !important;
        }

        .dataTables_wrapper .dataTables_filter input {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 6px 12px;
        }

        .dataTables_wrapper .dataTables_filter input:focus {
            border-color: var(--secondary);
            outline: none;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
           
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
                
                
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="lawyer_management.php"><i class="fas fa-gavel"></i> Lawyer Management</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_attorneys.php"><i class="fas fa-user-tie"></i> Manage Attorneys</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_practice_areas.php"><i class="fas fa-briefcase"></i> Practice Areas</a></li>
                    <li class="nav-item"><a class="nav-link" href="client_master.php"><i class="fas fa-user-friends"></i> Client Master</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_contact.php"><i class="fas fa-address-card"></i> Contact Info</a></li>
                    <li class="nav-item"><a class="nav-link active" href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                    <li class="nav-item"><a class="nav-link" href="../cases.php"><i class="fas fa-briefcase"></i> All Cases</a></li>
                    <li class="nav-item"><a class="nav-link" href="../invoices.php"><i class="fas fa-file-invoice-dollar"></i> Invoices</a></li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="../profile.php"><i class="fas fa-user-circle"></i> Profile Settings</a>
                        <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="pt-3 pb-2 mb-3">
                <h1 class="h2" style="color: var(--primary-dark);">
                    <i class="fas fa-chart-line" style="color: var(--secondary);"></i> Firm Analytics
                </h1>
                <p class="text-muted">Comprehensive insights and performance metrics</p>
            </div>

            <!-- Financial Charts Row -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-chart-line"></i> Monthly Earnings <?php echo date('Y'); ?></div>
                        <canvas id="monthlyEarningsChart" height="250"></canvas>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-chart-bar"></i> Yearly Earnings Overview</div>
                        <canvas id="yearlyEarningsChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-briefcase"></i> Case Status Distribution</div>
                        <canvas id="caseStatusChart" height="250"></canvas>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-chart-pie"></i> Practice Areas Breakdown</div>
                        <canvas id="practiceAreasChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-user-plus"></i> New Clients (Monthly)</div>
                        <canvas id="newClientsChart" height="250"></canvas>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="chart-container">
                        <div class="chart-title"><i class="fas fa-chart-line"></i> System Activity (Last 7 Days)</div>
                        <canvas id="systemLogsChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <!-- Lawyer Performance Table -->
            <div class="table-container">
                <div class="chart-title"><i class="fas fa-trophy"></i> Lawyer Performance Dashboard</div>
                <div class="table-responsive">
                    <table id="lawyerTable" class="table table-hover">
                        <thead>
                            <tr>
                                <th>Lawyer</th>
                                <th>Total Cases</th>
                                <th>Active</th>
                                <th>Closed</th>
                                <th>Billable Hours</th>
                                <th>Revenue Generated</th>
                                <th>Performance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($lawyer_performance && $lawyer_performance->num_rows > 0): ?>
                                <?php while($lawyer = $lawyer_performance->fetch_assoc()): 
                                    $performance_rate = $lawyer['total_cases'] > 0 ? ($lawyer['closed_cases'] / $lawyer['total_cases']) * 100 : 0;
                                ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($lawyer['full_name']); ?></strong></td>
                                        <td><?php echo $lawyer['total_cases']; ?></td>
                                        <td><span class="badge badge-active"><?php echo $lawyer['active_cases']; ?></span></td>
                                        <td><span class="badge badge-closed"><?php echo $lawyer['closed_cases']; ?></span></td>
                                        <td><?php echo number_format($lawyer['billable_hours'], 1); ?> hrs</td>
                                        <td><strong>₹<?php echo number_format($lawyer['revenue_generated'], 2); ?></strong></td>
                                        <td>
                                            <div class="progress-custom">
                                                <div class="progress-bar-custom" style="width: <?php echo $performance_rate; ?>%; height: 100%;"></div>
                                            </div>
                                            <small class="text-muted"><?php echo round($performance_rate); ?>% Success Rate</small>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">No lawyer performance data available</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        if ($('#lawyerTable tbody tr').length > 0 && $('#lawyerTable tbody tr td').length > 1) {
            $('#lawyerTable').DataTable({
                order: [[5, 'desc']],
                pageLength: 10,
                language: {
                    search: "Search lawyers:",
                    lengthMenu: "Show _MENU_ lawyers",
                    info: "Showing _START_ to _END_ of _TOTAL_ lawyers",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "→",
                        previous: "←"
                    }
                }
            });
        }
    });

    // Monthly Earnings Chart
    new Chart(document.getElementById('monthlyEarningsChart'), {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Earnings (₹)',
                data: [<?php echo implode(',', $monthly_earnings); ?>],
                backgroundColor: 'rgba(212, 175, 55, 0.7)',
                borderColor: '#D4AF37',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true, 
            scales: { 
                y: { 
                    beginAtZero: true, 
                    ticks: { 
                        callback: v => '₹' + v,
                        color: '#4A0E17'
                    },
                    grid: { color: '#e0e0e0' }
                },
                x: {
                    ticks: { color: '#4A0E17' }
                }
            },
            plugins: {
                legend: { labels: { color: '#4A0E17' } }
            }
        }
    });

    // Yearly Earnings Chart
    new Chart(document.getElementById('yearlyEarningsChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_keys($yearly_earnings)); ?>,
            datasets: [{
                label: 'Annual Revenue (₹)',
                data: <?php echo json_encode(array_values($yearly_earnings)); ?>,
                borderColor: '#D4AF37',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#D4AF37',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true, 
            scales: { 
                y: { 
                    beginAtZero: true, 
                    ticks: { 
                        callback: v => '₹' + v.toLocaleString(),
                        color: '#4A0E17'
                    },
                    grid: { color: '#e0e0e0' }
                },
                x: {
                    ticks: { color: '#4A0E17' }
                }
            },
            plugins: {
                legend: { labels: { color: '#4A0E17' } }
            }
        }
    });

    // Case Status Chart
    new Chart(document.getElementById('caseStatusChart'), {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_keys($case_stats)); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($case_stats)); ?>,
                backgroundColor: ['#D4AF37', '#F5D76E', '#8B2635', '#4A0E17'],
                borderWidth: 0
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true,
            plugins: {
                legend: { 
                    position: 'bottom',
                    labels: { color: '#4A0E17' }
                }
            }
        }
    });

    // Practice Areas Chart
    new Chart(document.getElementById('practiceAreasChart'), {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_keys($practice_areas)); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($practice_areas)); ?>,
                backgroundColor: ['#D4AF37', '#F5D76E', '#8B2635', '#4A0E17', '#6B1A2A', '#C72A2A', '#2D0A10']
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true,
            plugins: {
                legend: { 
                    position: 'bottom',
                    labels: { color: '#4A0E17' }
                }
            }
        }
    });

    // New Clients Chart
    new Chart(document.getElementById('newClientsChart'), {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'New Clients',
                data: [<?php echo implode(',', $new_clients); ?>],
                borderColor: '#D4AF37',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#D4AF37',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true, 
            scales: { 
                y: { 
                    beginAtZero: true, 
                    stepSize: 1,
                    ticks: { color: '#4A0E17' },
                    grid: { color: '#e0e0e0' }
                },
                x: {
                    ticks: { color: '#4A0E17' }
                }
            },
            plugins: {
                legend: { labels: { color: '#4A0E17' } }
            }
        }
    });

    // System Logs Chart
    <?php
    $log_dates = [];
    $log_counts = [];
    $system_logs->data_seek(0);
    while($log = $system_logs->fetch_assoc()) {
        $log_dates[] = date('M d', strtotime($log['date']));
        $log_counts[] = $log['total'];
    }
    ?>
    new Chart(document.getElementById('systemLogsChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($log_dates); ?>,
            datasets: [{
                label: 'Activities',
                data: <?php echo json_encode($log_counts); ?>,
                backgroundColor: 'rgba(212, 175, 55, 0.7)',
                borderColor: '#D4AF37',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: true, 
            scales: { 
                y: { 
                    beginAtZero: true, 
                    stepSize: 1,
                    ticks: { color: '#4A0E17' },
                    grid: { color: '#e0e0e0' }
                },
                x: {
                    ticks: { color: '#4A0E17' }
                }
            },
            plugins: {
                legend: { labels: { color: '#4A0E17' } }
            }
        }
    });

    // Mobile sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    let overlay = document.getElementById('overlay');
    
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }
    
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>
</body>
</html>