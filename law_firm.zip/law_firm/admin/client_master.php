<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$user_name = $_SESSION['user_name'] ?? 'Admin';

// Handle Client Status Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $client_id = $_POST['client_id'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $is_active, $client_id);
    $stmt->execute();
    $success = "Client status updated!";
}

// Get all clients with their case information
$clients = $conn->query("
    SELECT u.*, 
           (SELECT COUNT(*) FROM cases WHERE client_id = u.id) as total_cases,
           (SELECT COUNT(*) FROM cases WHERE client_id = u.id AND status = 'active') as active_cases,
           (SELECT SUM(amount) FROM invoices WHERE client_id = u.id AND status != 'paid') as outstanding_amount,
           (SELECT SUM(amount) FROM invoices WHERE client_id = u.id AND status = 'paid') as paid_amount
    FROM users u
    WHERE u.role = 'client'
    ORDER BY u.created_at DESC
");

// Statistics
$stats = [];
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'client'");
$stats['total_clients'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'client' AND is_active = 1");
$stats['active_clients'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE status = 'active'");
$stats['active_cases'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE status != 'paid'");
$stats['total_outstanding'] = $result->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Master - Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --accent: #8B2635;
            --light: #FDF8F0;
            --dark: #2D0A10;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body { 
            background: var(--light); 
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        
        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
            border-bottom: 3px solid transparent;
        }
        .stat-card:hover { 
            transform: translateY(-5px);
            border-bottom-color: var(--secondary);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
        }
        .stat-icon i { 
            font-size: 1.5rem; 
            color: var(--primary-dark);
        }
        
        /* Table Styles */
        .client-table-container {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border: 1px solid rgba(212, 175, 55, 0.2);
        }

        .client-table-container .card-header {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            color: white;
            border: none;
            padding: 15px 20px;
        }

        .client-table-container .card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .client-table-container .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .client-table-container .card-body {
            padding: 20px;
        }

        .client-row:hover { 
            background: rgba(212, 175, 55, 0.05) !important; 
            cursor: pointer; 
        }
        
        /* Badges */
        .badge-total {
            background: var(--secondary);
            color: var(--primary-dark);
            padding: 5px 10px;
            border-radius: 50px;
        }

        .badge-active {
            background: #10b981;
            color: white;
            padding: 5px 10px;
            border-radius: 50px;
        }

        .badge-inactive {
            background: #ef4444;
            color: white;
            padding: 5px 10px;
            border-radius: 50px;
        }

        .text-outstanding {
            color: #ef4444;
            font-weight: 600;
        }

        /* Buttons */
        .btn-toggle {
            background: #f59e0b;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-toggle:hover {
            background: #d97706;
            transform: translateY(-2px);
        }

        .btn-view {
            background: var(--secondary);
            color: var(--primary-dark);
            border: none;
            padding: 5px 12px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-view:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
        }

        /* Modal */
        .detail-modal .modal-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .detail-modal .modal-header .btn-close {
            background: white;
            opacity: 1;
        }

        /* DataTables Customization */
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--secondary) !important;
            color: var(--primary-dark) !important;
            border-color: var(--secondary) !important;
            border-radius: 8px !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: var(--secondary-light) !important;
            color: var(--primary-dark) !important;
            border-radius: 8px !important;
        }

        .dataTables_wrapper .dataTables_filter input {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 6px 12px;
            margin-left: 8px;
        }

        .dataTables_wrapper .dataTables_filter input:focus {
            border-color: var(--secondary);
            outline: none;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
           
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
               
                
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="lawyer_management.php"><i class="fas fa-gavel"></i> Lawyer Management</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_attorneys.php"><i class="fas fa-user-tie"></i> Manage Attorneys</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_practice_areas.php"><i class="fas fa-briefcase"></i> Practice Areas</a></li>
                    <li class="nav-item"><a class="nav-link active" href="client_master.php"><i class="fas fa-user-friends"></i> Client Master</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_contact.php"><i class="fas fa-address-card"></i> Contact Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                    <li class="nav-item"><a class="nav-link" href="../cases.php"><i class="fas fa-briefcase"></i> All Cases</a></li>
                    <li class="nav-item"><a class="nav-link" href="../invoices.php"><i class="fas fa-file-invoice-dollar"></i> Invoices</a></li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="../profile.php"><i class="fas fa-user-circle"></i> Profile Settings</a>
                        <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="pt-3 pb-2 mb-3">
                <h1 class="h2" style="color: var(--primary-dark);">
                    <i class="fas fa-user-friends" style="color: var(--secondary);"></i> Client Master
                </h1>
                <p class="text-muted">Complete overview of all registered clients</p>
            </div>

            <?php if(isset($success)): ?>
                <div class="alert alert-success alert-dismissible fade show" style="background: #d4edda; border-left: 4px solid #10b981; border-radius: 12px;">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics Row -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-users"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['total_clients']; ?></h3>
                        <p class="text-muted mb-0">Total Clients</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['active_clients']; ?></h3>
                        <p class="text-muted mb-0">Active Clients</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-briefcase"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['active_cases']; ?></h3>
                        <p class="text-muted mb-0">Active Cases</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-rupee-sign"></i></div>
                        <h3 style="color: var(--primary-dark);">₹<?php echo number_format($stats['total_outstanding'], 2); ?></h3>
                        <p class="text-muted mb-0">Outstanding Amount</p>
                    </div>
                </div>
            </div>

            <!-- Clients Table -->
            <div class="client-table-container">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list"></i> All Clients</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="clientsTable" class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Client Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Registered</th>
                                    <th>Total Cases</th>
                                    <th>Active Cases</th>
                                    <th>Outstanding</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($client = $clients->fetch_assoc()): ?>
                                    <tr class="client-row">
                                        <td><?php echo $client['id']; ?></td>
                                        <td>
                                            <strong style="color: var(--primary-dark);"><?php echo htmlspecialchars($client['full_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($client['username']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($client['email']); ?></td>
                                        <td><?php echo htmlspecialchars($client['phone'] ?: '—'); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($client['created_at'])); ?></td>
                                        <td><span class="badge-total"><?php echo $client['total_cases']; ?></span></td>
                                        <td><span class="badge-active"><?php echo $client['active_cases']; ?></span></td>
                                        <td class="text-outstanding">₹<?php echo number_format($client['outstanding_amount'] ?? 0, 2); ?></td>
                                        <td>
                                            <span class="badge <?php echo $client['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                                <?php echo $client['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-toggle" onclick="toggleClientStatus(<?php echo $client['id']; ?>, <?php echo $client['is_active']; ?>)">
                                                <i class="fas fa-<?php echo $client['is_active'] ? 'ban' : 'check'; ?>"></i>
                                            </button>
                                            <button class="btn btn-view" onclick="viewClientDetails(<?php echo $client['id']; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Client Details Modal -->
<div class="modal fade detail-modal" id="clientModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-user" style="color: var(--secondary);"></i> Client Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="clientDetails">
                <!-- Loaded via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Toggle Status Form -->
<form id="statusForm" method="POST" style="display: none;">
    <input type="hidden" name="client_id" id="status_client_id">
    <input type="hidden" name="is_active" id="status_is_active">
    <input type="hidden" name="update_status" value="1">
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#clientsTable').DataTable({
            order: [[0, 'desc']],
            pageLength: 20,
            language: { 
                search: "Search clients:",
                lengthMenu: "Show _MENU_ clients",
                info: "Showing _START_ to _END_ of _TOTAL_ clients",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "→",
                    previous: "←"
                }
            },
            columnDefs: [
                { orderable: false, targets: 9 }
            ]
        });
    });
    
    function toggleClientStatus(id, currentStatus) {
        var newStatus = currentStatus ? 0 : 1;
        var action = currentStatus ? 'deactivate' : 'activate';
        if(confirm('Are you sure you want to ' + action + ' this client?')) {
            document.getElementById('status_client_id').value = id;
            document.getElementById('status_is_active').value = newStatus;
            document.getElementById('statusForm').submit();
        }
    }
    
    function viewClientDetails(id) {
        $.ajax({
            url: 'get_client_details.php',
            method: 'GET',
            data: { id: id },
            success: function(data) {
                $('#clientDetails').html(data);
                $('#clientModal').modal('show');
            },
            error: function() {
                $('#clientDetails').html('<div class="alert alert-danger">Error loading client details.</div>');
            }
        });
    }
    
    // Mobile sidebar toggle
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.querySelector('.sidebar');
    
    let overlay = document.getElementById('overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }
    
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>
</body>
</html>