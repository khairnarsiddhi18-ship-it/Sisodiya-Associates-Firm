<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$user_name = $_SESSION['user_name'] ?? 'Admin';

// Handle Add/Edit Lawyer
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_lawyer'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $full_name = $_POST['full_name'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $phone = $_POST['phone'];
        $specialization = $_POST['specialization'];
        $experience = $_POST['experience'];
        $bar_number = $_POST['bar_number'];
        
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active) VALUES (?, ?, ?, ?, ?, 'lawyer', 1)");
        $stmt->bind_param("sssss", $username, $email, $password, $full_name, $phone);
        
        if ($stmt->execute()) {
            $lawyer_id = $conn->insert_id;
            // Add lawyer profile details
            $profile = $conn->prepare("INSERT INTO lawyer_profiles (user_id, specialization, experience_years, bar_number) VALUES (?, ?, ?, ?)");
            $profile->bind_param("isis", $lawyer_id, $specialization, $experience, $bar_number);
            $profile->execute();
            $success = "Lawyer added successfully!";
        } else {
            $error = "Error adding lawyer: " . $conn->error;
        }
    }
    
    if (isset($_POST['update_lawyer'])) {
        $lawyer_id = $_POST['lawyer_id'];
        $full_name = $_POST['full_name'];
        $phone = $_POST['phone'];
        $specialization = $_POST['specialization'];
        $experience = $_POST['experience'];
        $bar_number = $_POST['bar_number'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, phone = ?, is_active = ? WHERE id = ?");
        $stmt->bind_param("ssii", $full_name, $phone, $is_active, $lawyer_id);
        $stmt->execute();
        
        $profile = $conn->prepare("UPDATE lawyer_profiles SET specialization = ?, experience_years = ?, bar_number = ? WHERE user_id = ?");
        $profile->bind_param("sisi", $specialization, $experience, $bar_number, $lawyer_id);
        $profile->execute();
        
        $success = "Lawyer updated successfully!";
    }
    
    if (isset($_POST['suspend_lawyer'])) {
        $lawyer_id = $_POST['lawyer_id'];
        $stmt = $conn->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
        $stmt->bind_param("i", $lawyer_id);
        $stmt->execute();
        $success = "Lawyer suspended successfully!";
    }
    
    if (isset($_POST['activate_lawyer'])) {
        $lawyer_id = $_POST['lawyer_id'];
        $stmt = $conn->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
        $stmt->bind_param("i", $lawyer_id);
        $stmt->execute();
        $success = "Lawyer activated successfully!";
    }
}

// Handle Delete
if (isset($_GET['delete'])) {
    $lawyer_id = $_GET['delete'];
    $conn->query("DELETE FROM lawyer_profiles WHERE user_id = $lawyer_id");
    $conn->query("DELETE FROM users WHERE id = $lawyer_id");
    $success = "Lawyer deleted successfully!";
}

// Get all lawyers with their profiles
$lawyers = $conn->query("
    SELECT u.*, lp.specialization, lp.experience_years, lp.bar_number,
           (SELECT COUNT(*) FROM cases WHERE assigned_lawyer_id = u.id) as total_cases,
           (SELECT COUNT(*) FROM cases WHERE assigned_lawyer_id = u.id AND status = 'active') as active_cases
    FROM users u
    LEFT JOIN lawyer_profiles lp ON u.id = lp.user_id
    WHERE u.role = 'lawyer'
    ORDER BY u.created_at DESC
");

// Get lawyer for editing
$edit_lawyer = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $result = $conn->query("
        SELECT u.*, lp.specialization, lp.experience_years, lp.bar_number 
        FROM users u 
        LEFT JOIN lawyer_profiles lp ON u.id = lp.user_id 
        WHERE u.id = $edit_id
    ");
    $edit_lawyer = $result->fetch_assoc();
}

// Statistics
$stats = [];
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'lawyer'");
$stats['total_lawyers'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'lawyer' AND is_active = 1");
$stats['active_lawyers'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'lawyer' AND is_active = 0");
$stats['inactive_lawyers'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT AVG(experience_years) as avg_exp FROM lawyer_profiles");
$stats['avg_experience'] = round($result->fetch_assoc()['avg_exp'] ?? 0, 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Management - Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --accent: #8B2635;
            --light: #FDF8F0;
            --dark: #2D0A10;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--light);
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
            border-bottom: 3px solid transparent;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-bottom-color: var(--secondary);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
        }

        .stat-icon i {
            font-size: 1.5rem;
            color: var(--primary-dark);
        }

        /* Lawyer Cards */
        .lawyer-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
            border-left: 3px solid transparent;
        }

        .lawyer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-left-color: var(--secondary);
        }

        .lawyer-header {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            color: white;
            padding: 20px;
            position: relative;
        }

        .lawyer-avatar {
            width: 70px;
            height: 70px;
            background: rgba(212, 175, 55, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        .lawyer-avatar i {
            font-size: 2.5rem;
            color: var(--secondary);
        }

        .status-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-active { background: #10b981; color: white; }
        .status-inactive { background: #ef4444; color: white; }

        .btn-action {
            padding: 5px 12px;
            margin: 2px;
            border-radius: 8px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .btn-action:hover {
            transform: translateY(-2px);
        }

        .btn-edit {
            background: var(--secondary);
            color: var(--primary-dark);
            border: none;
        }

        .btn-edit:hover {
            background: var(--secondary-light);
            color: var(--primary-dark);
        }

        .btn-suspend {
            background: #ef4444;
            color: white;
            border: none;
        }

        .btn-suspend:hover {
            background: #dc2626;
        }

        .btn-activate {
            background: #10b981;
            color: white;
            border: none;
        }

        .btn-activate:hover {
            background: #059669;
        }

        .btn-delete {
            background: #C72A2A;
            color: white;
            border: none;
        }

        .btn-delete:hover {
            background: #8B2635;
        }

        /* Buttons */
        .btn-primary-custom {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        /* Modal */
        .modal-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .modal-header .btn-close {
            background: white;
            opacity: 1;
        }

        .modal-title i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .btn-modal-primary {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark);
            font-weight: 600;
        }

        .btn-modal-primary:hover {
            background: linear-gradient(135deg, var(--secondary-light), var(--secondary));
        }

        /* Form Controls */
        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        label {
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        hr {
            background: rgba(212, 175, 55, 0.2);
        }

        /* Alert */
        .alert-success-custom {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
            border-radius: 12px;
        }

        .alert-danger-custom {
            background: #f8d7da;
            border-left: 4px solid #C72A2A;
            color: #721c24;
            border-radius: 12px;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
            
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
               
                
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="lawyer_management.php"><i class="fas fa-users"></i> Lawyer Management</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_attorneys.php"><i class="fas fa-user-tie"></i> Manage Attorneys</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_practice_areas.php"><i class="fas fa-briefcase"></i> Practice Areas</a></li>
                    <li class="nav-item"><a class="nav-link" href="client_master.php"><i class="fas fa-user-friends"></i> Client Master</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_contact.php"><i class="fas fa-address-card"></i> Contact Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                    <li class="nav-item"><a class="nav-link" href="../cases.php"><i class="fas fa-briefcase"></i> All Cases</a></li>
                    <li class="nav-item"><a class="nav-link" href="../invoices.php"><i class="fas fa-file-invoice-dollar"></i> Invoices</a></li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="../profile.php"><i class="fas fa-user-circle"></i> Profile Settings</a>
                        <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="pt-3 pb-2 mb-3">
                <h1 class="h2" style="color: var(--primary-dark);">
                    <i class="fas fa-users" style="color: var(--secondary);"></i> Lawyer Management
                </h1>
            </div>

            <!-- Alert Messages -->
            <?php if(isset($success)): ?>
                <div class="alert alert-success-custom alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if(isset($error)): ?>
                <div class="alert alert-danger-custom alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics Row -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['total_lawyers']; ?></h3>
                        <p class="text-muted mb-0">Total Lawyers</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['active_lawyers']; ?></h3>
                        <p class="text-muted mb-0">Active Lawyers</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-ban"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['inactive_lawyers']; ?></h3>
                        <p class="text-muted mb-0">Inactive Lawyers</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                        <h3 style="color: var(--primary-dark);"><?php echo $stats['avg_experience']; ?> yrs</h3>
                        <p class="text-muted mb-0">Avg Experience</p>
                    </div>
                </div>
            </div>

            <!-- Add Lawyer Button -->
            <div class="mb-4">
                <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addLawyerModal">
                    <i class="fas fa-plus me-2"></i> Add New Lawyer
                </button>
            </div>

            <!-- Lawyers Grid -->
            <div class="row">
                <?php while($lawyer = $lawyers->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="lawyer-card">
                            <div class="lawyer-header">
                                <div class="lawyer-avatar">
                                    <i class="fas fa-user-tie"></i>
                                </div>
                                <h5 class="mb-0"><?php echo htmlspecialchars($lawyer['full_name']); ?></h5>
                                <small style="opacity: 0.8;"><?php echo htmlspecialchars($lawyer['email']); ?></small>
                                <span class="status-badge status-<?php echo $lawyer['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $lawyer['is_active'] ? 'Active' : 'Suspended'; ?>
                                </span>
                            </div>
                            <div class="p-3">
                                <p><i class="fas fa-phone" style="color: var(--secondary);"></i> <?php echo htmlspecialchars($lawyer['phone'] ?? 'N/A'); ?></p>
                                <p><i class="fas fa-gavel" style="color: var(--secondary);"></i> <?php echo htmlspecialchars($lawyer['specialization'] ?? 'General Practice'); ?></p>
                                <p><i class="fas fa-calendar-alt" style="color: var(--secondary);"></i> <?php echo htmlspecialchars($lawyer['experience_years'] ?? '0'); ?> years experience</p>
                                <p><i class="fas fa-id-card" style="color: var(--secondary);"></i> Bar #: <?php echo htmlspecialchars($lawyer['bar_number'] ?? 'N/A'); ?></p>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <span><i class="fas fa-briefcase" style="color: var(--secondary);"></i> <?php echo $lawyer['active_cases']; ?> Active</span>
                                    <span><i class="fas fa-folder-open" style="color: var(--secondary);"></i> <?php echo $lawyer['total_cases']; ?> Total</span>
                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-action btn-edit" onclick="editLawyer(<?php echo $lawyer['id']; ?>)">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <?php if($lawyer['is_active']): ?>
                                        <button class="btn btn-action btn-suspend" onclick="suspendLawyer(<?php echo $lawyer['id']; ?>)">
                                            <i class="fas fa-ban"></i> Suspend
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-action btn-activate" onclick="activateLawyer(<?php echo $lawyer['id']; ?>)">
                                            <i class="fas fa-check"></i> Activate
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-action btn-delete" onclick="deleteLawyer(<?php echo $lawyer['id']; ?>)">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </main>
    </div>
</div>

<!-- Add Lawyer Modal -->
<div class="modal fade" id="addLawyerModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-user-plus"></i> Add New Lawyer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Username</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Full Name</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Phone</label>
                            <input type="tel" class="form-control" name="phone">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Specialization</label>
                            <input type="text" class="form-control" name="specialization" placeholder="e.g., Criminal Law">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Experience (Years)</label>
                            <input type="number" class="form-control" name="experience" step="0.5">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Bar Number</label>
                            <input type="text" class="form-control" name="bar_number">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_lawyer" class="btn btn-modal-primary">Add Lawyer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function editLawyer(id) {
        window.location.href = '?edit=' + id;
    }
    
    function suspendLawyer(id) {
        if(confirm('Are you sure you want to suspend this lawyer?')) {
            var form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = '<input type="hidden" name="lawyer_id" value="' + id + '"><input type="hidden" name="suspend_lawyer" value="1">';
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function activateLawyer(id) {
        if(confirm('Are you sure you want to activate this lawyer?')) {
            var form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = '<input type="hidden" name="lawyer_id" value="' + id + '"><input type="hidden" name="activate_lawyer" value="1">';
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function deleteLawyer(id) {
        if(confirm('Permanently delete this lawyer? This action cannot be undone.')) {
            window.location.href = '?delete=' + id;
        }
    }
    
    // Mobile sidebar toggle
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.querySelector('.sidebar');
    
    let overlay = document.getElementById('overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }
    
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>
</body>
</html>