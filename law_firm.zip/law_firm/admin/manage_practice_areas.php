<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$page_title = "Manage Practice Areas";
$user_name = $_SESSION['user_name'] ?? 'Admin';

// Handle Add Practice Area
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_practice'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $icon = $_POST['icon'];
    
    $stmt = $conn->prepare("INSERT INTO practice_areas (name, description, icon, is_active) VALUES (?, ?, ?, 1)");
    $stmt->bind_param("sss", $name, $description, $icon);
    
    if ($stmt->execute()) {
        $success = "Practice area added successfully!";
    } else {
        $error = "Error adding practice area: " . $conn->error;
    }
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM practice_areas WHERE id = $id");
    $success = "Practice area deleted successfully!";
}

// Handle Toggle Status
if (isset($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $conn->query("UPDATE practice_areas SET is_active = NOT is_active WHERE id = $id");
    $success = "Status updated successfully!";
}

// Get all practice areas
$practice_areas = $conn->query("SELECT * FROM practice_areas ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Practice Areas | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar */
        .admin-sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .admin-sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .admin-sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .admin-sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .admin-sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .admin-main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        /* Buttons */
        .btn-gold {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            border: none;
            transition: all 0.3s;
        }

        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212,175,55,0.3);
        }

        /* Table Styles */
        .table-custom thead {
            background: var(--primary-dark);
            color: white;
        }

        .table-custom thead th {
            padding: 12px 15px;
            font-weight: 600;
        }

        .table-custom tbody td {
            padding: 12px 15px;
            vertical-align: middle;
        }

        /* Card Styles */
        .card-modern {
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .card-modern .card-header {
            background: white;
            border-bottom: 2px solid rgba(212, 175, 55, 0.2);
            padding: 15px 20px;
        }

        .card-modern .card-header h5 {
            color: var(--primary-dark);
            font-weight: 700;
            margin: 0;
        }

        .card-modern .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        /* Modal Styles */
        .modal-header-custom {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .modal-header-custom .btn-close {
            background: white;
            opacity: 1;
        }

        .practice-icon {
            width: 40px;
            height: 40px;
            background: rgba(212, 175, 55, 0.1);
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .practice-icon i {
            font-size: 20px;
            color: var(--secondary);
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .admin-sidebar.show {
                left: 0;
            }
            .admin-main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
           
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
               
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lawyer_management.php">
                            <i class="fas fa-gavel"></i> Lawyer Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_attorneys.php">
                            <i class="fas fa-user-tie"></i> Manage Attorneys
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_practice_areas.php">
                            <i class="fas fa-briefcase"></i> Practice Areas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="client_master.php">
                            <i class="fas fa-user-friends"></i> Client Master
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_contact.php">
                            <i class="fas fa-address-card"></i> Contact Info
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="analytics.php">
                            <i class="fas fa-chart-line"></i> Analytics
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cases.php">
                            <i class="fas fa-briefcase"></i> All Cases
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../invoices.php">
                            <i class="fas fa-file-invoice-dollar"></i> Invoices
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="../profile.php">
                            <i class="fas fa-user-circle"></i> Profile Settings
                        </a>
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="admin-main-content">
            <div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3">
                <h1 class="h2" style="color: var(--primary-dark);">
                    <i class="fas fa-briefcase me-2" style="color: var(--secondary);"></i> Manage Practice Areas
                </h1>
                <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addPracticeModal">
                    <i class="fas fa-plus-circle me-2"></i> Add Practice Area
                </button>
            </div>
            
            <?php if(isset($success)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="card-modern">
                <div class="card-header">
                    <h5><i class="fas fa-list"></i> All Practice Areas</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-custom">
                                <tr>
                                    <th>Icon</th>
                                    <th>Practice Area</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($practice_areas && $practice_areas->num_rows > 0): ?>
                                    <?php while($area = $practice_areas->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <div class="practice-icon">
                                                <i class="<?php echo htmlspecialchars($area['icon']); ?>"></i>
                                            </div>
                                        </td>
                                        <td><strong><?php echo htmlspecialchars($area['name']); ?></strong></td>
                                        <td><?php echo substr(htmlspecialchars($area['description']), 0, 60); ?>...</td>
                                        <td>
                                            <span class="badge <?php echo $area['is_active'] ? 'bg-success' : 'bg-danger'; ?>">
                                                <?php echo $area['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="?toggle=<?php echo $area['id']; ?>" class="btn btn-sm btn-warning" title="Toggle Status">
                                                <i class="fas fa-toggle-on"></i>
                                            </a>
                                            <a href="?delete=<?php echo $area['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this practice area?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4">
                                            <i class="fas fa-briefcase fa-3x mb-3" style="color: var(--secondary); opacity: 0.3;"></i>
                                            <p class="text-muted">No practice areas found. Click "Add Practice Area" to create one.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Add Practice Area Modal -->
<div class="modal fade" id="addPracticeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i> Add Practice Area</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Practice Area Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="name" required placeholder="e.g., Corporate Law">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Icon Class <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="icon" required placeholder="e.g., fas fa-balance-scale">
                        <small class="text-muted">Use Font Awesome icon classes. <a href="https://fontawesome.com/icons" target="_blank">Browse icons</a></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3" placeholder="Describe this practice area..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_practice" class="btn btn-gold">Add Practice Area</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Mobile sidebar toggle
    const hamburger = document.getElementById('hamburger');
    const adminSidebar = document.querySelector('.admin-sidebar');
    
    // Create overlay if it doesn't exist
    let overlay = document.getElementById('overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }

    if (hamburger && adminSidebar && overlay) {
        hamburger.addEventListener('click', function() {
            adminSidebar.classList.toggle('show');
            overlay.style.display = adminSidebar.classList.contains('show') ? 'block' : 'none';
        });
        overlay.addEventListener('click', function() {
            adminSidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
    
    // Mobile menu button for small screens
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                adminSidebar.classList.toggle('show');
                overlay.style.display = adminSidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
</script>
</body>
</html>