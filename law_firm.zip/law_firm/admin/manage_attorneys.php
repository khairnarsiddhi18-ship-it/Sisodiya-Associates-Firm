<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$page_title = "Manage Attorneys";
$user_name = $_SESSION['user_name'] ?? 'Admin';

// Handle Add Attorney with Image Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_attorney'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    $bio = $_POST['bio'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $username = strtolower(str_replace(' ', '_', $full_name)) . rand(100, 999);
    
    // Handle image upload
    $profile_image = '';
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['profile_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'attorney_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            $upload_path = '../uploads/attorneys/' . $new_filename;
            
            // Create directory if not exists
            if (!file_exists('../uploads/attorneys/')) {
                mkdir('../uploads/attorneys/', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                $profile_image = 'uploads/attorneys/' . $new_filename;
            }
        }
    }
    
    $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name, phone, role, specialization, experience, bio, profile_image, is_active) VALUES (?, ?, ?, ?, ?, 'lawyer', ?, ?, ?, ?, 1)");
    $stmt->bind_param("sssssssss", $username, $email, $password, $full_name, $phone, $specialization, $experience, $bio, $profile_image);
    
    if ($stmt->execute()) {
        $success = "Attorney added successfully!";
    } else {
        $error = "Error adding attorney: " . $conn->error;
    }
}

// Handle Update Attorney with Image
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_attorney'])) {
    $id = $_POST['attorney_id'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    $bio = $_POST['bio'];
    
    // Handle image upload
    $profile_image = $_POST['existing_image'];
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['profile_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'attorney_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            $upload_path = '../uploads/attorneys/' . $new_filename;
            
            if (!file_exists('../uploads/attorneys/')) {
                mkdir('../uploads/attorneys/', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                // Delete old image if exists
                if ($profile_image && file_exists('../' . $profile_image)) {
                    unlink('../' . $profile_image);
                }
                $profile_image = 'uploads/attorneys/' . $new_filename;
            }
        }
    }
    
    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, specialization = ?, experience = ?, bio = ?, profile_image = ? WHERE id = ? AND role = 'lawyer'");
    $stmt->bind_param("sssssssi", $full_name, $email, $phone, $specialization, $experience, $bio, $profile_image, $id);
    
    if ($stmt->execute()) {
        $success = "Attorney updated successfully!";
    } else {
        $error = "Error updating attorney: " . $conn->error;
    }
}

// Handle Delete Attorney
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Get profile image to delete
    $img_query = $conn->query("SELECT profile_image FROM users WHERE id = $id AND role = 'lawyer'");
    $img_data = $img_query->fetch_assoc();
    if ($img_data && $img_data['profile_image'] && file_exists('../' . $img_data['profile_image'])) {
        unlink('../' . $img_data['profile_image']);
    }
    $conn->query("DELETE FROM users WHERE id = $id AND role = 'lawyer'");
    $success = "Attorney deleted successfully!";
}

// Handle Toggle Status
if (isset($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $conn->query("UPDATE users SET is_active = NOT is_active WHERE id = $id");
    $success = "Status updated successfully!";
}

// Get all attorneys
$attorneys = $conn->query("SELECT * FROM users WHERE role = 'lawyer' ORDER BY full_name");

// Get single attorney for edit modal
$edit_attorney = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM users WHERE id = $edit_id AND role = 'lawyer'");
    $edit_attorney = $edit_result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attorneys | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        /* Navbar Logo */
        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: var(--secondary);
            margin-right: 5px;
        }

        /* Sidebar Logo */
        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        /* Sidebar */
        .admin-sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .admin-sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .admin-sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary);
            transform: translateX(5px);
        }

        .admin-sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .admin-sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .admin-main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
        }

        /* Buttons */
        .btn-gold {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            border: none;
            transition: all 0.3s;
        }

        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212,175,55,0.3);
        }

        /* Table Styles */
        .table-custom thead {
            background: var(--primary-dark);
            color: white;
        }

        .table-custom thead th {
            padding: 12px 15px;
            font-weight: 600;
        }

        .table-custom tbody td {
            padding: 12px 15px;
            vertical-align: middle;
        }

        /* Card Styles */
        .card-modern {
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .card-modern .card-header {
            background: white;
            border-bottom: 2px solid rgba(212, 175, 55, 0.2);
            padding: 15px 20px;
        }

        .card-modern .card-header h5 {
            color: var(--primary-dark);
            font-weight: 700;
            margin: 0;
        }

        .card-modern .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        /* Modal Styles */
        .modal-header-custom {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .modal-header-custom .btn-close {
            background: white;
            opacity: 1;
        }

        /* Attorney Image Styles */
        .attorney-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--secondary);
        }

        .image-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
            margin-bottom: 10px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .admin-sidebar.show {
                left: 0;
            }
            .admin-main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-admin">
    <div class="container-fluid">
        <a class="navbar-logo" href="admin_dashboard.php">
            <?php 
            $logo_path = '../assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
           
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <div class="dropdown">
            <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" style="background: rgba(212,175,55,0.15);">
                <i class="fas fa-user-circle me-2"></i> <?php echo htmlspecialchars($user_name); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile Settings</a></li>
                <li><a class="dropdown-item" href="analytics.php"><i class="fas fa-chart-line me-2"></i> Analytics</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
                
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lawyer_management.php">
                            <i class="fas fa-gavel"></i> Lawyer Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_attorneys.php">
                            <i class="fas fa-user-tie"></i> Manage Attorneys
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_practice_areas.php">
                            <i class="fas fa-briefcase"></i> Practice Areas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="client_master.php">
                            <i class="fas fa-user-friends"></i> Client Master
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="analytics.php">
                            <i class="fas fa-chart-line"></i> Analytics
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cases.php">
                            <i class="fas fa-briefcase"></i> All Cases
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../invoices.php">
                            <i class="fas fa-file-invoice-dollar"></i> Invoices
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="../profile.php">
                            <i class="fas fa-user-circle"></i> Profile Settings
                        </a>
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="admin-main-content">
            <div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3">
                <h1 class="h2" style="color: var(--primary-dark);">
                    <i class="fas fa-user-tie me-2" style="color: var(--secondary);"></i> Manage Attorneys
                </h1>
                <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addAttorneyModal">
                    <i class="fas fa-plus-circle me-2"></i> Add New Attorney
                </button>
            </div>
            
            <?php if(isset($success)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="card-modern">
                <div class="card-header">
                    <h5><i class="fas fa-users"></i> All Attorneys</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-custom">
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Specialization</th>
                                    <th>Experience</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($attorneys && $attorneys->num_rows > 0): ?>
                                    <?php while($attorney = $attorneys->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <?php if($attorney['profile_image'] && file_exists('../' . $attorney['profile_image'])): ?>
                                                <img src="../<?php echo $attorney['profile_image']; ?>" class="attorney-avatar" alt="<?php echo htmlspecialchars($attorney['full_name']); ?>">
                                            <?php else: ?>
                                                <div class="attorney-avatar d-flex align-items-center justify-content-center" style="background: var(--secondary); color: var(--primary-dark); font-weight: bold; font-size: 18px;">
                                                    <?php echo strtoupper(substr($attorney['full_name'], 0, 1)); ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><strong><?php echo htmlspecialchars($attorney['full_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($attorney['email']); ?></td>
                                        <td><?php echo htmlspecialchars($attorney['specialization'] ?? 'General'); ?></td>
                                        <td><?php echo htmlspecialchars($attorney['experience'] ?? 'N/A'); ?> years</td>
                                        <td>
                                            <span class="badge <?php echo $attorney['is_active'] ? 'bg-success' : 'bg-danger'; ?>">
                                                <?php echo $attorney['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="?edit=<?php echo $attorney['id']; ?>" class="btn btn-sm btn-info" title="Edit" data-bs-toggle="modal" data-bs-target="#editAttorneyModal">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="?toggle=<?php echo $attorney['id']; ?>" class="btn btn-sm btn-warning" title="Toggle Status">
                                                <i class="fas fa-toggle-on"></i>
                                            </a>
                                            <a href="?delete=<?php echo $attorney['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this attorney?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <i class="fas fa-user-tie fa-3x mb-3" style="color: var(--secondary); opacity: 0.3;"></i>
                                            <p class="text-muted">No attorneys found. Click "Add New Attorney" to create one.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Add Attorney Modal -->
<div class="modal fade" id="addAttorneyModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title"><i class="fas fa-user-tie me-2"></i> Add New Attorney</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 text-center mb-3">
                            <div class="image-preview-container">
                                <img id="imagePreview" src="https://via.placeholder.com/100x100?text=Photo" class="image-preview">
                                <input type="file" class="form-control mt-2" name="profile_image" id="profile_image" accept="image/*" onchange="previewImage(this)">
                                <small class="text-muted">Upload profile image (JPG, PNG, GIF)</small>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control" name="phone">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Specialization</label>
                            <input type="text" class="form-control" name="specialization" placeholder="e.g., Criminal Law, Corporate Law">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Experience (Years)</label>
                            <input type="number" class="form-control" name="experience" step="0.5">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Bio / Introduction</label>
                            <textarea class="form-control" name="bio" rows="3" placeholder="Brief introduction about the attorney..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_attorney" class="btn btn-gold">Add Attorney</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Attorney Modal -->
<div class="modal fade" id="editAttorneyModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i> Edit Attorney</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="attorney_id" id="edit_id" value="">
                <input type="hidden" name="existing_image" id="edit_existing_image" value="">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 text-center mb-3">
                            <div class="image-preview-container">
                                <img id="editImagePreview" src="https://via.placeholder.com/100x100?text=Photo" class="image-preview">
                                <input type="file" class="form-control mt-2" name="profile_image" id="edit_profile_image" accept="image/*" onchange="previewEditImage(this)">
                                <small class="text-muted">Upload new image (leave empty to keep current)</small>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" id="edit_full_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" id="edit_email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control" name="phone" id="edit_phone">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Specialization</label>
                            <input type="text" class="form-control" name="specialization" id="edit_specialization">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Experience (Years)</label>
                            <input type="number" class="form-control" name="experience" id="edit_experience" step="0.5">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Bio / Introduction</label>
                            <textarea class="form-control" name="bio" rows="3" id="edit_bio"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_attorney" class="btn btn-gold">Update Attorney</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Image preview for add modal
    function previewImage(input) {
        const preview = document.getElementById('imagePreview');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    // Image preview for edit modal
    function previewEditImage(input) {
        const preview = document.getElementById('editImagePreview');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    // Populate edit modal with attorney data
    <?php if($edit_attorney): ?>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('edit_id').value = '<?php echo $edit_attorney['id']; ?>';
        document.getElementById('edit_full_name').value = '<?php echo addslashes($edit_attorney['full_name']); ?>';
        document.getElementById('edit_email').value = '<?php echo $edit_attorney['email']; ?>';
        document.getElementById('edit_phone').value = '<?php echo $edit_attorney['phone']; ?>';
        document.getElementById('edit_specialization').value = '<?php echo addslashes($edit_attorney['specialization'] ?? ''); ?>';
        document.getElementById('edit_experience').value = '<?php echo $edit_attorney['experience']; ?>';
        document.getElementById('edit_bio').value = '<?php echo addslashes($edit_attorney['bio'] ?? ''); ?>';
        document.getElementById('edit_existing_image').value = '<?php echo $edit_attorney['profile_image']; ?>';
        
        const editPreview = document.getElementById('editImagePreview');
        <?php if($edit_attorney['profile_image'] && file_exists('../' . $edit_attorney['profile_image'])): ?>
            editPreview.src = '../<?php echo $edit_attorney['profile_image']; ?>';
        <?php else: ?>
            editPreview.src = 'https://via.placeholder.com/100x100?text=Photo';
        <?php endif; ?>
    });
    <?php endif; ?>
    
    // Mobile sidebar toggle
    const hamburger = document.getElementById('hamburger');
    const adminSidebar = document.querySelector('.admin-sidebar');
    
    // Create overlay if it doesn't exist
    let overlay = document.getElementById('overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }

    if (hamburger && adminSidebar && overlay) {
        hamburger.addEventListener('click', function() {
            adminSidebar.classList.toggle('show');
            overlay.style.display = adminSidebar.classList.contains('show') ? 'block' : 'none';
        });
        overlay.addEventListener('click', function() {
            adminSidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>
</body>
</html>