<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and has permission
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'paralegal'])) {
    header("Location: login.php");
    exit();
}

// Check if case_id and lawyer_id are provided
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['case_id']) && isset($_POST['lawyer_id'])) {
    $case_id = (int)$_POST['case_id'];
    $lawyer_id = (int)$_POST['lawyer_id'];
    $assigned_by = $_SESSION['user_id'];
    
    // Update the case with assigned lawyer
    $stmt = $conn->prepare("UPDATE cases SET assigned_lawyer_id = ?, status = 'active', updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("ii", $lawyer_id, $case_id);
    
    if ($stmt->execute()) {
        // Get case and lawyer details for logging
        $case_info = $conn->query("SELECT case_number, title FROM cases WHERE id = $case_id")->fetch_assoc();
        $lawyer_info = $conn->query("SELECT full_name, email FROM users WHERE id = $lawyer_id")->fetch_assoc();
        
        // Log the assignment
        $log_action = "Assigned case " . $case_info['case_number'] . " to " . $lawyer_info['full_name'];
        $log_stmt = $conn->prepare("INSERT INTO system_logs (user_id, action, ip_address) VALUES (?, ?, ?)");
        $ip = $_SERVER['REMOTE_ADDR'];
        $log_stmt->bind_param("iss", $_SESSION['user_id'], $log_action, $ip);
        $log_stmt->execute();
        
        // Redirect back with success message
        $_SESSION['assignment_success'] = "Case successfully assigned to " . $lawyer_info['full_name'];
        header("Location: paralegal_dashboard.php#case-assignment");
        exit();
    } else {
        $_SESSION['assignment_error'] = "Error assigning case: " . $conn->error;
        header("Location: paralegal_dashboard.php#case-assignment");
        exit();
    }
} else {
    // If direct access without POST data
    header("Location: paralegal_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Case - ABT Law Firm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .message-card {
            background: white;
            border-radius: 30px;
            padding: 50px;
            text-align: center;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .icon-circle {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        .icon-circle i {
            font-size: 40px;
            color: #4A0E17;
        }

        .error-icon {
            background: linear-gradient(135deg, #C72A2A, #8B2635);
        }

        .error-icon i {
            color: white;
        }

        h2 {
            color: #4A0E17;
            font-weight: 800;
            margin-bottom: 15px;
        }

        .message-text {
            color: #4a5568;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .btn-dashboard {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 700;
            color: #4A0E17;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-dashboard:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
            color: #4A0E17;
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(212,175,55,0.3);
            border-top-color: #D4AF37;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

<div class="message-card">
    <?php if(isset($_SESSION['assignment_success'])): ?>
        <div class="icon-circle">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2>Case Assigned Successfully!</h2>
        <p class="message-text"><?php echo htmlspecialchars($_SESSION['assignment_success']); ?></p>
        <p class="text-muted small">Redirecting you back to dashboard...</p>
        <a href="paralegal_dashboard.php#case-assignment" class="btn-dashboard mt-3">
            <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
        </a>
        <?php unset($_SESSION['assignment_success']); ?>
        
    <?php elseif(isset($_SESSION['assignment_error'])): ?>
        <div class="icon-circle error-icon">
            <i class="fas fa-exclamation-circle"></i>
        </div>
        <h2>Assignment Failed</h2>
        <p class="message-text"><?php echo htmlspecialchars($_SESSION['assignment_error']); ?></p>
        <a href="paralegal_dashboard.php#case-assignment" class="btn-dashboard mt-3">
            <i class="fas fa-arrow-left me-2"></i> Try Again
        </a>
        <?php unset($_SESSION['assignment_error']); ?>
        
    <?php else: ?>
        <div class="icon-circle error-icon">
            <i class="fas fa-ban"></i>
        </div>
        <h2>Invalid Request</h2>
        <p class="message-text">Please submit the assignment form from the dashboard.</p>
        <a href="paralegal_dashboard.php#case-assignment" class="btn-dashboard mt-3">
            <i class="fas fa-arrow-left me-2"></i> Go to Dashboard
        </a>
    <?php endif; ?>
</div>

<script>
    // Auto redirect after 3 seconds on success
    <?php if(isset($_SESSION['assignment_success'])): ?>
    setTimeout(function() {
        window.location.href = 'paralegal_dashboard.php#case-assignment';
    }, 3000);
    <?php endif; ?>
</script>

</body>
</html>