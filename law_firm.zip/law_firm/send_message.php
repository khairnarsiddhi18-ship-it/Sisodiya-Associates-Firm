<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$user_name = $_SESSION['user_name'];

// Handle sending message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $to_user_id = $_POST['to_user_id'];
    $message = trim($_POST['message']);
    $subject = trim($_POST['subject'] ?? '');
    $case_id = !empty($_POST['case_id']) ? $_POST['case_id'] : null;
    
    if (empty($to_user_id)) {
        $error = "Please select a recipient.";
    } elseif (empty($message)) {
        $error = "Please enter a message.";
    } else {
        $stmt = $conn->prepare("INSERT INTO messages (from_user_id, to_user_id, subject, message, case_id, status, created_at) VALUES (?, ?, ?, ?, ?, 'unread', NOW())");
        $stmt->bind_param("iissi", $user_id, $to_user_id, $subject, $message, $case_id);
        
        if ($stmt->execute()) {
            $success = "Message sent successfully!";
            
            // Optional: Add notification logic here
            // You can also add email notification if needed
        } else {
            $error = "Error sending message: " . $conn->error;
        }
    }
}

// Get list of users to send messages to (based on role)
if ($user_role == 'client') {
    // Client can message lawyers and paralegals assigned to their cases
    $recipients_query = "
        SELECT DISTINCT u.id, u.full_name, u.role 
        FROM users u
        JOIN cases c ON (c.assigned_lawyer_id = u.id OR c.client_id = u.id)
        WHERE (u.role IN ('lawyer', 'paralegal') AND c.client_id = $user_id)
        UNION
        SELECT id, full_name, role FROM users WHERE role IN ('admin')
        ORDER BY full_name
    ";
} elseif ($user_role == 'lawyer') {
    // Lawyer can message clients, paralegals, and admins
    $recipients_query = "
        SELECT DISTINCT u.id, u.full_name, u.role 
        FROM users u
        JOIN cases c ON (c.client_id = u.id OR c.assigned_lawyer_id = u.id)
        WHERE (u.role IN ('client', 'paralegal') AND c.assigned_lawyer_id = $user_id)
        UNION
        SELECT id, full_name, role FROM users WHERE role IN ('admin')
        ORDER BY full_name
    ";
} elseif ($user_role == 'paralegal') {
    // Paralegal can message lawyers, clients, and admins
    $recipients_query = "
        SELECT DISTINCT u.id, u.full_name, u.role 
        FROM users u
        WHERE u.role IN ('lawyer', 'client', 'admin')
        ORDER BY full_name
    ";
} elseif ($user_role == 'admin') {
    // Admin can message everyone
    $recipients_query = "
        SELECT id, full_name, role 
        FROM users 
        WHERE id != $user_id 
        ORDER BY full_name
    ";
} else {
    $recipients_query = "SELECT id, full_name, role FROM users WHERE role IN ('lawyer', 'paralegal', 'admin') ORDER BY full_name";
}

$recipients = $conn->query($recipients_query);

// Get user's cases for dropdown (optional)
$cases_query = "";
if ($user_role == 'client') {
    $cases_query = "SELECT id, case_number, title FROM cases WHERE client_id = $user_id ORDER BY created_at DESC";
} elseif ($user_role == 'lawyer') {
    $cases_query = "SELECT id, case_number, title FROM cases WHERE assigned_lawyer_id = $user_id ORDER BY created_at DESC";
} elseif ($user_role == 'paralegal') {
    $cases_query = "SELECT id, case_number, title FROM cases WHERE status = 'active' ORDER BY created_at DESC LIMIT 50";
} else {
    $cases_query = "SELECT id, case_number, title FROM cases ORDER BY created_at DESC LIMIT 50";
}
$cases = $conn->query($cases_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Send Message | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: #D4AF37;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Page Container */
        .page-container {
            margin-top: 70px;
            padding: 30px 0 50px;
            min-height: 100vh;
        }

        /* Message Card */
        .message-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
        }

        .message-card .card-header {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            color: white;
            border: none;
            padding: 20px 25px;
        }

        .message-card .card-header h4 {
            margin: 0;
            font-weight: 700;
        }

        .message-card .card-header h4 i {
            color: #D4AF37;
            margin-right: 10px;
        }

        .message-card .card-body {
            padding: 30px;
        }

        /* Form Controls */
        .form-label {
            font-weight: 600;
            color: #4A0E17;
            margin-bottom: 8px;
        }

        .form-label i {
            color: #D4AF37;
            margin-right: 6px;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 12px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        textarea.form-control {
            resize: vertical;
        }

        /* Buttons */
        .btn-send {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            padding: 12px 25px;
            border-radius: 12px;
            color: #4A0E17;
            font-weight: 700;
            transition: all 0.3s;
        }

        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .btn-back {
            background: transparent;
            border: 1px solid #D4AF37;
            padding: 12px 25px;
            border-radius: 12px;
            color: #4A0E17;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-back:hover {
            background: #D4AF37;
            color: #4A0E17;
            transform: translateY(-2px);
        }

        /* Alert Styles */
        .alert-success {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        .alert-danger {
            background: #f8d7da;
            border-left: 4px solid #ef4444;
            color: #721c24;
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        /* Recipient Badge */
        .recipient-badge {
            display: inline-block;
            background: rgba(212, 175, 55, 0.1);
            color: #D4AF37;
            padding: 2px 8px;
            border-radius: 50px;
            font-size: 11px;
            margin-left: 8px;
        }

        @media (max-width: 768px) {
            .message-card .card-body {
                padding: 20px;
            }
            .btn-send, .btn-back {
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="messages.php"><i class="fas fa-envelope me-1"></i> Messages</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="page-container">
    <div class="container">
        <div class="message-card">
            <div class="card-header">
                <h4><i class="fas fa-paper-plane"></i> Send New Message</h4>
            </div>
            <div class="card-body">
                <?php if(isset($success)): ?>
                    <div class="alert-success">
                        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="messages.php" class="btn-back">
                            <i class="fas fa-inbox me-2"></i> Go to Inbox
                        </a>
                        <a href="send_message.php" class="btn-send ms-2">
                            <i class="fas fa-plus me-2"></i> Send Another Message
                        </a>
                    </div>
                <?php else: ?>
                    <?php if(isset($error)): ?>
                        <div class="alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-user"></i> To</label>
                            <select class="form-select" name="to_user_id" required>
                                <option value="">Select recipient...</option>
                                <?php if($recipients && $recipients->num_rows > 0): ?>
                                    <?php while($recipient = $recipients->fetch_assoc()): ?>
                                        <option value="<?php echo $recipient['id']; ?>" <?php echo (isset($_GET['to']) && $_GET['to'] == $recipient['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($recipient['full_name']); ?>
                                            <span class="recipient-badge"><?php echo ucfirst($recipient['role']); ?></span>
                                        </option>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <option value="" disabled>No recipients available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-tag"></i> Subject (Optional)</label>
                            <input type="text" class="form-control" name="subject" placeholder="Brief subject line...">
                        </div>
                        
                        <?php if($cases && $cases->num_rows > 0): ?>
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-briefcase"></i> Related Case (Optional)</label>
                                <select class="form-select" name="case_id">
                                    <option value="">No specific case</option>
                                    <?php while($case = $cases->fetch_assoc()): ?>
                                        <option value="<?php echo $case['id']; ?>">
                                            <?php echo htmlspecialchars($case['case_number']); ?> - <?php echo htmlspecialchars(substr($case['title'], 0, 50)); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-comment"></i> Message</label>
                            <textarea class="form-control" name="message" rows="6" required placeholder="Type your message here..."></textarea>
                        </div>
                        
                        <div class="d-flex gap-3 justify-content-end flex-wrap">
                            <a href="messages.php" class="btn-back">
                                <i class="fas fa-arrow-left me-2"></i> Cancel
                            </a>
                            <button type="submit" name="send_message" class="btn-send">
                                <i class="fas fa-paper-plane me-2"></i> Send Message
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Tips -->
        <div class="text-center mt-4">
            <small class="text-muted">
                <i class="fas fa-lock me-1"></i> Your messages are private and secure.
                All communications are confidential.
            </small>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>