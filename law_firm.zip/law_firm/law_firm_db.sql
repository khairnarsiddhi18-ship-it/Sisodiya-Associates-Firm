-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2026 at 05:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `law_firm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `case_number` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `case_type` varchar(100) DEFAULT NULL,
  `filing_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `assigned_lawyer_id` int(11) DEFAULT NULL,
  `status` enum('pending','active','closed','archived') DEFAULT 'pending',
  `progress` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `case_number`, `title`, `case_type`, `filing_date`, `description`, `client_id`, `assigned_lawyer_id`, `status`, `progress`, `created_at`, `updated_at`) VALUES
(1, 'CASE-20260530-3679', 'family law', NULL, NULL, 'hello sir..', 2, 3, 'active', 0, '2026-05-30 05:21:13', '2026-05-30 05:21:13'),
(2, 'CASE-20260530-4503', 'injury', NULL, NULL, 'good maorning..', 2, 3, 'active', 47, '2026-05-30 05:22:03', '2026-05-30 05:22:03'),
(3, 'CASE-20260530-7578', 'Walk-in Case', NULL, NULL, 'family injury', 8, 3, 'active', 42, '2026-05-30 05:26:13', '2026-06-02 05:48:44'),
(4, 'CASE-20260602-5261', 'injury', NULL, NULL, 'personal injury', 2, 3, 'active', 34, '2026-06-02 05:44:39', '2026-06-02 05:44:39'),
(5, 'CASE-20260602-3228', 'family law', NULL, NULL, 'personal..', 2, 3, 'active', 67, '2026-06-02 05:46:33', '2026-06-02 05:46:33'),
(6, 'CASE-20260603-8267', 'relationship problem ', NULL, NULL, 'na', 11, 3, 'pending', 0, '2026-06-03 15:00:12', '2026-06-03 15:00:12'),
(7, 'CASE-20260640-0750', 'child custody', 'Family', '2026-06-03', 'child custody case from  child\'s mother', 13, 3, 'active', 0, '2026-06-04 02:20:53', '2026-06-04 02:20:53'),
(8, 'CASE-20260530-4509', 'child custody', 'Family', '2026-06-04', 'na', 14, 3, 'active', 0, '2026-06-04 06:24:54', '2026-06-04 06:24:54');

-- --------------------------------------------------------

--
-- Table structure for table `case_lawyer_assignments`
--

CREATE TABLE `case_lawyer_assignments` (
  `id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `lawyer_id` int(11) NOT NULL,
  `assigned_date` datetime NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `case_notes`
--

CREATE TABLE `case_notes` (
  `id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `case_notes`
--

INSERT INTO `case_notes` (`id`, `case_id`, `user_id`, `note`, `created_at`) VALUES
(1, 7, 3, 'Case filed by lawyer sarthak Khairnar on June 03, 2026', '2026-06-04 07:50:53'),
(2, 8, 3, 'Case filed by lawyer sarthak Khairnar on June 04, 2026', '2026-06-04 11:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `case_progress`
--

CREATE TABLE `case_progress` (
  `id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `case_progress`
--

INSERT INTO `case_progress` (`id`, `case_id`, `user_id`, `note`, `created_at`) VALUES
(1, 5, 10, 'case is in progress', '2026-06-05 11:56:30'),
(2, 5, 10, 'case is in progress', '2026-06-05 11:58:09');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_conversations`
--

CREATE TABLE `chatbot_conversations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `intent` varchar(50) DEFAULT NULL,
  `confidence` decimal(5,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chatbot_conversations`
--

INSERT INTO `chatbot_conversations` (`id`, `user_id`, `session_id`, `question`, `answer`, `intent`, `confidence`, `created_at`) VALUES
(1, 2, 'ilbhqprc9goushv12q4totrt16', 'what is the status of my case?', 'You can check your case status by logging into your client dashboard and clicking on \"My Cases\". Each case has a progress bar showing the current stage. You can also view detailed case information including upcoming hearings and document submissions.', 'faq', NULL, '2026-06-02 04:35:08'),
(2, 2, 'ilbhqprc9goushv12q4totrt16', 'how do i check my case status?', 'You can check your case status by logging into your client dashboard and clicking on \"My Cases\". Each case has a progress bar showing the current stage. You can also view detailed case information including upcoming hearings and document submissions.', 'faq', NULL, '2026-06-02 04:35:13'),
(3, 2, 'ilbhqprc9goushv12q4totrt16', 'when is my next hearing?', 'Your next hearing is on June 7, 2026 at 11:53:00 for Case #CASE-20260530-3679.\n\nVenue: Superior Court\n\nYou will receive a reminder 48 hours before the hearing.', 'hearings', NULL, '2026-06-02 04:35:17'),
(4, 2, 'u9u0v4u9s489qv8feeqhqn7nu4', 'what is the status of my case?', 'You can check your case status by logging into your client dashboard and clicking on \"My Cases\". Each case has a progress bar showing the current stage. You can also view detailed case information including upcoming hearings and document submissions.', 'faq', NULL, '2026-06-03 06:01:43'),
(5, 2, 'u9u0v4u9s489qv8feeqhqn7nu4', 'how to upload documents?', 'Required documents vary by case type. Common documents include: identification proof, case-related correspondence, contracts/agreements, medical reports (for injury cases), property documents (for real estate), and any court notices. Upload documents in the Documents section of your dashboard.', 'faq', NULL, '2026-06-03 06:01:54'),
(6, 2, 'u9u0v4u9s489qv8feeqhqn7nu4', 'can you guess my name', 'Thank you for your question. For specific legal advice regarding your case, please contact your assigned lawyer directly through the Message Board. You can also ask me about:\n\n• Case status and progress\n• Upcoming hearings\n• Document uploads\n• Billing and invoices\n• Appointment scheduling\n• Contacting your lawyer', 'general', NULL, '2026-06-03 06:02:23');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_faq`
--

CREATE TABLE `chatbot_faq` (
  `id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `keywords` text DEFAULT NULL,
  `priority` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chatbot_faq`
--

INSERT INTO `chatbot_faq` (`id`, `question`, `answer`, `category`, `keywords`, `priority`, `is_active`, `created_at`) VALUES
(1, 'How do I check my case status?', 'You can check your case status by logging into your client dashboard and clicking on \"My Cases\". Each case has a progress bar showing the current stage. You can also view detailed case information including upcoming hearings and document submissions.', 'Case Management', 'case status, progress, update', 0, 1, '2026-06-01 04:20:40'),
(2, 'How can I contact my lawyer?', 'You can contact your assigned lawyer through multiple ways: 1) Send a message via the Message Board in your dashboard, 2) Schedule an appointment through the Book Appointment section, 3) Call our office at (555) 123-4567 and ask for your lawyer, or 4) Reply to emails from your lawyer.', 'Communication', 'contact lawyer, message, email, call', 0, 1, '2026-06-01 04:20:40'),
(3, 'What documents do I need to upload?', 'Required documents vary by case type. Common documents include: identification proof, case-related correspondence, contracts/agreements, medical reports (for injury cases), property documents (for real estate), and any court notices. Upload documents in the Documents section of your dashboard.', 'Documents', 'documents upload, required papers, evidence', 0, 1, '2026-06-01 04:20:40'),
(4, 'How are legal fees calculated?', 'Our fee structure depends on your case type: 1) Hourly Rate - Billed per hour of work, 2) Contingency Fee - Percentage of settlement (common in injury cases), 3) Flat Fee - Fixed amount for specific services, or 4) Retainer - Advance payment for ongoing services. Check your engagement letter for details.', 'Billing', 'fees, payment, charges, cost', 0, 1, '2026-06-01 04:20:40'),
(5, 'When is my next court hearing?', 'Upcoming hearings are displayed on your client dashboard and in the Hearings section. You can also enable notifications to receive reminders 48 hours before each hearing.', 'Hearings', 'hearing date, court appearance, schedule', 0, 1, '2026-06-01 04:20:40'),
(6, 'How do I schedule an appointment?', 'To schedule an appointment: 1) Go to \"Book Appointment\" in your dashboard, 2) Select your preferred lawyer, 3) Choose date and time, 4) Add notes about your legal matter, and 5) Submit the request. You will receive confirmation within 24 hours.', 'Appointments', 'appointment, meeting, consultation', 0, 1, '2026-06-01 04:20:40'),
(7, 'Can I get a refund?', 'Refund policies vary by case type and fee structure. Please refer to your retainer agreement or contact our billing department at billing@lawfirm.com for specific refund inquiries.', 'Billing', 'refund, money back', 0, 1, '2026-06-01 04:20:40'),
(8, 'How long will my case take?', 'Case duration depends on complexity, court schedules, and opposition cooperation. Simple cases may take 3-6 months, while complex litigation can take 1-2 years. Your lawyer will provide regular updates on timeline expectations.', 'Case Management', 'duration, timeline, how long', 0, 1, '2026-06-01 04:20:40'),
(9, 'How do I check my case status?', 'You can check your case status by logging into your client dashboard and clicking on \"My Cases\". Each case has a progress bar showing the current stage. You can also view detailed case information including upcoming hearings and document submissions.', 'Case Management', 'case status progress update', 10, 1, '2026-06-02 04:34:24'),
(10, 'How can I contact my lawyer?', 'You can contact your assigned lawyer through multiple ways: 1) Send a message via the Message Board in your dashboard, 2) Schedule an appointment through the Book Appointment section, 3) Call our office at (555) 123-4567 and ask for your lawyer, or 4) Reply to emails from your lawyer.', 'Communication', 'contact lawyer message email call', 10, 1, '2026-06-02 04:34:24'),
(11, 'What documents do I need to upload?', 'Required documents vary by case type. Common documents include: identification proof, case-related correspondence, contracts/agreements, medical reports (for injury cases), property documents (for real estate), and any court notices. Upload documents in the Documents section of your dashboard.', 'Documents', 'documents upload required papers evidence', 10, 1, '2026-06-02 04:34:24'),
(12, 'How are legal fees calculated?', 'Our fee structure depends on your case type: 1) Hourly Rate - Billed per hour of work, 2) Contingency Fee - Percentage of settlement (common in injury cases), 3) Flat Fee - Fixed amount for specific services, or 4) Retainer - Advance payment for ongoing services. Check your engagement letter for details.', 'Billing', 'fees payment charges cost', 10, 1, '2026-06-02 04:34:24'),
(13, 'When is my next court hearing?', 'Upcoming hearings are displayed on your client dashboard and in the Hearings section. You can also enable notifications to receive reminders 48 hours before each hearing.', 'Hearings', 'hearing date court appearance schedule', 10, 1, '2026-06-02 04:34:24'),
(14, 'How do I schedule an appointment?', 'To schedule an appointment: 1) Go to \"Book Appointment\" in your dashboard, 2) Select your preferred lawyer, 3) Choose date and time, 4) Add notes about your legal matter, and 5) Submit the request. You will receive confirmation within 24 hours.', 'Appointments', 'appointment meeting consultation', 10, 1, '2026-06-02 04:34:24'),
(15, 'How to upload documents?', 'To upload documents: 1) Go to Documents section, 2) Select the relevant case, 3) Click \"Choose File\" to select your document, 4) Check \"Share with client\" if applicable, and 5) Click \"Upload Document\". Supported formats include PDF, DOC, DOCX, JPG, and PNG.', 'Documents', 'upload documents files', 10, 1, '2026-06-02 04:34:24'),
(16, 'How to pay my invoice?', 'To pay an invoice: 1) Go to Billing Portal in your dashboard, 2) Find the invoice you want to pay, 3) Click \"Pay Now\" button, 4) Enter your payment details, and 5) Confirm the payment. You will receive a receipt via email.', 'Billing', 'pay invoice payment bill', 10, 1, '2026-06-02 04:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_intents`
--

CREATE TABLE `chatbot_intents` (
  `id` int(11) NOT NULL,
  `intent_name` varchar(100) NOT NULL,
  `keywords` text NOT NULL,
  `response_template` text NOT NULL,
  `requires_auth` tinyint(1) DEFAULT 0,
  `action_type` varchar(50) DEFAULT 'text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id`, `type`, `value`, `icon`, `display_order`, `is_active`, `updated_at`) VALUES
(1, 'address', '124 Legal Street, Suite 100, New York, NY 10001', 'fas fa-map-marker-alt', 1, 1, '2026-06-05 22:23:27'),
(2, 'phone', 'Phone: (555) 123-4567<br>Fax: (555) 123-4568<br>24/7 Emergency: (555) 123-4569', 'fas fa-phone-alt', 2, 1, '2026-06-05 22:22:56'),
(3, 'email', 'General: info@abtlaw.com<br>Support: support@abtlaw.com<br>Billing: billing@abtlaw.com', 'fas fa-envelope', 3, 1, '2026-06-05 22:22:56'),
(4, 'hours', 'Monday - Friday: 9:00 AM - 6:00 PM<br>Saturday: 10:00 AM - 2:00 PM<br>Sunday: Closed<br>Emergency: 24/7 Available', 'fas fa-clock', 4, 1, '2026-06-05 22:22:56'),
(5, 'map_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bbafd23%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1699999999999!5m2!1sen!2sus', 'fas fa-map', 5, 1, '2026-06-05 22:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `is_shared` tinyint(1) DEFAULT 0,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `case_id`, `uploaded_by`, `file_name`, `file_path`, `file_type`, `file_size`, `is_shared`, `uploaded_at`) VALUES
(1, 1, 3, '1780118565_WIN_20260518_19_52_04_Pro.jpg', 'uploads/1780118565_WIN_20260518_19_52_04_Pro.jpg', '0', 193504, 1, '2026-05-30 05:22:45');

-- --------------------------------------------------------

--
-- Table structure for table `hearings`
--

CREATE TABLE `hearings` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `hearing_date` date NOT NULL,
  `hearing_time` time NOT NULL,
  `venue` varchar(200) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `hearing_type` varchar(100) DEFAULT 'general',
  `hearing_reason` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hearings`
--

INSERT INTO `hearings` (`id`, `case_id`, `hearing_date`, `hearing_time`, `venue`, `notes`, `created_by`, `created_at`, `hearing_type`, `hearing_reason`) VALUES
(1, 1, '2026-06-07', '11:53:00', 'Superior Court', 'good morning..', 3, '2026-05-30 05:23:48', 'general', NULL),
(2, 6, '2026-06-26', '11:29:00', 'Superior Court', 'na', 4, '2026-06-03 15:00:12', 'initial_hearing', 'other'),
(3, 5, '2026-06-11', '17:31:00', 'Superior Court', 'na', 10, '2026-06-05 11:57:25', 'general', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `case_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `paid_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `total_paid` decimal(10,2) DEFAULT 0.00,
  `remaining_balance` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `client_id`, `case_id`, `invoice_number`, `amount`, `status`, `due_date`, `created_at`, `paid_amount`, `paid_date`, `payment_method`, `transaction_id`, `description`, `total_paid`, `remaining_balance`) VALUES
(1, 2, 1, 'INV-20260603-1035', 2000.00, 'paid', '2026-06-03', '2026-06-03 14:07:31', 2000.00, NULL, NULL, NULL, 'family injury case', 0.00, 0.00),
(2, 2, 2, 'INV-20260603-8701', 200.00, 'paid', '2026-06-04', '2026-06-03 14:12:58', 100.00, NULL, NULL, NULL, 'injury case', 0.00, 0.00),
(3, 2, 3, 'INV-20260603-6367', 1800.00, 'paid', '2026-07-05', '2026-06-03 14:13:27', 1800.00, NULL, NULL, NULL, 'walk in case', 0.00, 0.00),
(4, 13, 7, 'INV-20260603-4413', 4600.00, '', '2026-06-22', '2026-06-04 02:58:59', 1600.00, NULL, NULL, NULL, 'na', 0.00, 0.00),
(5, 11, 4, 'INV-20260603-5839', 3000.00, 'pending', '2026-06-16', '2026-06-04 02:59:36', 0.00, NULL, NULL, NULL, 'na', 0.00, 0.00),
(6, 14, 1, 'INV-20260604-6194', 3400.00, 'pending', '2026-06-26', '2026-06-04 16:24:54', 0.00, NULL, NULL, NULL, 'na', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `lawyer_profiles`
--

CREATE TABLE `lawyer_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `experience_years` decimal(3,1) DEFAULT NULL,
  `bar_number` varchar(50) DEFAULT NULL,
  `education` text DEFAULT NULL,
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user_id` int(11) DEFAULT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('unread','read','archived') DEFAULT 'unread',
  `case_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `subject`, `message`, `status`, `case_id`, `is_read`, `created_at`, `read_at`) VALUES
(1, 2, 3, 'interview invitation', 'hello..', 'unread', NULL, 1, '2026-05-31 12:20:19', NULL),
(2, 2, 3, 'interview invitation', 'na', 'unread', 5, 1, '2026-06-05 16:32:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expiry` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `status` enum('pending','completed','failed','refunded') DEFAULT 'completed',
  `notes` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `invoice_id`, `client_id`, `case_id`, `amount`, `payment_method`, `transaction_id`, `payment_date`, `status`, `notes`, `recorded_by`, `created_at`) VALUES
(1, 1, 2, 1, 2000.00, 'cash', 'cash', '2026-06-03', 'completed', 'na', 3, '2026-06-03 14:08:38'),
(2, 3, 8, 3, 1800.00, 'cash', 'cash', '2026-06-03', 'completed', '200 pending', 3, '2026-06-03 14:14:51'),
(3, 2, 2, 2, 100.00, 'cash', 'cash', '2026-06-03', 'completed', 'na', 3, '2026-06-04 02:53:18'),
(4, 4, 13, 7, 1600.00, 'cash', 'cash', '2026-06-05', 'completed', 'na', 3, '2026-06-05 07:14:56');

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_summary`
-- (See below for the actual view)
--
CREATE TABLE `payment_summary` (
`case_id` int(11)
,`case_number` varchar(50)
,`client_id` int(11)
,`client_name` varchar(100)
,`assigned_lawyer_id` int(11)
,`lawyer_name` varchar(100)
,`total_billed` decimal(32,2)
,`total_paid` decimal(32,2)
,`balance_due` decimal(33,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `practice_areas`
--

CREATE TABLE `practice_areas` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fas fa-gavel',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practice_areas`
--

INSERT INTO `practice_areas` (`id`, `name`, `description`, `icon`, `is_active`, `created_at`) VALUES
(1, 'Corporate Law', 'Expert guidance for mergers, acquisitions, and business formation.', 'fas fa-building', 0, '2026-06-05 20:11:30'),
(2, 'Real Estate', 'Property disputes, contracts, and smooth transactions.', 'fas fa-home', 1, '2026-06-05 20:11:30'),
(3, 'Medical Malpractice', 'Protecting patient rights in negligence cases.', 'fas fa-user-md', 1, '2026-06-05 20:11:30'),
(4, 'Criminal Defense', 'Aggressive representation for criminal cases.', 'fas fa-gavel', 1, '2026-06-05 20:11:30'),
(5, 'Family Law', 'Compassionate handling of divorce and custody.', 'fas fa-heart', 1, '2026-06-05 20:11:30'),
(6, 'Immigration Law', 'Expert visa and citizenship guidance.', 'fas fa-passport', 1, '2026-06-05 20:11:30');

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_logs`
--

INSERT INTO `system_logs` (`id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 2, 'login', NULL, '::1', '2026-05-30 04:03:21'),
(2, 3, 'login', NULL, '::1', '2026-05-30 04:06:35'),
(3, 4, 'login', NULL, '::1', '2026-05-30 04:09:04'),
(4, 6, 'login', NULL, '::1', '2026-05-30 04:13:00'),
(5, 2, 'login', NULL, '::1', '2026-05-30 05:17:47'),
(6, 2, 'logout', NULL, NULL, '2026-05-30 05:19:48'),
(7, 3, 'login', NULL, '::1', '2026-05-30 05:20:02'),
(8, 3, 'logout', NULL, NULL, '2026-05-30 05:24:23'),
(9, 4, 'login', NULL, '::1', '2026-05-30 05:24:48'),
(10, 4, 'logout', NULL, NULL, '2026-05-30 05:27:22'),
(11, 6, 'login', NULL, '::1', '2026-05-30 05:27:36'),
(12, 6, 'logout', NULL, NULL, '2026-05-30 05:32:16'),
(13, 2, 'login', NULL, '::1', '2026-05-31 12:18:50'),
(14, 2, 'logout', NULL, NULL, '2026-05-31 12:23:50'),
(15, 2, 'login', NULL, '::1', '2026-06-01 04:26:29'),
(16, 2, 'logout', NULL, NULL, '2026-06-01 04:27:53'),
(17, 2, 'login', NULL, '::1', '2026-06-01 05:41:19'),
(18, 2, 'logout', NULL, NULL, '2026-06-01 05:52:54'),
(19, 2, 'login', NULL, '::1', '2026-06-01 06:14:16'),
(20, 2, 'logout', NULL, NULL, '2026-06-01 06:15:33'),
(21, 3, 'login', NULL, '::1', '2026-06-01 06:18:01'),
(22, 3, 'logout', NULL, NULL, '2026-06-01 06:19:30'),
(23, 6, 'login', NULL, '::1', '2026-06-01 14:41:30'),
(24, 6, 'logout', NULL, NULL, '2026-06-01 14:42:15'),
(25, 4, 'login', NULL, '::1', '2026-06-01 14:42:57'),
(26, 3, 'login', NULL, '::1', '2026-06-01 14:44:28'),
(27, 3, 'logout', NULL, NULL, '2026-06-01 14:45:19'),
(28, 10, 'login', NULL, '::1', '2026-06-02 04:11:45'),
(29, 10, 'logout', NULL, NULL, '2026-06-02 04:25:08'),
(30, 2, 'login', NULL, '::1', '2026-06-02 04:27:11'),
(31, 2, 'logout', NULL, NULL, '2026-06-02 04:39:38'),
(32, 3, 'login', NULL, '::1', '2026-06-02 04:40:22'),
(33, 3, 'logout', NULL, NULL, '2026-06-02 04:52:29'),
(34, 3, 'login', NULL, '::1', '2026-06-02 04:56:51'),
(35, 3, 'logout', NULL, NULL, '2026-06-02 05:01:19'),
(36, 4, 'login', NULL, '::1', '2026-06-02 05:02:10'),
(37, 4, 'logout', NULL, NULL, '2026-06-02 05:06:51'),
(38, 4, 'login', NULL, '::1', '2026-06-02 05:14:43'),
(39, 4, 'Assigned case CASE-20260530-7578 to sarthak Khairnar', NULL, '::1', '2026-06-02 05:14:56'),
(40, 4, 'logout', NULL, NULL, '2026-06-02 05:18:24'),
(41, 6, 'login', NULL, '::1', '2026-06-02 05:21:36'),
(42, 6, 'logout', NULL, NULL, '2026-06-02 05:30:20'),
(43, 10, 'login', NULL, '::1', '2026-06-02 05:41:16'),
(44, 10, 'logout', NULL, NULL, '2026-06-02 05:47:03'),
(45, 3, 'login', NULL, '::1', '2026-06-02 05:47:39'),
(46, 3, 'logout', NULL, NULL, '2026-06-02 05:52:25'),
(47, 4, 'login', NULL, '::1', '2026-06-02 05:55:53'),
(48, 4, 'logout', NULL, NULL, '2026-06-02 05:58:00'),
(49, 6, 'login', NULL, '::1', '2026-06-02 05:58:40'),
(50, 6, 'logout', NULL, NULL, '2026-06-02 06:01:09'),
(51, 10, 'login', NULL, '::1', '2026-06-02 15:58:33'),
(52, 10, 'login', NULL, '::1', '2026-06-03 02:47:49'),
(53, 10, 'logout', NULL, NULL, '2026-06-03 02:51:37'),
(54, 3, 'login', NULL, '::1', '2026-06-03 02:52:20'),
(55, 3, 'logout', NULL, NULL, '2026-06-03 03:06:26'),
(56, 4, 'login', NULL, '::1', '2026-06-03 03:07:18'),
(57, 3, 'login', NULL, '::1', '2026-06-03 05:29:19'),
(58, 3, 'logout', NULL, NULL, '2026-06-03 05:36:06'),
(59, 3, 'login', NULL, '::1', '2026-06-03 05:43:34'),
(60, 3, 'logout', NULL, NULL, '2026-06-03 05:44:09'),
(61, 3, 'login', NULL, '::1', '2026-06-03 05:48:42'),
(62, 3, 'logout', NULL, NULL, '2026-06-03 06:00:46'),
(63, 2, 'login', NULL, '::1', '2026-06-03 06:01:27'),
(64, 2, 'logout', NULL, NULL, '2026-06-03 06:07:31'),
(65, 4, 'login', NULL, '::1', '2026-06-03 06:14:02'),
(66, 4, 'logout', NULL, NULL, '2026-06-03 06:14:07'),
(67, 3, 'login', NULL, '::1', '2026-06-03 06:15:12'),
(68, 3, 'logout', NULL, NULL, '2026-06-03 06:15:26'),
(69, 6, 'login', NULL, '::1', '2026-06-03 06:15:51'),
(70, 6, 'logout', NULL, NULL, '2026-06-03 06:16:04'),
(71, 10, 'login', NULL, '::1', '2026-06-03 06:16:32'),
(72, 10, 'logout', NULL, NULL, '2026-06-03 06:16:41'),
(73, 3, 'login', NULL, '::1', '2026-06-03 06:17:07'),
(74, 3, 'logout', NULL, NULL, '2026-06-03 06:17:56'),
(75, 3, 'login', NULL, '::1', '2026-06-03 14:02:45'),
(76, 3, 'logout', NULL, NULL, '2026-06-03 14:05:35'),
(77, 4, 'login', NULL, '::1', '2026-06-03 14:06:17'),
(78, 4, 'logout', NULL, NULL, '2026-06-03 14:06:30'),
(79, 6, 'login', NULL, '::1', '2026-06-03 14:07:01'),
(80, 6, 'logout', NULL, NULL, '2026-06-03 14:07:43'),
(81, 3, 'login', NULL, '::1', '2026-06-03 14:08:11'),
(82, 3, 'logout', NULL, NULL, '2026-06-03 14:10:55'),
(83, 6, 'login', NULL, '::1', '2026-06-03 14:11:23'),
(84, 6, 'logout', NULL, NULL, '2026-06-03 14:13:40'),
(85, 3, 'login', NULL, '::1', '2026-06-03 14:14:10'),
(86, 3, 'logout', NULL, NULL, '2026-06-03 14:15:39'),
(87, 10, 'login', NULL, '::1', '2026-06-03 14:34:05'),
(88, 10, 'login', NULL, '::1', '2026-06-03 14:53:31'),
(89, 10, 'logout', NULL, NULL, '2026-06-03 14:55:09'),
(90, 4, 'login', NULL, '::1', '2026-06-03 14:55:40'),
(91, 2, 'login', NULL, '::1', '2026-06-04 02:00:23'),
(92, 2, 'logout', NULL, NULL, '2026-06-04 02:17:40'),
(93, 3, 'login', NULL, '::1', '2026-06-04 02:18:12'),
(94, 3, 'logout', NULL, NULL, '2026-06-04 02:21:57'),
(95, 10, 'login', NULL, '::1', '2026-06-04 02:51:30'),
(96, 10, 'logout', NULL, NULL, '2026-06-04 02:52:17'),
(97, 3, 'login', NULL, '::1', '2026-06-04 02:52:46'),
(98, 3, 'logout', NULL, NULL, '2026-06-04 02:57:01'),
(99, 4, 'login', NULL, '::1', '2026-06-04 02:57:26'),
(100, 6, 'login', NULL, '::1', '2026-06-04 02:58:28'),
(101, 3, 'login', NULL, '::1', '2026-06-04 06:22:35'),
(102, 14, 'login', NULL, '::1', '2026-06-04 06:25:42'),
(103, 4, 'login', NULL, '::1', '2026-06-04 06:31:01'),
(104, 4, 'logout', NULL, NULL, '2026-06-04 06:33:44'),
(105, 3, 'login', NULL, '::1', '2026-06-04 06:34:44'),
(106, 3, 'logout', NULL, NULL, '2026-06-04 06:36:33'),
(107, 10, 'login', NULL, '::1', '2026-06-04 16:08:15'),
(108, 3, 'login', NULL, '::1', '2026-06-04 16:12:24'),
(109, 3, 'login', NULL, '::1', '2026-06-04 16:13:25'),
(110, 3, 'logout', NULL, NULL, '2026-06-04 16:18:25'),
(111, 2, 'login', NULL, '::1', '2026-06-04 16:18:57'),
(112, 2, 'logout', NULL, NULL, '2026-06-04 16:20:45'),
(113, 4, 'login', NULL, '::1', '2026-06-04 16:21:11'),
(114, 4, 'logout', NULL, NULL, '2026-06-04 16:23:42'),
(115, 6, 'login', NULL, '::1', '2026-06-04 16:24:03'),
(116, 6, 'logout', NULL, NULL, '2026-06-04 16:25:42'),
(117, 10, 'login', NULL, '::1', '2026-06-04 16:27:14'),
(118, 3, 'login', NULL, '::1', '2026-06-04 16:32:55'),
(119, 3, 'logout', NULL, NULL, '2026-06-04 16:33:07'),
(120, 2, 'login', NULL, '::1', '2026-06-04 16:33:58'),
(121, 2, 'logout', NULL, NULL, '2026-06-04 16:40:56'),
(122, 10, 'login', NULL, '::1', '2026-06-04 16:51:30'),
(123, 10, 'login', NULL, '::1', '2026-06-04 16:52:50'),
(124, 10, 'logout', NULL, NULL, '2026-06-04 17:06:59'),
(125, 3, 'login', NULL, '::1', '2026-06-05 03:22:15'),
(126, 3, 'logout', NULL, NULL, '2026-06-05 03:30:51'),
(127, 2, 'login', NULL, '::1', '2026-06-05 03:31:13'),
(128, 2, 'logout', NULL, NULL, '2026-06-05 03:39:21'),
(129, 4, 'login', NULL, '::1', '2026-06-05 03:39:43'),
(130, 4, 'logout', NULL, NULL, '2026-06-05 03:52:18'),
(131, 6, 'login', NULL, '::1', '2026-06-05 03:52:43'),
(132, 6, 'logout', NULL, NULL, '2026-06-05 03:56:55'),
(133, 2, 'login', NULL, '::1', '2026-06-05 03:58:57'),
(134, 2, 'logout', NULL, NULL, '2026-06-05 04:00:00'),
(135, 10, 'login', NULL, '::1', '2026-06-05 07:05:48'),
(136, 10, 'logout', NULL, NULL, '2026-06-05 07:08:03'),
(137, 10, 'login', NULL, '::1', '2026-06-05 07:08:58'),
(138, 10, 'logout', NULL, NULL, '2026-06-05 07:09:28'),
(139, 3, 'login', NULL, '::1', '2026-06-05 07:09:51'),
(140, 3, 'logout', NULL, NULL, '2026-06-05 07:11:35'),
(141, 3, 'login', NULL, '::1', '2026-06-05 07:14:19'),
(142, 3, 'logout', NULL, NULL, '2026-06-05 07:26:04'),
(143, 10, 'login', NULL, '::1', '2026-06-05 11:51:54'),
(144, 10, 'logout', NULL, NULL, '2026-06-05 11:58:34'),
(145, 2, 'login', NULL, '::1', '2026-06-05 11:58:57'),
(146, 10, 'login', NULL, '::1', '2026-06-05 14:36:41'),
(147, 10, 'logout', NULL, NULL, '2026-06-05 15:04:33'),
(148, 16, 'login', NULL, '::1', '2026-06-05 15:04:53'),
(149, 16, 'logout', NULL, NULL, '2026-06-05 15:05:01'),
(150, 10, 'login', NULL, '::1', '2026-06-05 15:08:42'),
(151, 10, 'logout', NULL, NULL, '2026-06-05 15:18:05'),
(152, 3, 'login', NULL, '::1', '2026-06-05 15:18:24'),
(153, 3, 'login', NULL, '::1', '2026-06-05 16:09:12'),
(154, 3, 'logout', NULL, NULL, '2026-06-05 16:22:15'),
(155, 2, 'login', NULL, '::1', '2026-06-05 16:22:41'),
(156, 2, 'logout', NULL, NULL, '2026-06-05 16:34:05'),
(157, 4, 'login', NULL, '::1', '2026-06-05 16:34:31'),
(158, 4, 'logout', NULL, NULL, '2026-06-05 16:39:12'),
(159, 6, 'login', NULL, '::1', '2026-06-05 16:39:42'),
(160, 6, 'logout', NULL, NULL, '2026-06-05 16:45:51'),
(161, 10, 'login', NULL, '::1', '2026-06-05 16:49:53'),
(162, 10, 'logout', NULL, NULL, '2026-06-05 16:53:33'),
(163, 10, 'login', NULL, '::1', '2026-06-05 16:57:44'),
(164, 10, 'logout', NULL, NULL, '2026-06-05 16:58:54'),
(165, 10, 'login', NULL, '::1', '2026-06-05 17:02:44'),
(166, 10, 'login', NULL, '::1', '2026-06-06 02:25:52'),
(167, 10, 'logout', NULL, NULL, '2026-06-06 03:03:01'),
(168, 3, 'login', NULL, '::1', '2026-06-06 03:03:33'),
(169, 3, 'logout', NULL, NULL, '2026-06-06 03:08:10'),
(170, 2, 'login', NULL, '::1', '2026-06-06 03:08:48'),
(171, 2, 'logout', NULL, NULL, '2026-06-06 03:19:31'),
(172, 4, 'login', NULL, '::1', '2026-06-06 03:19:52'),
(173, 4, 'logout', NULL, NULL, '2026-06-06 03:20:13'),
(174, 6, 'login', NULL, '::1', '2026-06-06 03:20:31'),
(175, 6, 'logout', NULL, NULL, '2026-06-06 03:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `case_id` int(11) DEFAULT NULL,
  `hours` decimal(5,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `billable` tinyint(1) DEFAULT 1,
  `date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`id`, `user_id`, `case_id`, `hours`, `description`, `billable`, `date`, `created_at`) VALUES
(1, 3, 7, 27.50, 'na', 1, '2026-06-03', '2026-06-04 02:56:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','lawyer','client','paralegal','bookkeeper') NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT 'default.png',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `specialization` varchar(255) DEFAULT NULL,
  `experience` varchar(50) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `profile_image` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role`, `phone`, `address`, `profile_pic`, `is_active`, `created_at`, `updated_at`, `specialization`, `experience`, `bio`, `profile_image`) VALUES
(2, 'siddhi', 'khairnarsiddhi18@gmail.com', '$2y$10$0Z7PsLf.QC8D.gfi5AzH4OfG1uCN5GbpTrYimdgqdwptrBSKsIyIO', 'Siddhi Khairnar', 'client', '8459778860', '', '2_1780118364.jpeg', 1, '2026-05-30 04:03:04', '2026-05-30 05:19:24', NULL, NULL, NULL, NULL),
(3, 'sarthak', 'sarthak@gmail.com', '$2y$10$sM6wVeboXwHGMA0f2pNZY.2MjAs0O/Tex4N87kOTgUXlHyd8XOl3G', 'sarthak Khairnar', 'lawyer', '9876063426', NULL, 'default.png', 1, '2026-05-30 04:06:17', '2026-06-05 07:09:10', NULL, NULL, NULL, NULL),
(4, 'Vishnu', 'vishnu@gmail.com', '$2y$10$SHjr7LUj8D4QHJL7iBhP1OnxuDOM5hKXDx9UbET7e5FAk5ERbZo/K', 'Vishnu Khairnar', 'paralegal', '7463537873', NULL, 'default.png', 1, '2026-05-30 04:08:40', '2026-05-30 04:08:40', NULL, NULL, NULL, NULL),
(5, 'hemangi', 'hemangi@gmail.com', '$2y$10$tNkcdbV9lNyrNkhf13AJmOFLyxRmQQtxtBfIUALrTNPmH3SZbqJ2O', 'Hemangi Khairnar', 'bookkeeper', '76549234365', NULL, 'default.png', 1, '2026-05-30 04:11:08', '2026-05-30 04:11:08', NULL, NULL, NULL, NULL),
(6, 'maya', 'maya@gmail.com', '$2y$10$suBIhGPSJoz6h8qLlco7M.l45z/J74kj66hrPRuRJKli0SLbXqrBy', 'maya', 'bookkeeper', '76457932468', NULL, 'default.png', 1, '2026-05-30 04:12:40', '2026-05-30 04:12:40', NULL, NULL, NULL, NULL),
(8, 'siddhi_khairnar115', 'khairnarsiddhi05@gmail.com', '$2y$10$.LyncO4JF7nbhXqEK29dI.FkouQKVYPH.8LvjXOpj3OgpYdj4E84W', 'Siddhi Khairnar', 'client', '76549234363', NULL, 'default.png', 1, '2026-05-30 05:26:13', '2026-05-30 05:26:13', NULL, NULL, NULL, NULL),
(10, 'admin', 'admin@abtlaw.com', '0192023a7bbd73250516f069df18b500', 'System Administrator', 'admin', '+1 (555) 000-0000', '123 Legal Street, Suite 100, New York, NY 10001', 'default.png', 1, '2026-06-02 04:11:13', '2026-06-02 04:11:13', NULL, NULL, NULL, NULL),
(11, 'Rutuja Patil', 'rutuja1426@gmail.com', '$2y$10$uj.BTFNvl5Fx0VWOA7lcWOzoIooK10v96YvFxhp7MSHKMdSXkQS8y', 'Rutuja Patil', 'client', '746-353-7873', NULL, 'default.png', 1, '2026-06-03 14:58:53', '2026-06-03 14:58:53', NULL, NULL, NULL, NULL),
(12, 'Sakshi sharma', 'sakshi@gmail.com', '$2y$10$wI5ln5ID8e7ArXHrrnlFP.Obt32wZ7y44ggOz63Tdb/6vpWrGP3YW', 'Sakshi sharma', 'lawyer', '765-492-3436', NULL, 'default.png', 1, '2026-06-03 15:11:31', '2026-06-03 15:11:31', NULL, NULL, NULL, NULL),
(13, 'manshree_kapadanis258', 'mau@gmail.com', '$2y$10$oYEqlJkoYowVKrloyg1TW.nwrzrel5QMGAhyv/SJ5rILqkrjBjFdW', 'manshree kapadanis', 'client', '8454768786', 'at post,.dyane', 'default.png', 1, '2026-06-04 02:20:53', '2026-06-04 02:20:53', NULL, NULL, NULL, NULL),
(14, 'kartik_patil321', 'kartik@gmail.com', '$2y$10$lL0SzIYQcTFCOcH7x8XMd.JxQ5NeaMKs42DTCiCG/KpdeJCBSb9Ly', 'kartik patil', 'client', '8454768786', 'thehere', 'default.png', 1, '2026-06-04 06:24:54', '2026-06-04 06:24:54', NULL, NULL, NULL, NULL),
(16, 'kiran_ahire593', 'kiran@gmail.com', '$2y$10$6htvZIF5zxBpuqG2y1iRBeuJr/wAroJy/E87ywgxmkPN19WNa83Fu', 'kiran ahire', 'lawyer', '9876063426', NULL, 'default.png', 1, '2026-06-05 15:03:56', '2026-06-05 15:03:56', 'Criminal Law', '14', 'Graduation:M.S.G College Malegaon Camp ', 'uploads/attorneys/attorney_1780671836_3474.jpeg');

-- --------------------------------------------------------

--
-- Structure for view `payment_summary`
--
DROP TABLE IF EXISTS `payment_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_summary`  AS SELECT `c`.`id` AS `case_id`, `c`.`case_number` AS `case_number`, `c`.`client_id` AS `client_id`, `u`.`full_name` AS `client_name`, `c`.`assigned_lawyer_id` AS `assigned_lawyer_id`, `l`.`full_name` AS `lawyer_name`, coalesce(sum(`i`.`amount`),0) AS `total_billed`, coalesce(sum(`i`.`paid_amount`),0) AS `total_paid`, coalesce(sum(`i`.`amount`) - sum(`i`.`paid_amount`),0) AS `balance_due` FROM (((`cases` `c` left join `users` `u` on(`c`.`client_id` = `u`.`id`)) left join `users` `l` on(`c`.`assigned_lawyer_id` = `l`.`id`)) left join `invoices` `i` on(`i`.`case_id` = `c`.`id`)) GROUP BY `c`.`id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `lawyer_id` (`lawyer_id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `case_number` (`case_number`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `assigned_lawyer_id` (`assigned_lawyer_id`);

--
-- Indexes for table `case_lawyer_assignments`
--
ALTER TABLE `case_lawyer_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_assignment` (`case_id`,`lawyer_id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `lawyer_id` (`lawyer_id`);

--
-- Indexes for table `case_notes`
--
ALTER TABLE `case_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `case_progress`
--
ALTER TABLE `case_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_session` (`session_id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `chatbot_faq`
--
ALTER TABLE `chatbot_faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatbot_intents`
--
ALTER TABLE `chatbot_intents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `hearings`
--
ALTER TABLE `hearings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `lawyer_profiles`
--
ALTER TABLE `lawyer_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_case_id` (`case_id`),
  ADD KEY `idx_from_user` (`from_user_id`),
  ADD KEY `idx_to_user` (`to_user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `practice_areas`
--
ALTER TABLE `practice_areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `case_lawyer_assignments`
--
ALTER TABLE `case_lawyer_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `case_notes`
--
ALTER TABLE `case_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `case_progress`
--
ALTER TABLE `case_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `chatbot_faq`
--
ALTER TABLE `chatbot_faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `chatbot_intents`
--
ALTER TABLE `chatbot_intents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_info`
--
ALTER TABLE `contact_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hearings`
--
ALTER TABLE `hearings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lawyer_profiles`
--
ALTER TABLE `lawyer_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `practice_areas`
--
ALTER TABLE `practice_areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`lawyer_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`assigned_lawyer_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `case_lawyer_assignments`
--
ALTER TABLE `case_lawyer_assignments`
  ADD CONSTRAINT `fk_case_lawyer_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_case_lawyer_lawyer` FOREIGN KEY (`lawyer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `case_notes`
--
ALTER TABLE `case_notes`
  ADD CONSTRAINT `case_notes_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `case_notes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `case_progress`
--
ALTER TABLE `case_progress`
  ADD CONSTRAINT `case_progress_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `case_progress_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  ADD CONSTRAINT `chatbot_conversations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `hearings`
--
ALTER TABLE `hearings`
  ADD CONSTRAINT `hearings_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hearings_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `lawyer_profiles`
--
ALTER TABLE `lawyer_profiles`
  ADD CONSTRAINT `lawyer_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`),
  ADD CONSTRAINT `payments_ibfk_4` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD CONSTRAINT `system_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD CONSTRAINT `timesheets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `timesheets_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
