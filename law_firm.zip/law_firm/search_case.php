<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $search = trim($_POST['search']);
    
    if (empty($search)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a case number or case title.']);
        exit();
    }
    
    // Search for case by case_number or title
    $stmt = $conn->prepare("
        SELECT c.*, 
               u.full_name as lawyer_name
        FROM cases c
        LEFT JOIN users u ON c.assigned_lawyer_id = u.id
        WHERE c.case_number LIKE ? OR c.title LIKE ?
        LIMIT 1
    ");
    
    $search_term = "%$search%";
    $stmt->bind_param("ss", $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $case = $result->fetch_assoc();
        
        // Get next hearing date
        $hearing = $conn->query("SELECT hearing_date FROM hearings WHERE case_id = {$case['id']} AND hearing_date >= CURDATE() ORDER BY hearing_date LIMIT 1");
        $next_hearing = $hearing->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'case' => [
                'case_number' => $case['case_number'],
                'title' => $case['title'],
                'status' => $case['status'],
                'progress' => $case['progress'],
                'lawyer_name' => $case['lawyer_name'],
                'filed_date' => date('M d, Y', strtotime($case['created_at'])),
                'next_hearing' => $next_hearing ? date('M d, Y', strtotime($next_hearing['hearing_date'])) : null,
                'description' => $case['description']
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No case found with the provided information.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>