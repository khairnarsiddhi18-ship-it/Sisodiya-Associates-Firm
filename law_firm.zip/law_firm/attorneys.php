<?php
session_start();
require_once 'config/database.php';

$page_title = "Our Attorneys";

// Get all active attorneys from database
$attorneys_query = "SELECT * FROM users WHERE role = 'lawyer' AND is_active = 1 ORDER BY full_name";
$attorneys_result = $conn->query($attorneys_query);

require_once 'includes/header.php';
?>

<style>
    /* Page Specific Styles */
    .page-header {
        background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
        padding: 150px 0 80px;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .page-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(212,175,55,0.05)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        background-size: cover;
        animation: wave 15s ease-in-out infinite;
    }

    @keyframes wave {
        0%, 100% { transform: translateX(0) translateY(0); }
        50% { transform: translateX(-5%) translateY(10px); }
    }

    .attorney-profile {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        margin-bottom: 30px;
        transition: all 0.3s;
        border-bottom: 3px solid transparent;
        height: 100%;
    }

    .attorney-profile:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.12);
        border-bottom-color: #D4AF37;
    }

    .attorney-image {
        height: 320px;
        background-size: cover;
        background-position: center;
        position: relative;
        overflow: hidden;
        background-color: #f0f0f0;
    }

    .attorney-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .attorney-image .no-image {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #4A0E17, #6B1A2A);
        color: white;
        font-size: 48px;
        font-weight: bold;
    }

    .attorney-image::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgba(74,14,23,0.3), rgba(107,26,42,0.3));
        opacity: 0;
        transition: opacity 0.3s;
        z-index: 1;
    }

    .attorney-profile:hover .attorney-image::before {
        opacity: 1;
    }

    .attorney-social-links {
        position: absolute;
        bottom: 20px;
        left: 0;
        right: 0;
        text-align: center;
        opacity: 0;
        transition: opacity 0.3s;
        z-index: 2;
    }

    .attorney-profile:hover .attorney-social-links {
        opacity: 1;
    }

    .attorney-social-links a {
        display: inline-block;
        width: 40px;
        height: 40px;
        background: #D4AF37;
        border-radius: 50%;
        line-height: 40px;
        margin: 0 5px;
        color: #4A0E17;
        transition: all 0.3s;
        text-decoration: none;
    }

    .attorney-social-links a:hover {
        background: white;
        color: #D4AF37;
        transform: scale(1.1) translateY(-3px);
    }

    .attorney-profile h3 {
        color: #4A0E17;
        font-weight: 700;
        margin-bottom: 5px;
    }

    .attorney-profile .text-primary {
        color: #D4AF37 !important;
        font-weight: 600;
    }

    .expertise-tag {
        display: inline-block;
        background: rgba(212, 175, 55, 0.1);
        color: #D4AF37;
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.85rem;
        margin: 5px;
        transition: all 0.3s;
    }

    .expertise-tag:hover {
        background: #D4AF37;
        color: #4A0E17;
        transform: translateY(-2px);
    }

    .rating-star {
        color: #D4AF37;
    }

    hr {
        background: rgba(212, 175, 55, 0.2);
        margin: 15px 0;
    }

    .empty-state {
        text-align: center;
        padding: 80px 20px;
        background: white;
        border-radius: 20px;
    }

    .empty-state i {
        font-size: 80px;
        color: #D4AF37;
        opacity: 0.3;
        margin-bottom: 20px;
    }

    .empty-state h3 {
        color: #4A0E17;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #6c757d;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .page-header {
            padding: 120px 0 60px;
        }
        
        .page-header h1 {
            font-size: 2rem;
        }
        
        .attorney-image {
            height: 280px;
        }
        
        .attorney-profile .p-4 {
            padding: 1.2rem !important;
        }
        
        .attorney-profile h3 {
            font-size: 1.3rem;
        }
    }

    /* CTA Section */
    .cta-section {
        background: linear-gradient(135deg, #4A0E17, #6B1A2A);
        padding: 70px 0;
    }

    .btn-premium-primary {
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border: none;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 700;
        color: #4A0E17;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-premium-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px -5px rgba(212, 175, 55, 0.4);
        color: #4A0E17;
    }

    .btn-premium-outline {
        border: 2px solid #D4AF37;
        background: transparent;
        padding: 10px 28px;
        border-radius: 50px;
        font-weight: 600;
        color: white;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-premium-outline:hover {
        background: #D4AF37;
        color: #4A0E17;
        transform: translateY(-2px);
    }
</style>

<!-- Page Header -->
<section class="page-header">
    <div class="container text-center position-relative" style="z-index: 2;">
        <h1 class="display-3 fw-bold" data-aos="fade-down">Our Distinguished <span style="color: #D4AF37;">Attorneys</span></h1>
        <p class="lead" data-aos="fade-up">Meet the legal experts committed to your success</p>
    </div>
</section>

<!-- Attorneys Section -->
<section class="py-5" style="background: #FDF8F0;">
    <div class="container">
        <?php if($attorneys_result && $attorneys_result->num_rows > 0): ?>
            <div class="row">
                <?php 
                $delay = 100;
                while($attorney = $attorneys_result->fetch_assoc()): 
                    // Get initials for placeholder
                    $initials = strtoupper(substr($attorney['full_name'], 0, 1));
                    // Get specialization array for expertise tags
                    $specializations = explode(',', $attorney['specialization'] ?? 'Legal Expert');
                ?>
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo $delay; ?>">
                    <div class="attorney-profile">
                        <div class="attorney-image">
                            <?php if($attorney['profile_image'] && file_exists($attorney['profile_image'])): ?>
                                <img src="<?php echo $attorney['profile_image']; ?>" alt="<?php echo htmlspecialchars($attorney['full_name']); ?>">
                            <?php else: ?>
                                <div class="no-image">
                                    <?php echo $initials; ?>
                                </div>
                            <?php endif; ?>
                            <div class="attorney-social-links">
                                <a href="mailto:<?php echo $attorney['email']; ?>"><i class="fas fa-envelope"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3><?php echo htmlspecialchars($attorney['full_name']); ?></h3>
                            <p class="text-primary fw-bold"><?php echo htmlspecialchars($attorney['specialization'] ?? 'Legal Expert'); ?></p>
                            <p class="text-muted small">
                                <?php 
                                if($attorney['experience']):
                                    echo $attorney['experience'] . '+ years experience';
                                else:
                                    echo 'Experienced Attorney';
                                endif;
                                ?>
                            </p>
                            <div class="mt-3">
                                <?php foreach($specializations as $tag): ?>
                                    <span class="expertise-tag"><?php echo trim(htmlspecialchars($tag)); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <?php if($attorney['bio']): ?>
                                <hr>
                                <p class="text-muted small mt-2"><?php echo substr(htmlspecialchars($attorney['bio']), 0, 100); ?>...</p>
                            <?php endif; ?>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <span><i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($attorney['phone'] ?? 'Contact via email'); ?></span>
                                <span><i class="fas fa-star rating-star"></i> 
                                    <?php 
                                    // Generate random rating between 4.5 and 5.0 for demo
                                    $rating = 4.5 + (mt_rand(0, 50) / 100);
                                    echo number_format($rating, 1); 
                                    ?> Rating
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    $delay += 100;
                endwhile; 
                ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-user-tie"></i>
                <h3>No Attorneys Found</h3>
                <p>Our attorney directory is being updated. Please check back soon.</p>
                <a href="contact.php" class="btn-premium-primary mt-3">Contact Us for Assistance</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container text-center">
        <h2 class="display-5 fw-bold text-white mb-4">Need Legal Assistance?</h2>
        <p class="lead text-white-50 mb-4">Schedule a free consultation with our expert attorneys today</p>
        <div class="d-flex gap-3 justify-content-center flex-wrap">
            <a href="register.php" class="btn-premium-primary">Get Free Consultation</a>
            <a href="contact.php" class="btn-premium-outline">Contact Us Now</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>