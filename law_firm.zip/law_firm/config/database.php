<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'law_firm_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set timezone
date_default_timezone_set('America/New_York');
?>