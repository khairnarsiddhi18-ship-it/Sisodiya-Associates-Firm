<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['lawyer', 'paralegal'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Timesheets";
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Handle Add Timesheet Entry
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_entry'])) {
    $case_id = $_POST['case_id'];
    $hours = $_POST['hours'];
    $description = $_POST['description'];
    $billable = isset($_POST['billable']) ? 1 : 0;
    $date = $_POST['date'];
    
    $stmt = $conn->prepare("INSERT INTO timesheets (user_id, case_id, hours, description, billable, date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iidsis", $user_id, $case_id, $hours, $description, $billable, $date);
    
    if ($stmt->execute()) {
        $success = "Time entry added successfully!";
    } else {
        $error = "Error adding time entry: " . $conn->error;
    }
}

// Handle Delete Entry
if (isset($_GET['delete'])) {
    $entry_id = $_GET['delete'];
    $conn->query("DELETE FROM timesheets WHERE id = $entry_id AND user_id = $user_id");
    $success = "Entry deleted successfully!";
}

// Handle Update Entry
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_entry'])) {
    $entry_id = $_POST['entry_id'];
    $hours = $_POST['hours'];
    $description = $_POST['description'];
    $billable = isset($_POST['billable']) ? 1 : 0;
    $date = $_POST['date'];
    
    $stmt = $conn->prepare("UPDATE timesheets SET hours = ?, description = ?, billable = ?, date = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("dsisii", $hours, $description, $billable, $date, $entry_id, $user_id);
    
    if ($stmt->execute()) {
        $success = "Time entry updated successfully!";
    } else {
        $error = "Error updating time entry: " . $conn->error;
    }
}

// Get filter parameters
$filter_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$filter_case = isset($_GET['case']) ? (int)$_GET['case'] : 0;

// Build query for timesheet entries
$timesheet_query = "SELECT t.*, c.case_number, c.title 
                   FROM timesheets t 
                   LEFT JOIN cases c ON t.case_id = c.id 
                   WHERE t.user_id = $user_id";

if ($filter_month) {
    $timesheet_query .= " AND DATE_FORMAT(t.date, '%Y-%m') = '$filter_month'";
}
if ($filter_case && $filter_case > 0) {
    $timesheet_query .= " AND t.case_id = $filter_case";
}

$timesheet_query .= " ORDER BY t.date DESC, t.created_at DESC";
$timesheets = $conn->query($timesheet_query);

// Get statistics
$stats = [];
$result = $conn->query("SELECT SUM(hours) as total_hours FROM timesheets WHERE user_id = $user_id AND billable = 1 AND DATE_FORMAT(date, '%Y-%m') = '$filter_month'");
$stats['billable_hours'] = $result->fetch_assoc()['total_hours'] ?? 0;

$result = $conn->query("SELECT SUM(hours) as total_hours FROM timesheets WHERE user_id = $user_id AND DATE_FORMAT(date, '%Y-%m') = '$filter_month'");
$stats['total_hours'] = $result->fetch_assoc()['total_hours'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM timesheets WHERE user_id = $user_id AND DATE_FORMAT(date, '%Y-%m') = '$filter_month'");
$stats['total_entries'] = $result->fetch_assoc()['total'];

// Get cases for dropdown
$cases_query = "SELECT id, case_number, title FROM cases";
if ($user_role == 'lawyer') {
    $cases_query .= " WHERE assigned_lawyer_id = $user_id";
}
$cases = $conn->query($cases_query);

require_once '../includes/header.php';
?>

<style>
    /* Page Specific Styles */
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
        --dark: #2D0A10;
    }

    .page-container {
        background: var(--light);
        min-height: 100vh;
        padding: 30px 0 50px;
        margin-top: 70px;
    }

    /* Sidebar Styles - Matching Theme */
    .sidebar {
        background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
        min-height: 100vh;
        box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    }

    .sidebar .nav-link {
        color: rgba(255,255,255,0.85) !important;
        padding: 12px 20px;
        margin: 5px 10px;
        border-radius: 12px;
        transition: all 0.3s;
        font-weight: 500;
    }

    .sidebar .nav-link:hover {
        background: rgba(212, 175, 55, 0.15);
        color: var(--secondary) !important;
        transform: translateX(5px);
    }

    .sidebar .nav-link.active {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        color: var(--primary-dark) !important;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .sidebar .nav-link i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }

    /* Stat Cards */
    .stat-card {
        background: white;
        border-radius: 20px;
        padding: 20px;
        text-align: center;
        transition: all 0.3s;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        border-bottom: 3px solid transparent;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        border-bottom-color: var(--secondary);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
    }

    .stat-icon i {
        font-size: 24px;
        color: var(--primary-dark);
    }

    .stat-value {
        font-size: 32px;
        font-weight: 800;
        color: var(--primary-dark);
    }

    /* Form Card */
    .form-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        margin-bottom: 25px;
    }

    .form-card .card-header {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        color: white;
        border: none;
        padding: 15px 20px;
    }

    .form-card .card-header h5 {
        margin: 0;
        font-weight: 700;
    }

    .form-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .form-card .card-body {
        padding: 25px;
    }

    /* Table Card */
    .table-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }

    .table-card .card-header {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        color: white;
        border: none;
        padding: 15px 20px;
    }

    .table-card .card-header h5 {
        margin: 0;
        font-weight: 700;
    }

    .table-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .table-card .card-body {
        padding: 20px;
    }

    /* Form Controls */
    .form-label {
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 8px;
    }

    .form-label i {
        color: var(--secondary);
        margin-right: 6px;
    }

    .form-control, .form-select {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px 15px;
        transition: all 0.3s;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--secondary);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        outline: none;
    }

    /* Table Styles */
    .timesheet-table {
        width: 100%;
    }

    .timesheet-table thead th {
        background: var(--primary-dark);
        color: white;
        font-weight: 600;
        padding: 12px 15px;
        border: none;
    }

    .timesheet-table thead th:first-child {
        border-radius: 12px 0 0 0;
    }

    .timesheet-table thead th:last-child {
        border-radius: 0 12px 0 0;
    }

    .timesheet-table tbody tr {
        border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        transition: all 0.3s;
    }

    .timesheet-table tbody tr:hover {
        background: rgba(212, 175, 55, 0.05);
    }

    .timesheet-table tbody td {
        padding: 12px 15px;
        vertical-align: middle;
        color: var(--primary-dark);
    }

    /* Badges */
    .badge-billable {
        background: #10b981;
        color: white;
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 600;
    }

    .badge-non-billable {
        background: #6c757d;
        color: white;
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 600;
    }

    /* Buttons */
    .btn-submit {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        padding: 10px 25px;
        border-radius: 12px;
        color: var(--primary-dark);
        font-weight: 700;
        transition: all 0.3s;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .btn-edit {
        background: #f59e0b;
        border: none;
        padding: 5px 12px;
        border-radius: 8px;
        color: white;
        transition: all 0.3s;
    }

    .btn-edit:hover {
        background: #d97706;
        transform: translateY(-2px);
    }

    .btn-delete {
        background: #C72A2A;
        border: none;
        padding: 5px 12px;
        border-radius: 8px;
        color: white;
        transition: all 0.3s;
    }

    .btn-delete:hover {
        background: #8B2635;
        transform: translateY(-2px);
    }

    /* Filter Bar */
    .filter-bar {
        background: white;
        border-radius: 15px;
        padding: 15px;
        margin-bottom: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        border: 1px solid rgba(212, 175, 55, 0.2);
    }

    /* Modal */
    .modal-header {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
        border: none;
    }

    .modal-header .btn-close {
        background: white;
        opacity: 1;
    }

    .modal-title i {
        color: var(--secondary);
    }

    @media (max-width: 768px) {
        .timesheet-table thead {
            display: none;
        }
        
        .timesheet-table tbody tr {
            display: block;
            margin-bottom: 15px;
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
        }
        
        .timesheet-table tbody td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .timesheet-table tbody td:before {
            content: attr(data-label);
            font-weight: 600;
            color: var(--primary-dark);
            margin-right: 15px;
        }
        
        .sidebar {
            position: fixed;
            left: -280px;
            transition: left 0.3s;
            z-index: 1000;
        }
        
        .sidebar.show {
            left: 0;
        }
    }
</style>

<div class="page-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar - Fixed to Match Theme -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4 pb-2 border-bottom" style="border-color: rgba(212,175,55,0.3) !important;">
                        <div class="logo-icon-small mb-2" style="width: 50px; height: 50px; background: var(--secondary); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center;">
                            <i class="fas fa-gavel" style="color: var(--primary-dark); font-size: 1.5rem;"></i>
                        </div>
                        <h6 class="text-white mb-0">Lawyer Portal</h6>
                        <small class="text-white-50">Welcome, <?php echo $_SESSION['user_name']; ?></small>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="lawyer_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../cases.php">
                                <i class="fas fa-briefcase"></i> Case Tracker
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="timesheets.php">
                                <i class="fas fa-clock"></i> Timesheet
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../documents.php">
                                <i class="fas fa-file-alt"></i> Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hearings.php">
                                <i class="fas fa-calendar"></i> Hearings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../messages.php">
                                <i class="fas fa-envelope"></i> Messages
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <hr style="border-color: rgba(212,175,55,0.3);">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-circle"></i> Profile Settings
                            </a>
                            <a class="nav-link" href="../logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4">
                <div class="pt-3 pb-2 mb-3">
                    <h1 class="h2" style="color: var(--primary-dark);">
                        <i class="fas fa-clock" style="color: var(--secondary);"></i> Timesheets
                    </h1>
                    <p class="text-muted">Track and manage your billable hours</p>
                </div>

                <!-- Statistics Row -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                            <div class="stat-value"><?php echo number_format($stats['total_hours'], 1); ?></div>
                            <p class="text-muted mb-0">Total Hours (<?php echo date('F Y', strtotime($filter_month . '-01')); ?>)</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                            <div class="stat-value"><?php echo number_format($stats['billable_hours'], 1); ?></div>
                            <p class="text-muted mb-0">Billable Hours</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-list"></i></div>
                            <div class="stat-value"><?php echo $stats['total_entries']; ?></div>
                            <p class="text-muted mb-0">Total Entries</p>
                        </div>
                    </div>
                </div>

                <!-- Add Time Entry Form -->
                <div class="form-card">
                    <div class="card-header">
                        <h5><i class="fas fa-plus-circle"></i> Add Time Entry</h5>
                    </div>
                    <div class="card-body">
                        <?php if(isset($success)): ?>
                            <div class="alert alert-success alert-dismissible fade show" style="background: #d4edda; border-left: 4px solid #10b981; border-radius: 12px;">
                                <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" style="background: #f8d7da; border-left: 4px solid #C72A2A; border-radius: 12px;">
                                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><i class="fas fa-briefcase"></i> Select Case</label>
                                    <select class="form-select" name="case_id" required>
                                        <option value="">Choose case...</option>
                                        <?php while($case = $cases->fetch_assoc()): ?>
                                            <option value="<?php echo $case['id']; ?>">
                                                <?php echo $case['case_number']; ?> - <?php echo substr($case['title'], 0, 40); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label"><i class="fas fa-clock"></i> Hours</label>
                                    <input type="number" step="0.25" class="form-control" name="hours" placeholder="0.00" required>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label"><i class="fas fa-calendar-alt"></i> Date</label>
                                    <input type="date" class="form-control" name="date" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label"><i class="fas fa-tag"></i> Billable</label>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="billable" value="1" id="billable" checked>
                                        <label class="form-check-label" for="billable">
                                            Mark as billable
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label class="form-label"><i class="fas fa-align-left"></i> Description</label>
                                    <textarea class="form-control" name="description" rows="3" placeholder="Describe the work performed..." required></textarea>
                                </div>
                            </div>
                            <button type="submit" name="add_entry" class="btn btn-submit">
                                <i class="fas fa-save me-2"></i> Save Entry
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Filter Bar -->
                <div class="filter-bar">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label mb-1"><i class="fas fa-calendar-month"></i> Month</label>
                            <input type="month" class="form-control" name="month" value="<?php echo $filter_month; ?>">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label mb-1"><i class="fas fa-briefcase"></i> Case</label>
                            <select class="form-select" name="case">
                                <option value="0">All Cases</option>
                                <?php 
                                $cases->data_seek(0);
                                while($case = $cases->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $case['id']; ?>" <?php echo ($filter_case == $case['id']) ? 'selected' : ''; ?>>
                                        <?php echo $case['case_number']; ?> - <?php echo substr($case['title'], 0, 40); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-submit w-100">
                                <i class="fas fa-filter me-2"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Timesheet Entries Table -->
                <div class="table-card">
                    <div class="card-header">
                        <h5><i class="fas fa-list"></i> Time Entries</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="timesheet-table table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Case</th>
                                        <th>Description</th>
                                        <th>Hours</th>
                                        <th>Type</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($timesheets && $timesheets->num_rows > 0): ?>
                                        <?php while($entry = $timesheets->fetch_assoc()): ?>
                                            <tr>
                                                <td data-label="Date"><?php echo date('M d, Y', strtotime($entry['date'])); ?></td>
                                                <td data-label="Case">
                                                    <strong><?php echo $entry['case_number']; ?></strong><br>
                                                    <small class="text-muted"><?php echo substr($entry['title'], 0, 30); ?></small>
                                                </td>
                                                <td data-label="Description"><?php echo nl2br(htmlspecialchars(substr($entry['description'], 0, 100))); ?></td>
                                                <td data-label="Hours"><strong><?php echo number_format($entry['hours'], 2); ?> hrs</strong></td>
                                                <td data-label="Type">
                                                    <?php if($entry['billable']): ?>
                                                        <span class="badge-billable"><i class="fas fa-dollar-sign"></i> Billable</span>
                                                    <?php else: ?>
                                                        <span class="badge-non-billable"><i class="fas fa-clock"></i> Non-Billable</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td data-label="Actions">
                                                    <button class="btn btn-edit btn-sm" onclick="editEntry(<?php echo $entry['id']; ?>, '<?php echo $entry['date']; ?>', <?php echo $entry['hours']; ?>, '<?php echo addslashes($entry['description']); ?>', <?php echo $entry['billable']; ?>)">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <a href="?delete=<?php echo $entry['id']; ?>&month=<?php echo $filter_month; ?>&case=<?php echo $filter_case; ?>" class="btn btn-delete btn-sm" onclick="return confirm('Delete this time entry?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted py-4">
                                                <i class="fas fa-clock fa-3x mb-3 d-block" style="color: var(--secondary); opacity: 0.5;"></i>
                                                No time entries found for this period.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<!-- Edit Entry Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit" style="color: var(--secondary);"></i> Edit Time Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="entry_id" id="edit_entry_id">
                    <div class="mb-3">
                        <label class="form-label">Date</label>
                        <input type="date" class="form-control" name="date" id="edit_date" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Hours</label>
                        <input type="number" step="0.25" class="form-control" name="hours" id="edit_hours" placeholder="0.00" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="edit_description" rows="3" required></textarea>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" name="billable" value="1" id="edit_billable">
                        <label class="form-check-label">Mark as billable</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_entry" class="btn btn-submit">Update Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function editEntry(id, date, hours, description, billable) {
        document.getElementById('edit_entry_id').value = id;
        document.getElementById('edit_date').value = date;
        document.getElementById('edit_hours').value = hours;
        document.getElementById('edit_description').value = description;
        document.getElementById('edit_billable').checked = billable == 1;
        
        new bootstrap.Modal(document.getElementById('editModal')).show();
    }
</script>

<?php require_once '../includes/footer.php'; ?>