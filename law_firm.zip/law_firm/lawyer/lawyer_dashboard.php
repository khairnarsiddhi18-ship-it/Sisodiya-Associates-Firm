<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'lawyer') {
    header("Location: login.php");
    exit();
}

$page_title = "Lawyer Dashboard";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Lawyer';

// Handle Manual Client + Case Addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_client_case'])) {
    // Client details
    $client_name = trim($_POST['client_name']);
    $client_email = trim($_POST['client_email']);
    $client_phone = trim($_POST['client_phone']);
    $client_address = trim($_POST['client_address']);
    
    // Case details
    $case_number = trim($_POST['case_number']);
    $case_title = trim($_POST['case_title']);
    $case_description = trim($_POST['case_description']);
    $case_type = trim($_POST['case_type']);
    $filing_date = $_POST['filing_date'];
    
    $errors = [];
    
    if (empty($client_name) || empty($client_email) || empty($case_title)) {
        $errors[] = "Please fill in all required fields (Client Name, Email, Case Title).";
    }
    
    if (!filter_var($client_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    if (empty($errors)) {
        $conn->begin_transaction();
        
        try {
            // Check if client already exists
            $check_client = $conn->prepare("SELECT id FROM users WHERE email = ? AND role = 'client'");
            $check_client->bind_param("s", $client_email);
            $check_client->execute();
            $client_result = $check_client->get_result();
            
            if ($client_result->num_rows > 0) {
                $client_data = $client_result->fetch_assoc();
                $client_id = $client_data['id'];
                $client_message = "Client already exists. Case added to existing client.";
            } else {
                // Create new client
                $temp_password = substr(md5(uniqid()), 0, 10);
                $password_hash = password_hash($temp_password, PASSWORD_DEFAULT);
                $username = strtolower(str_replace(' ', '_', $client_name)) . rand(100, 999);
                
                $insert_client = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name, phone, address, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, 'client', 1, NOW())");
                $insert_client->bind_param("ssssss", $username, $client_email, $password_hash, $client_name, $client_phone, $client_address);
                $insert_client->execute();
                $client_id = $conn->insert_id;
                $client_message = "New client created successfully! Temporary password: <strong>$temp_password</strong>";
            }
            
            // Generate case number if not provided
            if (empty($case_number)) {
                $case_number = 'CASE-' . date('Ymd') . '-' . rand(1000, 9999);
            }
            
            // Insert case
            $insert_case = $conn->prepare("INSERT INTO cases (case_number, title, description, case_type, client_id, assigned_lawyer_id, filing_date, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())");
            $insert_case->bind_param("ssssiis", $case_number, $case_title, $case_description, $case_type, $client_id, $user_id, $filing_date);
            $insert_case->execute();
            $case_id = $conn->insert_id;
            
            // Add initial case note
            $initial_note = "Case filed by lawyer " . $_SESSION['user_name'] . " on " . date('F d, Y');
            $insert_note = $conn->prepare("INSERT INTO case_notes (case_id, user_id, note, created_at) VALUES (?, ?, ?, NOW())");
            $insert_note->bind_param("iis", $case_id, $user_id, $initial_note);
            $insert_note->execute();
            
            $conn->commit();
            
            $success_message = $client_message . "<br>Case <strong>$case_number</strong> has been created successfully!";
            
            // Refresh the page to show updated data
            header("Location: lawyer_dashboard.php?success=1&msg=" . urlencode($success_message));
            exit();
            
        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "Error: " . $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}

// Handle Payment Recording
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['record_payment'])) {
    $case_id = $_POST['case_id'];
    $client_id = $_POST['client_id'];
    $invoice_id = $_POST['invoice_id'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];
    $payment_date = $_POST['payment_date'];
    $notes = $_POST['notes'];
    
    $conn->begin_transaction();
    
    try {
        $stmt = $conn->prepare("INSERT INTO payments (invoice_id, client_id, case_id, amount, payment_method, transaction_id, payment_date, notes, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiidssssi", $invoice_id, $client_id, $case_id, $amount, $payment_method, $transaction_id, $payment_date, $notes, $user_id);
        $stmt->execute();
        
        $update_invoice = $conn->prepare("UPDATE invoices SET paid_amount = paid_amount + ?, status = CASE WHEN paid_amount + ? >= amount THEN 'paid' ELSE 'partial' END WHERE id = ?");
        $update_invoice->bind_param("ddi", $amount, $amount, $invoice_id);
        $update_invoice->execute();
        
        $conn->commit();
        header("Location: lawyer_dashboard.php?payment_success=1");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $payment_error = "Error recording payment: " . $e->getMessage();
    }
}

// Handle Payment Deletion
if (isset($_GET['delete_payment'])) {
    $payment_id = $_GET['delete_payment'];
    $conn->query("DELETE FROM payments WHERE id = $payment_id");
    header("Location: lawyer_dashboard.php");
    exit();
}

// Metrics
$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE assigned_lawyer_id = $user_id AND status = 'active'");
$active_cases = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM hearings h JOIN cases c ON h.case_id = c.id WHERE c.assigned_lawyer_id = $user_id AND h.hearing_date >= CURDATE()");
$upcoming_hearings = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM documents d JOIN cases c ON d.case_id = c.id WHERE c.assigned_lawyer_id = $user_id AND d.uploaded_by != $user_id");
$pending_tasks = $result->fetch_assoc()['total'];

// Payment Statistics
$result = $conn->query("
    SELECT 
        COALESCE(SUM(i.amount), 0) as total_billed,
        COALESCE(SUM(i.paid_amount), 0) as total_collected,
        COALESCE(SUM(i.amount) - SUM(i.paid_amount), 0) as total_pending
    FROM cases c
    LEFT JOIN invoices i ON i.case_id = c.id
    WHERE c.assigned_lawyer_id = $user_id
");
$payment_stats = $result->fetch_assoc();

// Get cases with payment status
$cases_with_payment = $conn->query("
    SELECT 
        c.id,
        c.case_number,
        c.title,
        c.case_type,
        c.filing_date,
        c.status as case_status,
        u.id as client_id,
        u.full_name as client_name,
        u.email as client_email,
        u.phone as client_phone,
        COALESCE(SUM(i.amount), 0) as billed_amount,
        COALESCE(SUM(i.paid_amount), 0) as paid_amount,
        COALESCE(SUM(i.amount) - SUM(i.paid_amount), 0) as balance_due
    FROM cases c
    JOIN users u ON c.client_id = u.id
    LEFT JOIN invoices i ON i.case_id = c.id
    WHERE c.assigned_lawyer_id = $user_id
    GROUP BY c.id
    ORDER BY c.created_at DESC
    LIMIT 15
");

// Recent payments
$recent_payments = $conn->query("
    SELECT p.*, c.case_number, u.full_name as client_name, i.invoice_number
    FROM payments p
    JOIN cases c ON p.case_id = c.id
    JOIN users u ON p.client_id = u.id
    JOIN invoices i ON p.invoice_id = i.id
    WHERE c.assigned_lawyer_id = $user_id
    ORDER BY p.created_at DESC
    LIMIT 10
");

// Get all invoices for payment dropdown
$all_invoices = $conn->query("
    SELECT i.id, i.invoice_number, i.amount, i.paid_amount, c.case_number, c.id as case_id, u.id as client_id, u.full_name as client_name
    FROM invoices i
    JOIN cases c ON i.case_id = c.id
    JOIN users u ON c.client_id = u.id
    WHERE c.assigned_lawyer_id = $user_id AND i.status != 'paid'
    ORDER BY i.due_date ASC
");

// Upcoming hearings
$hearings = $conn->query("SELECT h.*, c.case_number, c.title FROM hearings h JOIN cases c ON h.case_id = c.id WHERE c.assigned_lawyer_id = $user_id AND h.hearing_date >= CURDATE() ORDER BY h.hearing_date LIMIT 5");

// My schedule
$appointments = $conn->query("SELECT a.*, u.full_name as client_name FROM appointments a JOIN users u ON a.client_id = u.id WHERE a.lawyer_id = $user_id AND a.appointment_date >= CURDATE() ORDER BY a.appointment_date LIMIT 5");

// Get success/error messages from URL
$success_msg = isset($_GET['msg']) ? urldecode($_GET['msg']) : '';
$show_success = isset($_GET['success']) ? true : false;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Lawyer Dashboard | ABT Law Firm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --light: #FDF8F0;
            --accent: #8B2635;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--light);
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: var(--secondary);
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: var(--secondary) !important;
        }

        .dashboard-wrapper {
            background: var(--light);
            min-height: 100vh;
            margin-top: 70px;
            padding: 20px;
        }

        /* Sidebar */
        .sidebar {
            background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
            min-height: calc(100vh - 70px);
            border-radius: 20px;
            margin: 0;
            padding: 20px 0;
        }

        .sidebar .nav-link {
            color: rgba(255,255,255,0.85) !important;
            padding: 12px 20px;
            margin: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary) !important;
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark) !important;
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-box {
            background: white;
            border-radius: 16px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }

        .stat-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .stat-info h3 {
            font-size: 28px;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        .stat-info p {
            font-size: 13px;
            color: #6c757d;
            margin: 0;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-icon i {
            font-size: 24px;
        }

        .icon-cases { background: rgba(74,14,23,0.1); color: var(--primary-dark); }
        .icon-hearings { background: rgba(212,175,55,0.1); color: var(--secondary); }
        .icon-tasks { background: rgba(139,38,53,0.1); color: var(--accent); }
        .icon-payment { background: rgba(16,185,129,0.1); color: #10b981; }

        /* Cards */
        .card-modern {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            overflow: hidden;
        }

        .card-modern .card-header {
            background: white;
            padding: 15px 20px;
            border-bottom: 2px solid rgba(212, 175, 55, 0.15);
        }

        .card-modern .card-header h5 {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 16px;
            margin: 0;
        }

        .card-modern .card-header h5 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .card-modern .card-body {
            padding: 20px;
        }

        /* Client Add Section */
        .client-add-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 25px;
            border: 2px dashed rgba(212, 175, 55, 0.3);
        }

        /* Form Styles */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .form-group {
            margin-bottom: 0;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 5px;
            display: block;
        }

        .form-group label .required {
            color: #ef4444;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 8px 12px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        textarea.form-control {
            resize: vertical;
        }

        .btn-submit-client {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            color: var(--primary-dark);
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 700;
            border: none;
            width: 100%;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .btn-submit-client:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        /* Alert Styles */
        .alert-custom {
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        .alert-success-custom {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
        }

        .alert-danger-custom {
            background: #f8d7da;
            border-left: 4px solid #ef4444;
            color: #721c24;
        }

        /* List Items */
        .list-item {
            padding: 12px 0;
            border-bottom: 1px solid #eef2f6;
        }

        .list-item:last-child {
            border-bottom: none;
        }

        .list-item-title {
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        .list-item-meta {
            font-size: 12px;
            color: #6c757d;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .list-item-meta i {
            color: var(--secondary);
            width: 14px;
        }

        .badge-status {
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-confirmed { background: #10b981; color: white; }
        .badge-pending { background: #f59e0b; color: white; }

        /* Tables */
        .table-custom {
            width: 100%;
        }

        .table-custom thead th {
            background: var(--primary-dark);
            color: white;
            padding: 12px 15px;
            font-size: 13px;
            font-weight: 600;
        }

        .table-custom tbody td {
            padding: 12px 15px;
            border-bottom: 1px solid #eef2f6;
            font-size: 13px;
            vertical-align: middle;
        }

        .table-custom tbody tr:hover {
            background: #faf9f7;
        }

        .balance-due { color: #ef4444; font-weight: 600; }
        .balance-paid { color: #10b981; font-weight: 600; }

        /* Buttons */
        .btn-record {
            background: #10b981;
            color: white;
            padding: 6px 15px;
            border-radius: 8px;
            font-size: 12px;
            border: none;
            transition: all 0.2s;
        }

        .btn-record:hover {
            background: #059669;
            transform: translateY(-2px);
        }

        .btn-delete {
            background: #ef4444;
            color: white;
            padding: 5px 12px;
            border-radius: 8px;
            font-size: 12px;
            border: none;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }

        /* Quick Actions */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }

        .action-btn {
            padding: 12px;
            border-radius: 12px;
            text-align: center;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.2s;
            text-decoration: none;
            display: block;
        }

        .action-btn:hover {
            transform: translateY(-3px);
        }

        /* Progress */
        .progress-custom {
            height: 6px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 8px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 10px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
        }

        .empty-state i {
            font-size: 48px;
            color: var(--secondary);
            opacity: 0.3;
            margin-bottom: 15px;
        }

        .empty-state p {
            color: #6c757d;
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .actions-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .actions-grid {
                grid-template-columns: 1fr;
            }
            .table-custom thead {
                display: none;
            }
            .table-custom tbody tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid #eef2f6;
                border-radius: 12px;
            }
            .table-custom tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 15px;
            }
            .table-custom tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                width: 40%;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <?php 
            $logo_path = 'assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" style="width: 35px; height: 35px; border-radius: 50%; object-fit: cover; margin-right: 10px;">
            <?php else: ?>
                <i class="fas fa-gavel me-2"></i>
            <?php endif; ?>
            Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="cases.php"><i class="fas fa-briefcase me-1"></i> Cases</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="dashboard-wrapper">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2">
                <div class="sidebar">
                    <div class="text-center mb-3">
                        <?php 
                        if (file_exists($logo_path)): 
                        ?>
                            <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; margin-bottom: 10px; border: 2px solid var(--secondary);">
                        <?php else: ?>
                            <div style="width: 50px; height: 50px; background: var(--secondary); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 10px;">
                                <i class="fas fa-gavel" style="color: var(--primary-dark); font-size: 1.5rem;"></i>
                            </div>
                        <?php endif; ?>
                        <h6 class="text-white mb-0">Lawyer Portal</h6>
                        <small class="text-white-50"><?php echo htmlspecialchars($user_name); ?></small>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link active" href="lawyer_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="cases.php"><i class="fas fa-briefcase"></i> Case Tracker</a></li>
                        <li class="nav-item"><a class="nav-link" href="../documents.php"><i class="fas fa-file-alt"></i> Documents</a></li>
                        <li class="nav-item"><a class="nav-link" href="../hearings.php"><i class="fas fa-calendar"></i> Hearings</a></li>
                        <li class="nav-item"><a class="nav-link" href="../messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                        
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10">
                <!-- Welcome -->
                <div class="card-modern">
                    <div class="card-body">
                        <h2 style="color: var(--primary-dark); font-size: 24px; margin-bottom: 5px;">Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
                        <p class="text-muted" style="margin-bottom: 0;">Manage your cases, clients, hearings, and payments</p>
                    </div>
                </div>

                <!-- Success/Error Alerts -->
                <?php if($show_success && $success_msg): ?>
                    <div class="alert alert-success-custom alert-custom">
                        <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
                    </div>
                <?php endif; ?>
                
                <?php if(isset($_GET['payment_success'])): ?>
                    <div class="alert alert-success-custom alert-custom">
                        <i class="fas fa-check-circle me-2"></i> Payment recorded successfully!
                    </div>
                <?php endif; ?>
                
                <?php if(isset($error_message)): ?>
                    <div class="alert alert-danger-custom alert-custom">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <!-- Manual Client + Case Addition Section -->
                <div class="client-add-section">
                    <div class="d-flex align-items-center mb-3">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; margin-right: 12px;">
                            <i class="fas fa-user-plus" style="color: var(--primary-dark);"></i>
                        </div>
                        <div>
                            <h5 style="color: var(--primary-dark); margin: 0;">Manual Client & Case Registration</h5>
                            <p class="text-muted small mb-0">Add new client and case when client cannot login themselves</p>
                        </div>
                    </div>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="mb-3" style="color: var(--primary-dark);"><i class="fas fa-user"></i> Client Information</h6>
                                <div class="form-group mb-3">
                                    <label>Full Name <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="client_name" required placeholder="Enter client's full name">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Email Address <span class="required">*</span></label>
                                    <input type="email" class="form-control" name="client_email" required placeholder="client@example.com">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Phone Number</label>
                                    <input type="tel" class="form-control" name="client_phone" placeholder="+91 1234567890">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Address</label>
                                    <textarea class="form-control" name="client_address" rows="2" placeholder="Full address"></textarea>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <h6 class="mb-3" style="color: var(--primary-dark);"><i class="fas fa-briefcase"></i> Case Information</h6>
                                <div class="form-group mb-3">
                                    <label>Case Number (Optional - Auto generated if left blank)</label>
                                    <input type="text" class="form-control" name="case_number" placeholder="e.g., CASE-2024-001">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Case Title <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="case_title" required placeholder="Brief case title">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Case Type</label>
                                    <select class="form-select" name="case_type">
                                        <option value="Civil">Civil</option>
                                        <option value="Criminal">Criminal</option>
                                        <option value="Corporate">Corporate</option>
                                        <option value="Family">Family</option>
                                        <option value="Property">Property</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label>Filing Date</label>
                                    <input type="date" class="form-control" name="filing_date" value="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Case Description</label>
                                    <textarea class="form-control" name="case_description" rows="2" placeholder="Detailed description of the case..."></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" name="add_client_case" class="btn-submit-client">
                                    <i class="fas fa-save me-2"></i> Register Client & Create Case
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Stats -->
                <div class="stats-grid">
                    <div class="stat-box">
                        <div class="stat-info">
                            <h3><?php echo $active_cases; ?></h3>
                            <p>Active Cases</p>
                        </div>
                        <div class="stat-icon icon-cases"><i class="fas fa-briefcase"></i></div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-info">
                            <h3><?php echo $upcoming_hearings; ?></h3>
                            <p>Upcoming Hearings</p>
                        </div>
                        <div class="stat-icon icon-hearings"><i class="fas fa-gavel"></i></div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-info">
                            <h3><?php echo $pending_tasks; ?></h3>
                            <p>Pending Tasks</p>
                        </div>
                        <div class="stat-icon icon-tasks"><i class="fas fa-tasks"></i></div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-info">
                            <h3>₹<?php echo number_format($payment_stats['total_collected'], 2); ?></h3>
                            <p>Total Collected</p>
                        </div>
                        <div class="stat-icon icon-payment"><i class="fas fa-rupee-sign"></i></div>
                    </div>
                </div>

                <!-- Payment Summary Row -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card-modern" style="background: linear-gradient(135deg, var(--primary-dark), var(--primary)); color: white;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-1 opacity-75">Total Billed</p>
                                        <h3 class="mb-0">₹<?php echo number_format($payment_stats['total_billed'], 2); ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: rgba(255,255,255,0.2);"><i class="fas fa-file-invoice"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-modern" style="background: linear-gradient(135deg, #10b981, #059669); color: white;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-1 opacity-75">Total Collected</p>
                                        <h3 class="mb-0">₹<?php echo number_format($payment_stats['total_collected'], 2); ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: rgba(255,255,255,0.2);"><i class="fas fa-check-circle"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-modern" style="background: linear-gradient(135deg, #ef4444, #dc2626); color: white;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-1 opacity-75">Pending Amount</p>
                                        <h3 class="mb-0">₹<?php echo number_format($payment_stats['total_pending'], 2); ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: rgba(255,255,255,0.2);"><i class="fas fa-clock"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Payment Overview & Quick Entry -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-modern">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-pie"></i> Payment Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-6">
                                        <h4 style="color: #10b981;">₹<?php echo number_format($payment_stats['total_collected'], 2); ?></h4>
                                        <p class="text-muted small">Total Collected</p>
                                    </div>
                                    <div class="col-6">
                                        <h4 style="color: #ef4444;">₹<?php echo number_format($payment_stats['total_pending'], 2); ?></h4>
                                        <p class="text-muted small">Pending Payment</p>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span>Collection Rate</span>
                                        <span><?php echo $payment_stats['total_billed'] > 0 ? round(($payment_stats['total_collected'] / $payment_stats['total_billed']) * 100, 1) : 0; ?>%</span>
                                    </div>
                                    <div class="progress-custom">
                                        <div class="progress-fill" style="width: <?php echo $payment_stats['total_billed'] > 0 ? ($payment_stats['total_collected'] / $payment_stats['total_billed']) * 100 : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-modern">
                            <div class="card-header">
                                <h5><i class="fas fa-file-invoice-dollar"></i> Quick Payment</h5>
                            </div>
                            <div class="card-body">
                                <button class="btn-payment-entry" data-bs-toggle="modal" data-bs-target="#recordPaymentModal" style="background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); color: var(--primary-dark); padding: 12px; border-radius: 12px; font-weight: 600; border: none; width: 100%;">
                                    <i class="fas fa-plus-circle me-2"></i> Record New Payment
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Hearings & Schedule -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-modern">
                            <div class="card-header">
                                <h5><i class="fas fa-gavel"></i> Upcoming Hearings</h5>
                            </div>
                            <div class="card-body">
                                <?php if($hearings && $hearings->num_rows > 0): ?>
                                    <?php while($hearing = $hearings->fetch_assoc()): ?>
                                        <div class="list-item">
                                            <div class="list-item-title"><?php echo htmlspecialchars($hearing['case_number']); ?> - <?php echo substr(htmlspecialchars($hearing['title']), 0, 40); ?></div>
                                            <div class="list-item-meta">
                                                <span><i class="fas fa-calendar-alt"></i> <?php echo date('M d, Y', strtotime($hearing['hearing_date'])); ?></span>
                                                <span><i class="fas fa-clock"></i> <?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></span>
                                                <span><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($hearing['venue']); ?></span>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-calendar-times"></i>
                                        <p>No upcoming hearings</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-modern">
                            <div class="card-header">
                                <h5><i class="fas fa-calendar-check"></i> My Schedule</h5>
                            </div>
                            <div class="card-body">
                                <?php if($appointments && $appointments->num_rows > 0): ?>
                                    <?php while($apt = $appointments->fetch_assoc()): ?>
                                        <div class="list-item">
                                            <div class="list-item-title"><i class="fas fa-user"></i> <?php echo htmlspecialchars($apt['client_name']); ?></div>
                                            <div class="list-item-meta">
                                                <span><i class="fas fa-calendar-alt"></i> <?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?></span>
                                                <span><i class="fas fa-clock"></i> <?php echo date('g:i A', strtotime($apt['appointment_time'])); ?></span>
                                                <span class="badge-status badge-<?php echo $apt['status']; ?>"><?php echo ucfirst($apt['status']); ?></span>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-calendar-week"></i>
                                        <p>No upcoming appointments</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cases Payment Status -->
                <div class="card-modern">
                    <div class="card-header">
                        <h5><i class="fas fa-rupee-sign"></i> Cases Payment Status</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table-custom table">
                                <thead>
                                    <tr>
                                        <th>Case #</th>
                                        <th>Case Title</th>
                                        <th>Client</th>
                                        <th>Total Billed</th>
                                        <th>Paid Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Payment %</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($cases_with_payment && $cases_with_payment->num_rows > 0): ?>
                                        <?php while($case = $cases_with_payment->fetch_assoc()): 
                                            $payment_percent = $case['billed_amount'] > 0 ? ($case['paid_amount'] / $case['billed_amount']) * 100 : 0;
                                        ?>
                                            <tr>
                                                <td data-label="Case #"><strong><?php echo htmlspecialchars($case['case_number']); ?></strong></td>
                                                <td数据-label="Case Title"><?php echo substr(htmlspecialchars($case['title']), 0, 35); ?></td>
                                                <td数据-label="Client"><?php echo htmlspecialchars($case['client_name']); ?></td>
                                                <td data-label="Total Billed" class="fw-bold">₹<?php echo number_format($case['billed_amount'], 2); ?></td>
                                                <td data-label="Paid Amount" class="balance-paid">₹<?php echo number_format($case['paid_amount'], 2); ?></td>
                                                <td data-label="Pending Amount" class="balance-due">₹<?php echo number_format($case['balance_due'], 2); ?></td>
                                                <td data-label="Payment %">
                                                    <div class="d-flex flex-column">
                                                        <small><?php echo round($payment_percent, 1); ?>% Paid</small>
                                                        <div class="progress-custom" style="height: 4px; margin-top: 4px;">
                                                            <div class="progress-fill" style="width: <?php echo $payment_percent; ?>%;"></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td data-label="Status">
                                                    <?php if($case['balance_due'] <= 0): ?>
                                                        <span class="badge" style="background: #10b981; color: white; padding: 5px 10px;">Fully Paid</span>
                                                    <?php elseif($case['paid_amount'] > 0): ?>
                                                        <span class="badge" style="background: #f59e0b; color: white; padding: 5px 10px;">Partial Payment</span>
                                                    <?php else: ?>
                                                        <span class="badge" style="background: #ef4444; color: white; padding: 5px 10px;">Pending</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td data-label="Action">
                                                    <button class="btn-record" onclick="openRecordPayment(<?php echo $case['id']; ?>, <?php echo $case['client_id']; ?>, '<?php echo htmlspecialchars($case['case_number']); ?>', <?php echo $case['balance_due']; ?>)">
                                                        <i class="fas fa-money-bill"></i> Add Payment
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="9" class="text-center py-4">No cases with payment data</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Recent Payments -->
                <div class="card-modern">
                    <div class="card-header">
                        <h5><i class="fas fa-history"></i> Recent Payments</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table-custom table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>Case</th>
                                        <th>Invoice</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($recent_payments && $recent_payments->num_rows > 0): ?>
                                        <?php while($payment = $recent_payments->fetch_assoc()): ?>
                                            <tr>
                                                <td data-label="Date"><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                                <td data-label="Client"><?php echo htmlspecialchars($payment['client_name']); ?></td>
                                                <td data-label="Case"><?php echo htmlspecialchars($payment['case_number']); ?></td>
                                                <td data-label="Invoice"><?php echo htmlspecialchars($payment['invoice_number']); ?></td>
                                                <td data-label="Amount" class="balance-paid">₹<?php echo number_format($payment['amount'], 2); ?></td>
                                                <td data-label="Method"><?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?></td>
                                                <td data-label="Action">
                                                    <a href="?delete_payment=<?php echo $payment['id']; ?>" class="btn-delete" onclick="return confirm('Delete this payment?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center py-4">No recent payments</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card-modern">
                    <div class="card-header">
                        <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="actions-grid">
                            <a href="add_case.php" class="action-btn" style="background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); color: var(--primary-dark);">
                                <i class="fas fa-plus-circle me-2"></i> New Case
                            </a>
                            <a href="hearings.php" class="action-btn" style="background: var(--primary-dark); color: white;">
                                <i class="fas fa-calendar-plus me-2"></i> Schedule Hearing
                            </a>
                            <a href="documents.php" class="action-btn" style="background: var(--primary); color: white;">
                                <i class="fas fa-upload me-2"></i> Upload Document
                            </a>
                            <a href="timesheets.php" class="action-btn" style="border: 2px solid var(--secondary); color: var(--primary-dark); background: transparent;">
                                <i class="fas fa-clock me-2"></i> Log Hours
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Record Payment Modal -->
<div class="modal fade payment-modal" id="recordPaymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, var(--primary-dark), var(--primary)); color: white;">
                <h5 class="modal-title"><i class="fas fa-money-bill-wave" style="color: var(--secondary);"></i> Record Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="case_id" id="payment_case_id">
                    <input type="hidden" name="client_id" id="payment_client_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Select Invoice</label>
                        <select class="form-select" name="invoice_id" id="invoice_select" required>
                            <option value="">Select Invoice...</option>
                            <?php 
                            $all_invoices->data_seek(0);
                            while($inv = $all_invoices->fetch_assoc()): ?>
                                <option value="<?php echo $inv['id']; ?>" data-case-id="<?php echo $inv['case_id']; ?>" data-client-id="<?php echo $inv['client_id']; ?>" data-amount="<?php echo $inv['amount']; ?>" data-paid="<?php echo $inv['paid_amount']; ?>">
                                    <?php echo htmlspecialchars($inv['invoice_number']); ?> - <?php echo htmlspecialchars($inv['case_number']); ?> - ₹<?php echo number_format($inv['amount'] - $inv['paid_amount'], 2); ?> due
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Amount</label>
                        <input type="number" step="0.01" class="form-control" name="amount" id="payment_amount" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Date</label>
                        <input type="date" class="form-control" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select" name="payment_method" required>
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="check">Check</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Transaction ID</label>
                        <input type="text" class="form-control" name="transaction_id" placeholder="Check #, Transaction ID">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Payment notes..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="record_payment" class="btn" style="background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); color: var(--primary-dark);">Record Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('invoice_select')?.addEventListener('change', function() {
        const opt = this.options[this.selectedIndex];
        document.getElementById('payment_case_id').value = opt.getAttribute('data-case-id');
        document.getElementById('payment_client_id').value = opt.getAttribute('data-client-id');
        const due = parseFloat(opt.getAttribute('data-amount')) - parseFloat(opt.getAttribute('data-paid'));
        document.getElementById('payment_amount').value = due.toFixed(2);
    });
    
    function openRecordPayment(caseId, clientId, caseNumber, balanceDue) {
        document.getElementById('payment_case_id').value = caseId;
        document.getElementById('payment_client_id').value = clientId;
        document.getElementById('payment_amount').value = balanceDue;
        const select = document.getElementById('invoice_select');
        for(let i = 0; i < select.options.length; i++) {
            if(select.options[i].getAttribute('data-case-id') == caseId) {
                select.selectedIndex = i;
                select.dispatchEvent(new Event('change'));
                break;
            }
        }
        new bootstrap.Modal(document.getElementById('recordPaymentModal')).show();
    }
</script>

</body>
</html>