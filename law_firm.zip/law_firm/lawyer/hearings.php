<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Hearings Management";
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Add hearing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_hearing'])) {
    $case_id = $_POST['case_id'];
    $hearing_date = $_POST['hearing_date'];
    $hearing_time = $_POST['hearing_time'];
    $venue = $_POST['venue'];
    $notes = $_POST['notes'];
    
    $stmt = $conn->prepare("INSERT INTO hearings (case_id, hearing_date, hearing_time, venue, notes, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssi", $case_id, $hearing_date, $hearing_time, $venue, $notes, $user_id);
    $stmt->execute();
    $success = "Hearing date added successfully!";
}

// Get cases for dropdown
$cases_query = "SELECT c.id, c.case_number, c.title FROM cases c";
if ($user_role == 'lawyer') {
    $cases_query .= " WHERE c.assigned_lawyer_id = $user_id";
} elseif ($user_role == 'client') {
    $cases_query .= " WHERE c.client_id = $user_id";
}
$cases = $conn->query($cases_query);

// Get upcoming hearings
$hearings_query = "SELECT h.*, c.case_number, c.title, u.full_name as created_by_name 
                  FROM hearings h 
                  JOIN cases c ON h.case_id = c.id 
                  JOIN users u ON h.created_by = u.id 
                  WHERE h.hearing_date >= CURDATE() 
                  ORDER BY h.hearing_date, h.hearing_time";
if ($user_role == 'lawyer') {
    $hearings_query .= " AND c.assigned_lawyer_id = $user_id";
} elseif ($user_role == 'client') {
    $hearings_query .= " AND c.client_id = $user_id";
}
$hearings = $conn->query($hearings_query);

require_once '../includes/header.php';
?>

<style>
    /* Page Specific Styles */
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
    }

    .page-container {
        background: var(--light);
        min-height: 100vh;
        padding: 30px 0 50px;
        margin-top: 70px;
    }

    /* Sidebar */
    .sidebar {
        background: linear-gradient(180deg, var(--primary-dark) 0%, var(--primary) 100%);
        min-height: 100vh;
        box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    }

    .sidebar .nav-link {
        color: rgba(255,255,255,0.85) !important;
        padding: 12px 20px;
        margin: 5px 10px;
        border-radius: 12px;
        transition: all 0.3s;
        font-weight: 500;
    }

    .sidebar .nav-link:hover {
        background: rgba(212, 175, 55, 0.15);
        color: var(--secondary) !important;
        transform: translateX(5px);
    }

    .sidebar .nav-link.active {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        color: var(--primary-dark) !important;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .sidebar .nav-link i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }

    /* Form Card */
    .form-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        margin-bottom: 25px;
    }

    .form-card .card-header {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        color: white;
        border: none;
        padding: 15px 20px;
    }

    .form-card .card-header h5 {
        margin: 0;
        font-weight: 700;
    }

    .form-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .form-card .card-body {
        padding: 25px;
    }

    /* Table Card */
    .table-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }

    .table-card .card-header {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        color: white;
        border: none;
        padding: 15px 20px;
    }

    .table-card .card-header h5 {
        margin: 0;
        font-weight: 700;
    }

    .table-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .table-card .card-body {
        padding: 20px;
    }

    /* Form Controls */
    .form-label {
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 8px;
    }

    .form-label i {
        color: var(--secondary);
        margin-right: 6px;
    }

    .form-control, .form-select {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px 15px;
        transition: all 0.3s;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--secondary);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        outline: none;
    }

    /* Table Styles */
    .hearings-table {
        width: 100%;
    }

    .hearings-table thead th {
        background: var(--primary-dark);
        color: white;
        font-weight: 600;
        padding: 12px 15px;
        border: none;
    }

    .hearings-table thead th:first-child {
        border-radius: 12px 0 0 0;
    }

    .hearings-table thead th:last-child {
        border-radius: 0 12px 0 0;
    }

    .hearings-table tbody tr {
        border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        transition: all 0.3s;
    }

    .hearings-table tbody tr:hover {
        background: rgba(212, 175, 55, 0.05);
    }

    .hearings-table tbody td {
        padding: 12px 15px;
        vertical-align: middle;
        color: var(--primary-dark);
    }

    /* Badge */
    .badge-date {
        background: var(--secondary);
        color: var(--primary-dark);
        padding: 6px 12px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 600;
    }

    /* Buttons */
    .btn-submit {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        padding: 10px 25px;
        border-radius: 12px;
        color: var(--primary-dark);
        font-weight: 700;
        transition: all 0.3s;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    /* Alert */
    .alert-success-custom {
        background: #d4edda;
        border-left: 4px solid #10b981;
        color: #155724;
        border-radius: 12px;
        padding: 12px 20px;
        margin-bottom: 20px;
    }

    /* DataTables */
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: var(--secondary) !important;
        color: var(--primary-dark) !important;
        border-color: var(--secondary) !important;
        border-radius: 8px !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        background: var(--secondary-light) !important;
        color: var(--primary-dark) !important;
        border-radius: 8px !important;
    }

    .dataTables_wrapper .dataTables_filter input {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 6px 12px;
        margin-left: 8px;
    }

    .dataTables_wrapper .dataTables_filter input:focus {
        border-color: var(--secondary);
        outline: none;
    }

    @media (max-width: 768px) {
        .sidebar {
            position: fixed;
            left: -280px;
            transition: left 0.3s;
            z-index: 1000;
        }
        
        .sidebar.show {
            left: 0;
        }
        
        .hearings-table thead {
            display: none;
        }
        
        .hearings-table tbody tr {
            display: block;
            margin-bottom: 15px;
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
        }
        
        .hearings-table tbody td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .hearings-table tbody td:before {
            content: attr(data-label);
            font-weight: 600;
            color: var(--primary-dark);
            margin-right: 15px;
        }
    }
</style>

<div class="page-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4 pb-2 border-bottom" style="border-color: rgba(212,175,55,0.3) !important;">
                        <div class="logo-icon-small mb-2" style="width: 50px; height: 50px; background: var(--secondary); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center;">
                            <i class="fas fa-gavel" style="color: var(--primary-dark); font-size: 1.5rem;"></i>
                        </div>
                        <h6 class="text-white mb-0">Hearings</h6>
                        <small class="text-white-50">Manage Court Dates</small>
                    </div>
                    <ul class="nav flex-column">
                        <?php if($user_role == 'lawyer'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="lawyer_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cases.php">
                                    <i class="fas fa-briefcase"></i> Cases
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="hearings.php">
                                    <i class="fas fa-calendar"></i> Hearings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../documents.php">
                                    <i class="fas fa-file-alt"></i> Documents
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="timesheets.php">
                                    <i class="fas fa-clock"></i> Timesheets
                                </a>
                            </li>
                        <?php elseif($user_role == 'client'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="client_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="my_cases.php">
                                    <i class="fas fa-briefcase"></i> My Cases
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="hearings.php">
                                    <i class="fas fa-calendar"></i> Hearings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../documents.php">
                                    <i class="fas fa-folder-open"></i> Documents
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item mt-4">
                            <hr style="border-color: rgba(212,175,55,0.3);">
                            <a class="nav-link" href="../profile.php">
                                <i class="fas fa-user-circle"></i> Profile
                            </a>
                            <a class="nav-link" href="../logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4">
                <div class="pt-3 pb-2 mb-3">
                    <h1 class="h2" style="color: var(--primary-dark);">
                        <i class="fas fa-calendar-alt" style="color: var(--secondary);"></i> Hearings Management
                    </h1>
                    <p class="text-muted">Schedule and track court hearings</p>
                </div>

                <div class="row">
                    <!-- Add Hearing Form -->
                    <div class="col-md-4 mb-4">
                        <div class="form-card">
                            <div class="card-header">
                                <h5><i class="fas fa-calendar-plus"></i> Add Hearing Date</h5>
                            </div>
                            <div class="card-body">
                                <?php if(isset($success)): ?>
                                    <div class="alert-success-custom">
                                        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST">
                                    <div class="mb-3">
                                        <label class="form-label"><i class="fas fa-briefcase"></i> Select Case</label>
                                        <select class="form-select" name="case_id" required>
                                            <option value="">Choose case...</option>
                                            <?php while($case = $cases->fetch_assoc()): ?>
                                                <option value="<?php echo $case['id']; ?>">
                                                    <?php echo $case['case_number']; ?> - <?php echo substr($case['title'], 0, 40); ?>
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label"><i class="fas fa-calendar-day"></i> Hearing Date</label>
                                            <input type="date" class="form-control" name="hearing_date" min="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label"><i class="fas fa-clock"></i> Hearing Time</label>
                                            <input type="time" class="form-control" name="hearing_time" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label"><i class="fas fa-map-marker-alt"></i> Venue/Court</label>
                                        <input type="text" class="form-control" name="venue" placeholder="e.g., Superior Court, Room 302" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label"><i class="fas fa-sticky-note"></i> Notes/Instructions</label>
                                        <textarea class="form-control" name="notes" rows="3" placeholder="Any special instructions for the client or legal team..."></textarea>
                                    </div>
                                    
                                    <button type="submit" name="add_hearing" class="btn btn-submit w-100">
                                        <i class="fas fa-save me-2"></i> Schedule Hearing
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hearings List -->
                    <div class="col-md-8">
                        <div class="table-card">
                            <div class="card-header">
                                <h5><i class="fas fa-list"></i> Upcoming Hearings</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="hearingsTable" class="hearings-table table">
                                        <thead>
                                            <tr>
                                                <th>Case #</th>
                                                <th>Case Title</th>
                                                <th>Hearing Date</th>
                                                <th>Time</th>
                                                <th>Venue</th>
                                                <th>Notes</th>
                                                <th>Added By</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($hearings && $hearings->num_rows > 0): ?>
                                                <?php while($hearing = $hearings->fetch_assoc()): ?>
                                                    <tr>
                                                        <td data-label="Case #"><strong><?php echo $hearing['case_number']; ?></strong></td>
                                                        <td data-label="Case Title"><?php echo substr($hearing['title'], 0, 40); ?></td>
                                                        <td data-label="Hearing Date">
                                                            <span class="badge-date">
                                                                <?php echo date('M d, Y', strtotime($hearing['hearing_date'])); ?>
                                                            </span>
                                                        </td>
                                                        <td data-label="Time"><?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></td>
                                                        <td data-label="Venue">
                                                            <i class="fas fa-map-marker-alt" style="color: var(--secondary);"></i>
                                                            <?php echo $hearing['venue']; ?>
                                                        </td>
                                                        <td data-label="Notes"><?php echo substr($hearing['notes'], 0, 50); ?></td>
                                                        <td data-label="Added By">
                                                            <small><i class="fas fa-user" style="color: var(--secondary);"></i> <?php echo $hearing['created_by_name']; ?></small>
                                                        </td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="7" class="text-center text-muted py-4">
                                                        <i class="fas fa-calendar-times fa-3x mb-3 d-block" style="color: var(--secondary); opacity: 0.5;"></i>
                                                        No upcoming hearings scheduled.
                                                    </table>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#hearingsTable').DataTable({
            order: [[2, 'asc']],
            pageLength: 15,
            language: {
                search: "Search hearings:",
                lengthMenu: "Show _MENU_ hearings",
                info: "Showing _START_ to _END_ of _TOTAL_ hearings",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "→",
                    previous: "←"
                }
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>