<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Case Management";
$user_role = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

// Build query based on role
switch($user_role) {
    case 'admin':
        $cases_query = "SELECT c.*, cl.full_name as client_name, l.full_name as lawyer_name 
                       FROM cases c 
                       LEFT JOIN users cl ON c.client_id = cl.id 
                       LEFT JOIN users l ON c.assigned_lawyer_id = l.id 
                       ORDER BY c.created_at DESC";
        break;
    case 'lawyer':
        $cases_query = "SELECT c.*, cl.full_name as client_name 
                       FROM cases c 
                       JOIN users cl ON c.client_id = cl.id 
                       WHERE c.assigned_lawyer_id = $user_id 
                       ORDER BY c.created_at DESC";
        break;
    case 'client':
        $cases_query = "SELECT c.*, l.full_name as lawyer_name 
                       FROM cases c 
                       LEFT JOIN users l ON c.assigned_lawyer_id = l.id 
                       WHERE c.client_id = $user_id 
                       ORDER BY c.created_at DESC";
        break;
    default:
        $cases_query = "SELECT * FROM cases LIMIT 10";
}

$cases = $conn->query($cases_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Case Management | ABT Law Firm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: #D4AF37;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Page Container */
        .page-container {
            background: #FDF8F0;
            min-height: 100vh;
            padding: 30px 0 50px;
            margin-top: 70px;
        }

        .cases-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .cases-card .card-header {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            color: white;
            border: none;
            padding: 18px 25px;
        }

        .cases-card .card-header h4 {
            margin: 0;
            font-weight: 700;
        }

        .cases-card .card-header h4 i {
            color: #D4AF37;
            margin-right: 10px;
        }

        .cases-card .card-header .btn-primary-custom {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            color: #4A0E17;
            font-weight: 600;
            padding: 8px 20px;
            border-radius: 12px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .cases-card .card-header .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: #4A0E17;
        }

        .cases-card .card-body {
            padding: 25px;
        }

        /* Table Styles */
        .data-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        .data-table thead th {
            background: #4A0E17;
            color: white;
            font-weight: 600;
            padding: 12px 15px;
            border: none;
        }

        .data-table thead th:first-child {
            border-radius: 12px 0 0 0;
        }

        .data-table thead th:last-child {
            border-radius: 0 12px 0 0;
        }

        .data-table tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }

        .data-table tbody tr:hover {
            background: rgba(212, 175, 55, 0.05);
            transform: scale(1.01);
        }

        .data-table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            color: #4A0E17;
        }

        /* Status Badges */
        .badge-status {
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-active {
            background: #d4edda;
            color: #155724;
        }

        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }

        .badge-closed {
            background: #e2e3e5;
            color: #383d41;
        }

        .badge-archived {
            background: #f8d7da;
            color: #721c24;
        }

        /* Progress Bar */
        .progress-custom {
            height: 25px;
            background: #e2e8f0;
            border-radius: 12px;
            overflow: hidden;
            min-width: 80px;
        }

        .progress-bar-custom {
            background: linear-gradient(90deg, #D4AF37, #F5D76E);
            color: #4A0E17;
            font-weight: 600;
            font-size: 12px;
            line-height: 25px;
            text-align: center;
            border-radius: 12px;
        }

        /* Action Buttons */
        .btn-action {
            padding: 5px 10px;
            margin: 0 2px;
            border-radius: 8px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-action:hover {
            transform: translateY(-2px);
        }

        .btn-view {
            background: #D4AF37;
            color: #4A0E17;
            border: none;
        }

        .btn-view:hover {
            background: #F5D76E;
            color: #4A0E17;
        }

        .btn-edit {
            background: #f59e0b;
            color: white;
            border: none;
        }

        .btn-edit:hover {
            background: #d97706;
            color: white;
        }

        .btn-delete {
            background: #C72A2A;
            color: white;
            border: none;
        }

        .btn-delete:hover {
            background: #8B2635;
            color: white;
        }

        /* DataTables Customization */
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #D4AF37 !important;
            color: #4A0E17 !important;
            border-color: #D4AF37 !important;
            border-radius: 8px !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #F5D76E !important;
            color: #4A0E17 !important;
            border-radius: 8px !important;
        }

        .dataTables_wrapper .dataTables_filter input {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 6px 12px;
            margin-left: 8px;
        }

        .dataTables_wrapper .dataTables_filter input:focus {
            border-color: #D4AF37;
            outline: none;
        }

        .dataTables_wrapper .dataTables_length select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 5px;
            margin: 0 5px;
        }

        @media (max-width: 768px) {
            .cases-card .card-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .cases-card .card-header .btn {
                width: 100%;
            }
            
            .data-table thead {
                display: none;
            }
            
            .data-table tbody tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid rgba(212, 175, 55, 0.2);
                border-radius: 12px;
            }
            
            .data-table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 15px;
                border-bottom: 1px solid rgba(212, 175, 55, 0.1);
            }
            
            .data-table tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                color: #4A0E17;
                margin-right: 10px;
            }
            
            .progress-custom {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>ABT Law Firm
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="lawyer_dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="page-container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="cases-card">
                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                        <h4 class="mb-0"><i class="fas fa-briefcase"></i> Case Management</h4>
                        <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                            <a href="add_case.php" class="btn btn-primary-custom">
                                <i class="fas fa-plus me-2"></i> Add New Case
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="casesTable" class="data-table table">
                                <thead>
                                    <tr>
                                        <th>Case #</th>
                                        <th>Title</th>
                                        <th>Client</th>
                                        <th>Assigned To</th>
                                        <th>Status</th>
                                        <th>Progress</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($cases && $cases->num_rows > 0): ?>
                                        <?php while($case = $cases->fetch_assoc()): ?>
                                        <tr>
                                            <td data-label="Case #">
                                                <strong style="color: #D4AF37;"><?php echo htmlspecialchars($case['case_number']); ?></strong>
                                            </td>
                                            <td data-label="Title"><?php echo htmlspecialchars(substr($case['title'], 0, 50)); ?><?php echo strlen($case['title']) > 50 ? '...' : ''; ?></td>
                                            <td data-label="Client"><?php echo htmlspecialchars($case['client_name'] ?? 'N/A'); ?></td>
                                            <td data-label="Assigned To"><?php echo htmlspecialchars($case['lawyer_name'] ?? 'Unassigned'); ?></td>
                                            <td data-label="Status">
                                                <span class="badge-status badge-<?php echo $case['status']; ?>">
                                                    <?php echo ucfirst($case['status']); ?>
                                                </span>
                                            </td>
                                            <td data-label="Progress">
                                                <div class="progress-custom">
                                                    <div class="progress-bar-custom" style="width: <?php echo $case['progress']; ?>%">
                                                        <?php echo $case['progress']; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td data-label="Created"><?php echo date('M d, Y', strtotime($case['created_at'])); ?></td>
                                            <td data-label="Actions">
                                                <a href="case_details.php?id=<?php echo $case['id']; ?>" class="btn btn-action btn-view" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if(in_array($user_role, ['admin', 'lawyer'])): ?>
                                                    <a href="edit_case.php?id=<?php echo $case['id']; ?>" class="btn btn-action btn-edit" title="Edit Case">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button onclick="deleteCase(<?php echo $case['id']; ?>)" class="btn btn-action btn-delete" title="Delete Case">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-4">
                                                <i class="fas fa-briefcase fa-3x mb-3" style="color: #D4AF37; opacity: 0.3;"></i>
                                                <p class="text-muted">No cases found.</p>
                                                <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                                                    <a href="add_case.php" class="btn btn-primary-custom mt-3">Create Your First Case</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        if ($('#casesTable tbody tr').length > 0 && $('#casesTable tbody tr td').length > 1) {
            $('#casesTable').DataTable({
                pageLength: 25,
                order: [[6, 'desc']],
                language: {
                    search: "Search cases:",
                    lengthMenu: "Show _MENU_ cases",
                    info: "Showing _START_ to _END_ of _TOTAL_ cases",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [
                    { orderable: false, targets: [7] }
                ]
            });
        }
    });
    
    function deleteCase(caseId) {
        if(confirm('⚠️ Are you sure you want to delete this case?\n\nThis action cannot be undone and will remove all related data including hearings, documents, and invoices.')) {
            window.location.href = 'delete_case.php?id=' + caseId;
        }
    }
</script>

</body>
</html>