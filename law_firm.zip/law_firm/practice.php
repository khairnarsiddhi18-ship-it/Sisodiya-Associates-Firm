<?php
$page_title = "Practice Areas";
require_once 'includes/header.php';
?>

<style>
    /* Page Specific Styles */
    .page-header {
        background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
        padding: 150px 0 80px;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .page-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(212,175,55,0.05)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        background-size: cover;
        animation: wave 15s ease-in-out infinite;
    }

    @keyframes wave {
        0%, 100% { transform: translateX(0) translateY(0); }
        50% { transform: translateX(-5%) translateY(10px); }
    }

    .practice-detail-card {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        transition: all 0.3s;
        border-bottom: 3px solid transparent;
        height: 100%;
    }

    .practice-detail-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.12);
        border-bottom-color: #D4AF37;
    }

    .practice-icon-large {
        width: 100px;
        height: 100px;
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 1.5rem;
        transition: all 0.3s;
    }

    .practice-detail-card:hover .practice-icon-large {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
    }

    .practice-icon-large i {
            font-size: 3rem;
            color: #4A0E17;
        }

        .practice-detail-card h3 {
            color: #4A0E17;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .practice-detail-card h5 {
            color: #4A0E17;
            font-weight: 600;
            margin: 1rem 0 0.8rem;
            font-size: 1.1rem;
        }

        .practice-detail-card ul li {
            margin-bottom: 8px;
            color: #4a5568;
        }

        .practice-detail-card ul li i {
            color: #D4AF37;
        }

        .btn-outline-custom {
            border: 2px solid #D4AF37;
            background: transparent;
            color: #4A0E17;
            padding: 10px 25px;
            border-radius: 50px;
            transition: all 0.3s;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }

        .btn-outline-custom:hover {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            color: #4A0E17;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            border-color: transparent;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .page-header {
                padding: 120px 0 60px;
            }
            
            .page-header h1 {
                font-size: 2rem;
            }
            
            .practice-detail-card {
                padding: 1.5rem;
            }
            
            .practice-icon-large {
                width: 80px;
                height: 80px;
            }
            
            .practice-icon-large i {
                font-size: 2.2rem;
            }
        }
    </style>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container text-center position-relative" style="z-index: 2;">
            <h1 class="display-3 fw-bold" data-aos="fade-down">Our Practice <span style="color: #D4AF37;">Areas</span></h1>
            <p class="lead" data-aos="fade-up">Comprehensive legal expertise across multiple domains</p>
        </div>
    </section>

    <!-- Practice Areas Content -->
    <section class="py-5" style="background: #FDF8F0;">
        <div class="container">
            <div class="row">
                <!-- Corporate Law -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-balance-scale"></i>
                        </div>
                        <h3>Corporate Law</h3>
                        <p class="text-muted">Strategic legal counsel for businesses of all sizes, from startups to multinational corporations.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> Business Formation & Structuring</li>
                            <li><i class="fas fa-check-circle me-2"></i> Mergers & Acquisitions</li>
                            <li><i class="fas fa-check-circle me-2"></i> Corporate Governance</li>
                            <li><i class="fas fa-check-circle me-2"></i> Contract Drafting & Review</li>
                            <li><i class="fas fa-check-circle me-2"></i> Regulatory Compliance</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>

                <!-- Real Estate Law -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-home"></i>
                        </div>
                        <h3>Real Estate Law</h3>
                        <p class="text-muted">Protecting your property rights and facilitating smooth real estate transactions.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> Property Transactions</li>
                            <li><i class="fas fa-check-circle me-2"></i> Title Searches & Insurance</li>
                            <li><i class="fas fa-check-circle me-2"></i> Lease Agreements</li>
                            <li><i class="fas fa-check-circle me-2"></i> Property Disputes</li>
                            <li><i class="fas fa-check-circle me-2"></i> Zoning & Land Use</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>

                <!-- Medical Malpractice -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <h3>Medical Malpractice</h3>
                        <p class="text-muted">Standing up for patients who have suffered from medical negligence.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> Surgical Errors</li>
                            <li><i class="fas fa-check-circle me-2"></i> Misdiagnosis Claims</li>
                            <li><i class="fas fa-check-circle me-2"></i> Birth Injuries</li>
                            <li><i class="fas fa-check-circle me-2"></i> Medication Errors</li>
                            <li><i class="fas fa-check-circle me-2"></i> Hospital Negligence</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>

                <!-- Criminal Defense -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="400">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-gavel"></i>
                        </div>
                        <h3>Criminal Defense</h3>
                        <p class="text-muted">Aggressive representation to protect your rights and freedom.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> DUI/DWI Defense</li>
                            <li><i class="fas fa-check-circle me-2"></i> Drug Charges</li>
                            <li><i class="fas fa-check-circle me-2"></i> White Collar Crimes</li>
                            <li><i class="fas fa-check-circle me-2"></i> Violent Crimes</li>
                            <li><i class="fas fa-check-circle me-2"></i> Appeals</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>

                <!-- Family Law -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="500">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-heart"></i>
                        </div>
                        <h3>Family Law</h3>
                        <p class="text-muted">Compassionate guidance through sensitive family matters.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> Divorce & Separation</li>
                            <li><i class="fas fa-check-circle me-2"></i> Child Custody & Support</li>
                            <li><i class="fas fa-check-circle me-2"></i> Spousal Support/Alimony</li>
                            <li><i class="fas fa-check-circle me-2"></i> Adoption</li>
                            <li><i class="fas fa-check-circle me-2"></i> Domestic Violence</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>

                <!-- Immigration Law -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="600">
                    <div class="practice-detail-card">
                        <div class="practice-icon-large">
                            <i class="fas fa-passport"></i>
                        </div>
                        <h3>Immigration Law</h3>
                        <p class="text-muted">Expert guidance for navigating complex immigration systems.</p>
                        <h5>Services Include:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle me-2"></i> Visas & Green Cards</li>
                            <li><i class="fas fa-check-circle me-2"></i> Citizenship Applications</li>
                            <li><i class="fas fa-check-circle me-2"></i> Deportation Defense</li>
                            <li><i class="fas fa-check-circle me-2"></i> Asylum Requests</li>
                            <li><i class="fas fa-check-circle me-2"></i> Employment Authorization</li>
                        </ul>
                        <a href="contact.php" class="btn-outline-custom mt-3 d-inline-block">Request Consultation →</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5" style="background: linear-gradient(135deg, #4A0E17, #6B1A2A);">
        <div class="container text-center">
            <h2 class="display-5 fw-bold text-white mb-4">Need Legal Assistance?</h2>
            <p class="lead text-white-50 mb-4">Schedule a free consultation with our expert attorneys today</p>
            <div class="d-flex gap-3 justify-content-center flex-wrap">
                <a href="register.php" class="btn btn-premium-primary px-5" style="background: linear-gradient(135deg, #D4AF37, #F5D76E); color: #4A0E17; border-radius: 50px; padding: 12px 30px; font-weight: 700; text-decoration: none;">Get Free Consultation</a>
                <a href="contact.php" class="btn btn-premium-outline px-5" style="border: 2px solid #D4AF37; color: white; border-radius: 50px; padding: 12px 30px; font-weight: 600; text-decoration: none;">Contact Us Now</a>
            </div>
        </div>
    </section>

<?php require_once 'includes/footer.php'; ?>