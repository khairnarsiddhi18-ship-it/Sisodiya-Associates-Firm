<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>ABT Law Firm | Excellence in Legal Services</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

<!-- Header -->
<?php include "includes/header.php"; ?>

<div class="overlay" id="overlay"></div>

<!-- Hero Section -->
<?php include "index_home/hero_home.php"; ?>

<!-- Practice Areas -->
<?php include "index_home/home_practice_areas.php"; ?>

<!-- About Us -->
<?php include "index_home/home_about_us.php"; ?>

<!-- Our Attorneys -->
<?php include "index_home/home_our_attorneys.php"; ?>

<!-- Clients Say (Testimonials) -->
<?php include "index_home/clients_say.php"; ?>

<!-- CTA Section -->
<?php include "index_home/cta_section.php"; ?>

<!-- Footer -->
<?php include "includes/footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // Initialize AOS
    AOS.init({ duration: 800, once: true, offset: 100 });

    // Hide loading spinner
    window.addEventListener('load', function() {
        setTimeout(() => {
            const spinner = document.getElementById('loadingSpinner');
            if (spinner) spinner.classList.add('hide');
        }, 500);
    });

    // Scroll Reveal Animation
    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.scroll-reveal');
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        revealElements.forEach(element => revealObserver.observe(element));
    }

    document.addEventListener('DOMContentLoaded', function() {
        initScrollReveal();
    });
</script>

<style>
/* Global Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    overflow-x: hidden;
    background: #ffffff;
    padding-top: 0;
}

.loading-spinner {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #4A0E17;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    transition: opacity 0.5s;
}

.loading-spinner.hide {
    opacity: 0;
    visibility: hidden;
}

.spinner {
    width: 50px;
    height: 50px;
    border: 3px solid rgba(212, 175, 55, 0.2);
    border-top-color: #D4AF37;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.scroll-reveal {
    opacity: 0;
    transform: translateY(30px);
    transition: all 0.6s ease;
}

.scroll-reveal.revealed {
    opacity: 1;
    transform: translateY(0);
}

@media (max-width: 768px) {
    .scroll-reveal {
        transform: translateY(20px);
    }
}
</style>

</body>
</html>