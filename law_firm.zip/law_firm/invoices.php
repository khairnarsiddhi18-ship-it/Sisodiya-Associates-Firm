<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id']) ) {
    header("Location: login.php");
    exit();
}

$page_title = "Invoices & Billing";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'client';

// Get all invoices for the client
$invoices = $conn->query("
    SELECT i.*, c.case_number, c.title as case_title
    FROM invoices i
    LEFT JOIN cases c ON i.case_id = c.id
    WHERE i.client_id = $user_id
    ORDER BY i.created_at DESC
");

// Get invoice statistics
$stats = [];
$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE client_id = $user_id");
$stats['total_billed'] = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE client_id = $user_id AND status = 'paid'");
$stats['total_paid'] = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE client_id = $user_id AND status = 'pending'");
$stats['total_pending'] = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE client_id = $user_id AND status = 'overdue'");
$stats['total_overdue'] = $result->fetch_assoc()['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM invoices WHERE client_id = $user_id AND status = 'paid'");
$stats['paid_count'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM invoices WHERE client_id = $user_id AND status IN ('pending', 'overdue')");
$stats['unpaid_count'] = $result->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Invoices & Billing | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #D4AF37;
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: #D4AF37;
            margin-right: 5px;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Page Container */
        .page-container {
            background: #FDF8F0;
            min-height: 100vh;
            padding: 30px 0 50px;
            margin-top: 70px;
        }

        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            height: 100%;
            border-bottom: 3px solid transparent;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-bottom-color: #D4AF37;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }

        .stat-icon i {
            font-size: 24px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 5px;
            color: #4A0E17;
        }

        /* Invoice Card */
        .invoice-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .invoice-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-left-color: #D4AF37;
        }

        .invoice-header {
            padding: 20px;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .invoice-number {
            font-size: 16px;
            font-weight: 700;
            color: #D4AF37;
            letter-spacing: 1px;
        }

        .invoice-date {
            font-size: 12px;
            color: #718096;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-paid { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-overdue { background: #f8d7da; color: #721c24; animation: pulse 2s infinite; }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .invoice-body {
            padding: 20px;
        }

        .amount {
            font-size: 24px;
            font-weight: 800;
            color: #4A0E17;
        }

        .btn-download {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            padding: 8px 20px;
            border-radius: 12px;
            color: #4A0E17;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: #4A0E17;
        }

        .btn-pay {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            padding: 8px 20px;
            border-radius: 12px;
            color: white;
            transition: all 0.3s;
        }

        .btn-pay:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
            color: white;
        }

        .payment-history-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-top: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border: 1px solid rgba(212, 175, 55, 0.2);
        }

        .payment-history-card h5 {
            color: #4A0E17;
            font-weight: 700;
        }

        .payment-history-card h5 i {
            color: #D4AF37;
        }

        .border-bottom {
            border-bottom: 1px solid rgba(212, 175, 55, 0.2) !important;
        }

        /* Modal Styles */
        .modal-header-custom {
            background: linear-gradient(135deg, #4A0E17, #6B1A2A);
            border-bottom: none;
        }

        .modal-header-custom .btn-close {
            background: white;
            opacity: 1;
        }

        .modal-title-custom {
            color: white;
        }

        .modal-title-custom i {
            color: #D4AF37;
            margin-right: 8px;
        }

        .btn-primary-modal {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            color: #4A0E17;
            font-weight: 600;
        }

        .btn-primary-modal:hover {
            background: linear-gradient(135deg, #F5D76E, #D4AF37);
            color: #4A0E17;
        }

        .text-primary {
            color: #D4AF37 !important;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .invoice-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .invoice-actions {
                width: 100%;
            }
            
            .btn-download, .btn-pay {
                width: 100%;
                margin-top: 5px;
            }
            
            .stat-value {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-logo" href="index.php">
            <?php 
            $logo_path = 'assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
            <?php else: ?>
                <div style="width: 40px; height: 40px; border-radius: 50%; background: #D4AF37; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-gavel" style="color: #4A0E17; font-size: 1.2rem;"></i>
                </div>
            <?php endif; ?>
            <span class="navbar-logo-text"><i class="fas fa-gavel"></i>Sisodiya Associates</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="client_dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="my_cases.php"><i class="fas fa-briefcase me-1"></i> My Cases</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Page Container -->
<div class="page-container">
    <div class="container">
        <!-- Page Header -->
        <div class="mb-4">
            <h1 class="display-5 fw-bold" style="color: #4A0E17;">Invoices & <span style="color: #D4AF37;">Billing</span></h1>
            <p class="text-muted">View and manage your billing history</p>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(212, 175, 55, 0.1);">
                        <i class="fas fa-rupee-sign" style="color: #D4AF37;"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_billed'], 2); ?></div>
                    <div class="text-muted small">Total Billed</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1);">
                        <i class="fas fa-check-circle" style="color: #10b981;"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_paid'], 2); ?></div>
                    <div class="text-muted small">Total Paid</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1);">
                        <i class="fas fa-clock" style="color: #f59e0b;"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_pending'], 2); ?></div>
                    <div class="text-muted small">Pending Payment</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(239, 68, 68, 0.1);">
                        <i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_overdue'], 2); ?></div>
                    <div class="text-muted small">Overdue</div>
                </div>
            </div>
        </div>

        <!-- Invoices List -->
        <?php if($invoices && $invoices->num_rows > 0): ?>
            <?php while($invoice = $invoices->fetch_assoc()): ?>
                <div class="invoice-card">
                    <div class="invoice-header d-flex justify-content-between align-items-center flex-wrap">
                        <div>
                            <div class="invoice-number">
                                <i class="fas fa-receipt"></i> <?php echo htmlspecialchars($invoice['invoice_number']); ?>
                            </div>
                            <div class="invoice-date">
                                <i class="far fa-calendar-alt"></i> Issued: <?php echo date('F d, Y', strtotime($invoice['created_at'])); ?>
                                <?php if($invoice['due_date']): ?>
                                    | Due: <?php echo date('F d, Y', strtotime($invoice['due_date'])); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <span class="status-badge status-<?php echo $invoice['status']; ?>">
                                <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                <?php echo ucfirst($invoice['status']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="invoice-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="amount">
                                    ₹<?php echo number_format($invoice['amount'], 2); ?>
                                </div>
                                <?php if($invoice['case_number']): ?>
                                    <div class="text-muted small mt-1">
                                        <i class="fas fa-briefcase" style="color: #D4AF37;"></i> Case: <?php echo htmlspecialchars($invoice['case_number']); ?>
                                        <?php if($invoice['case_title']): ?> - <?php echo htmlspecialchars($invoice['case_title']); ?><?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($invoice['description']): ?>
                                    <div class="text-muted small mt-1">
                                        <i class="fas fa-align-left" style="color: #D4AF37;"></i> <?php echo htmlspecialchars($invoice['description']); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($invoice['paid_amount'] > 0): ?>
                                    <div class="text-success small mt-1">
                                        <i class="fas fa-check-circle"></i> Paid: ₹<?php echo number_format($invoice['paid_amount'], 2); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 text-md-end mt-3 mt-md-0 invoice-actions">
                                <a href="get_invoice.php?id=<?php echo $invoice['id']; ?>" target="_blank" class="btn btn-download me-2">
                                    <i class="fas fa-download"></i> Download PDF
                                </a>
                                <?php if($invoice['status'] != 'paid'): ?>
                                    <button class="btn btn-pay" onclick="openPaymentModal(<?php echo $invoice['id']; ?>, <?php echo $invoice['amount']; ?>)">
                                        <i class="fas fa-credit-card"></i> Pay Now
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <div class="mb-4">
                    <i class="fas fa-file-invoice fa-5x" style="color: #D4AF37; opacity: 0.5;"></i>
                </div>
                <h3 style="color: #4A0E17;">No Invoices Found</h3>
                <p class="text-muted">You don't have any invoices yet.</p>
            </div>
        <?php endif; ?>

        <!-- Payment History Summary -->
        <div class="payment-history-card">
            <h5 class="mb-3"><i class="fas fa-history"></i> Payment Summary</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Total Invoices:</span>
                        <strong style="color: #4A0E17;"><?php echo $invoices->num_rows; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Paid Invoices:</span>
                        <strong class="text-success"><?php echo $stats['paid_count']; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Unpaid Invoices:</span>
                        <strong class="text-warning"><?php echo $stats['unpaid_count']; ?></strong>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Total Paid:</span>
                        <strong class="text-success">₹<?php echo number_format($stats['total_paid'], 2); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Total Due:</span>
                        <strong class="text-danger">₹<?php echo number_format($stats['total_pending'] + $stats['total_overdue'], 2); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title modal-title-custom"><i class="fas fa-credit-card"></i> Make Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <div class="display-6 fw-bold text-primary" id="modalAmount">₹0.00</div>
                    <p class="text-muted">Invoice #<span id="modalInvoice"></span></p>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-lock"></i> Secure payment processing
                </div>
                
                <form id="paymentForm">
                    <input type="hidden" id="paymentInvoiceId" name="invoice_id">
                    <div class="mb-3">
                        <label class="form-label">Card Number</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                            <input type="text" class="form-control" placeholder="1234 5678 9012 3456" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Expiry Date</label>
                            <input type="text" class="form-control" placeholder="MM/YY" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">CVV</label>
                            <input type="password" class="form-control" placeholder="123" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Cardholder Name</label>
                        <input type="text" class="form-control" placeholder="Name on card" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary-modal" onclick="processPayment()">
                    <i class="fas fa-check-circle"></i> Pay Now
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function openPaymentModal(invoiceId, amount) {
        document.getElementById('paymentInvoiceId').value = invoiceId;
        document.getElementById('modalAmount').innerText = '₹' + amount.toLocaleString();
        document.getElementById('modalInvoice').innerText = invoiceId;
        new bootstrap.Modal(document.getElementById('paymentModal')).show();
    }
    
    function processPayment() {
        // Here you would integrate with a payment gateway like Stripe, PayPal, etc.
        alert('Payment processing demo. In production, integrate with Stripe/PayPal API.');
        bootstrap.Modal.getInstance(document.getElementById('paymentModal')).hide();
        
        // Show success message
        const successDiv = document.createElement('div');
        successDiv.className = 'alert alert-success alert-dismissible fade show mt-3';
        successDiv.innerHTML = 'Payment initiated! You will receive a confirmation email shortly.<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
        document.querySelector('.page-container .container').insertBefore(successDiv, document.querySelector('.page-container .container').firstChild);
        
        setTimeout(() => successDiv.remove(), 5000);
    }
    
    // Auto-hide alerts after 5 seconds
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(alert => alert.remove());
    }, 5000);
</script>

</body>
</html>