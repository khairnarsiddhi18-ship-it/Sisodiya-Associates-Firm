<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized', 'success' => false]);
    exit();
}

$user_id = $_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
$question = strtolower(trim($input['question'] ?? ''));
$session_id = $input['session_id'] ?? session_id();

if (empty($question)) {
    echo json_encode(['error' => 'No question provided', 'success' => false]);
    exit();
}

// Function to get answer from FAQ database
function getFAQAnswer($conn, $question) {
    $keywords = explode(' ', $question);
    $score_query = [];
    $params = [];
    
    foreach ($keywords as $keyword) {
        if (strlen($keyword) > 3) {
            $score_query[] = "keywords LIKE ?";
            $params[] = "%$keyword%";
        }
    }
    
    if (empty($score_query)) {
        return null;
    }
    
    $sql = "SELECT question, answer FROM chatbot_faq 
            WHERE is_active = 1 AND (" . implode(' OR ', $score_query) . ")
            ORDER BY priority DESC 
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return [
            'answer' => $row['answer'],
            'intent' => 'faq'
        ];
    }
    
    return null;
}

// Function to get case-specific answers
function getCaseAnswer($conn, $user_id, $question) {
    if (strpos($question, 'my case') !== false || strpos($question, 'my hearing') !== false || strpos($question, 'case status') !== false) {
        
        // Get active cases
        $cases = $conn->query("
            SELECT c.case_number, c.title, c.status, c.progress,
                   (SELECT hearing_date FROM hearings WHERE case_id = c.id AND hearing_date >= CURDATE() ORDER BY hearing_date LIMIT 1) as next_hearing
            FROM cases c
            WHERE c.client_id = $user_id AND c.status != 'archived'
            LIMIT 3
        ");
        
        if ($cases && $cases->num_rows > 0) {
            $case_info = [];
            while ($case = $cases->fetch_assoc()) {
                $case_info[] = "- Case #{$case['case_number']}: {$case['title']} ({$case['progress']}% complete) - Status: " . ucfirst($case['status']);
                if ($case['next_hearing']) {
                    $case_info[] = "  Next hearing: " . date('M d, Y', strtotime($case['next_hearing']));
                }
            }
            
            return [
                'answer' => "Here are your active cases:\n" . implode("\n", $case_info) . "\n\nWould you like more details about any specific case?",
                'intent' => 'case_specific'
            ];
        }
        
        return [
            'answer' => "You don't have any active cases at the moment. If you need legal assistance, please contact our office to discuss your matter.",
            'intent' => 'case_specific'
        ];
    }
    
    return null;
}

// Function to get appointment-related answers
function getAppointmentAnswer($conn, $user_id, $question) {
    if (strpos($question, 'appointment') !== false || strpos($question, 'schedule') !== false || strpos($question, 'book') !== false) {
        $appointments = $conn->query("
            SELECT a.*, u.full_name as lawyer_name 
            FROM appointments a
            JOIN users u ON a.lawyer_id = u.id
            WHERE a.client_id = $user_id AND a.appointment_date >= CURDATE()
            ORDER BY a.appointment_date
            LIMIT 3
        ");
        
        if ($appointments && $appointments->num_rows > 0) {
            $apt_list = [];
            while ($apt = $appointments->fetch_assoc()) {
                $apt_list[] = "- " . date('M d, Y', strtotime($apt['appointment_date'])) . " at {$apt['appointment_time']} with {$apt['lawyer_name']} (Status: {$apt['status']})";
            }
            return [
                'answer' => "Your upcoming appointments:\n" . implode("\n", $apt_list) . "\n\nTo schedule a new appointment, use the Book Appointment section in your dashboard.",
                'intent' => 'appointment'
            ];
        } else {
            return [
                'answer' => "You don't have any upcoming appointments. Would you like to schedule one? You can book an appointment from your client dashboard.",
                'intent' => 'appointment'
            ];
        }
    }
    return null;
}

// Function to get invoice answers
function getInvoiceAnswer($conn, $user_id, $question) {
    if (strpos($question, 'invoice') !== false || strpos($question, 'bill') !== false || strpos($question, 'payment') !== false || strpos($question, 'pay') !== false) {
        $result = $conn->query("
            SELECT SUM(amount) as total_due, COUNT(*) as invoice_count
            FROM invoices 
            WHERE client_id = $user_id AND status != 'paid'
        ");
        $due = $result->fetch_assoc();
        
        if ($due && $due['invoice_count'] > 0) {
            return [
                'answer' => "You have {$due['invoice_count']} pending invoice(s) totaling $" . number_format($due['total_due'], 2) . ". You can view and pay your invoices in the Billing Portal section of your dashboard.",
                'intent' => 'billing'
            ];
        } else {
            return [
                'answer' => "You have no pending invoices. All your payments are up to date!",
                'intent' => 'billing'
            ];
        }
    }
    return null;
}

// Function to get document answers
function getDocumentAnswer($conn, $user_id, $question) {
    if (strpos($question, 'document') !== false || strpos($question, 'upload') !== false || strpos($question, 'file') !== false) {
        return [
            'answer' => "You can upload documents related to your case from the Documents section in your dashboard. Supported formats include PDF, DOC, DOCX, JPG, and PNG. Make sure to select the correct case when uploading.",
            'intent' => 'documents'
        ];
    }
    return null;
}

// Function to get lawyer contact answer
function getLawyerContactAnswer($conn, $user_id, $question) {
    if (strpos($question, 'lawyer') !== false || strpos($question, 'contact') !== false || strpos($question, 'attorney') !== false) {
        $lawyer = $conn->query("
            SELECT u.full_name, u.email, u.phone
            FROM cases c
            JOIN users u ON c.assigned_lawyer_id = u.id
            WHERE c.client_id = $user_id AND c.status = 'active'
            LIMIT 1
        ");
        
        if ($lawyer && $lawyer->num_rows > 0) {
            $law = $lawyer->fetch_assoc();
            return [
                'answer' => "Your assigned lawyer is {$law['full_name']}. You can contact them at:\n📧 Email: {$law['email']}\n📞 Phone: {$law['phone']}\n\nYou can also send a message through the Message Board in your dashboard.",
                'intent' => 'contact'
            ];
        } else {
            return [
                'answer' => "You don't have an assigned lawyer yet. Please contact our office to get legal assistance.",
                'intent' => 'contact'
            ];
        }
    }
    return null;
}

// Function to get fee structure answer
function getFeeAnswer($question) {
    if (strpos($question, 'fee') !== false || strpos($question, 'cost') !== false || strpos($question, 'price') !== false || strpos($question, 'charge') !== false) {
        return [
            'answer' => "Our fee structure varies by case type:\n\n• Hourly Rate: Billed per hour of work\n• Contingency Fee: Percentage of settlement (common in injury cases)\n• Flat Fee: Fixed amount for specific services\n• Retainer: Advance payment for ongoing services\n\nPlease check your engagement letter or contact our billing department for specific fee details.",
            'intent' => 'fees'
        ];
    }
    return null;
}

// Function to get hearing answer
function getHearingAnswer($conn, $user_id, $question) {
    if (strpos($question, 'hearing') !== false || strpos($question, 'court') !== false) {
        $hearing = $conn->query("
            SELECT h.*, c.case_number, c.title
            FROM hearings h
            JOIN cases c ON h.case_id = c.id
            WHERE c.client_id = $user_id AND h.hearing_date >= CURDATE()
            ORDER BY h.hearing_date
            LIMIT 1
        ");
        
        if ($hearing && $hearing->num_rows > 0) {
            $h = $hearing->fetch_assoc();
            return [
                'answer' => "Your next hearing is on " . date('F j, Y', strtotime($h['hearing_date'])) . " at {$h['hearing_time']} for Case #{$h['case_number']}.\n\nVenue: {$h['venue']}\n\nYou will receive a reminder 48 hours before the hearing.",
                'intent' => 'hearings'
            ];
        } else {
            return [
                'answer' => "You don't have any upcoming hearings scheduled at this time.",
                'intent' => 'hearings'
            ];
        }
    }
    return null;
}

// Main processing - Try all possible answer sources
$response = null;

// Try to get answer from FAQ first
$faq_answer = getFAQAnswer($conn, $question);
if ($faq_answer) {
    $response = $faq_answer;
}
// Then try case-specific
elseif ($case_answer = getCaseAnswer($conn, $user_id, $question)) {
    $response = $case_answer;
}
// Then try appointment
elseif ($appt_answer = getAppointmentAnswer($conn, $user_id, $question)) {
    $response = $appt_answer;
}
// Then try invoice
elseif ($invoice_answer = getInvoiceAnswer($conn, $user_id, $question)) {
    $response = $invoice_answer;
}
// Then try document
elseif ($doc_answer = getDocumentAnswer($conn, $user_id, $question)) {
    $response = $doc_answer;
}
// Then try lawyer contact
elseif ($lawyer_answer = getLawyerContactAnswer($conn, $user_id, $question)) {
    $response = $lawyer_answer;
}
// Then try fee structure
elseif ($fee_answer = getFeeAnswer($question)) {
    $response = $fee_answer;
}
// Then try hearing
elseif ($hearing_answer = getHearingAnswer($conn, $user_id, $question)) {
    $response = $hearing_answer;
}
// Default response
else {
    $response = [
        'answer' => "Thank you for your question. For specific legal advice regarding your case, please contact your assigned lawyer directly through the Message Board. You can also ask me about:\n\n• Case status and progress\n• Upcoming hearings\n• Document uploads\n• Billing and invoices\n• Appointment scheduling\n• Contacting your lawyer",
        'intent' => 'general'
    ];
}

// Save conversation to database
$stmt = $conn->prepare("INSERT INTO chatbot_conversations (user_id, session_id, question, answer, intent) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issss", $user_id, $session_id, $question, $response['answer'], $response['intent']);
$stmt->execute();

echo json_encode([
    'success' => true,
    'answer' => $response['answer'],
    'intent' => $response['intent'],
    'timestamp' => date('Y-m-d H:i:s')
]);
?>