<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'client') {
    header("Location: login.php");
    exit();
}

$page_title = "My Cases";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Client';

// Get all cases for the client
$cases = $conn->query("
    SELECT c.*, 
           u.full_name as lawyer_name,
           u.email as lawyer_email,
           u.phone as lawyer_phone,
           (SELECT COUNT(*) FROM hearings WHERE case_id = c.id AND hearing_date >= CURDATE()) as upcoming_hearings,
           (SELECT COUNT(*) FROM documents WHERE case_id = c.id AND is_shared = 1) as shared_documents,
           (SELECT COUNT(*) FROM messages WHERE to_user_id = $user_id AND is_read = 0) as unread_messages
    FROM cases c
    LEFT JOIN users u ON c.assigned_lawyer_id = u.id
    WHERE c.client_id = $user_id
    ORDER BY c.created_at DESC
");

// Check for query error
if (!$cases) {
    die("Query Error: " . $conn->error);
}

// Get case statistics
$stats = [];
$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE client_id = $user_id");
$stats['total_cases'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE client_id = $user_id AND status = 'active'");
$stats['active_cases'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM cases WHERE client_id = $user_id AND status = 'closed'");
$stats['closed_cases'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM hearings WHERE case_id IN (SELECT id FROM cases WHERE client_id = $user_id) AND hearing_date >= CURDATE()");
$stats['upcoming_hearings'] = $result->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>My Cases | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #D4AF37;
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: #D4AF37;
            margin-right: 5px;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 60px;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            background: linear-gradient(180deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            width: 250px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 20px 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .sidebar-logo-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #D4AF37;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .sidebar-logo-img:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .sidebar-logo h6 {
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 5px;
        }

        .sidebar-logo small {
            color: rgba(255,255,255,0.7);
            font-size: 11px;
        }

        .sidebar .nav-link {
            font-weight: 500;
            color: rgba(255,255,255,0.85);
            padding: 0.75rem 1rem;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: #D4AF37;
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            color: #4A0E17;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .page-container {
            margin-left: 250px;
            margin-top: 70px;
            padding: 30px 0 50px;
            background: #FDF8F0;
            min-height: 100vh;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-bottom: 3px solid transparent;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-bottom-color: #D4AF37;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }

        .stat-icon i {
            font-size: 24px;
            color: #4A0E17;
        }

        .case-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .case-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-left-color: #D4AF37;
        }

        .case-header {
            padding: 20px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
        }

        .case-number {
            font-size: 18px;
            font-weight: 700;
            color: #D4AF37;
            margin-bottom: 5px;
        }

        .case-title {
            font-size: 20px;
            font-weight: 600;
            color: #4A0E17;
            margin-bottom: 10px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-closed { background: #d1ecf1; color: #0c5460; }
        .status-archived { background: #e2e3e5; color: #383d41; }

        .case-body {
            padding: 20px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }

        .info-label {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
        }

        .info-value {
            font-size: 14px;
            color: #4A0E17;
            font-weight: 600;
        }

        .progress-section {
            margin: 15px 0;
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #718096;
            margin-bottom: 5px;
        }

        .progress-bar-custom {
            height: 8px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #D4AF37, #F5D76E);
            border-radius: 10px;
            transition: width 0.5s ease;
        }

        .case-footer {
            padding: 15px 20px;
            background: #FDF8F0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .btn-custom {
            padding: 8px 16px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
        }

        .btn-outline-custom {
            border: 1px solid #D4AF37;
            background: transparent;
            color: #4A0E17;
        }

        .btn-outline-custom:hover {
            background: #D4AF37;
            color: #4A0E17;
        }

        .lawyer-card {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            border-radius: 15px;
            padding: 15px;
            color: white;
            margin-top: 15px;
        }

        .lawyer-card .rounded-circle {
            background: rgba(212, 175, 55, 0.2) !important;
        }

        .lawyer-card i {
            color: #D4AF37 !important;
        }

        .badge-primary-custom {
            background: #D4AF37;
            color: #4A0E17;
            padding: 8px 15px;
            border-radius: 50px;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .page-container {
                margin-left: 0;
                padding: 15px;
                margin-top: 60px;
            }
            .case-footer {
                flex-direction: column;
                align-items: stretch;
            }
            .btn-custom {
                text-align: center;
            }
            .info-row {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-logo" href="index.php">
            <?php 
            $logo_path = 'assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
          
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="client_dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="position-sticky">
                <!-- Sidebar Logo -->
                <div class="sidebar-logo">
                    <?php 
                    if (file_exists($logo_path)): 
                    ?>
                        <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="sidebar-logo-img">
                    <?php else: ?>
                        <div style="width: 70px; height: 70px; border-radius: 50%; background: #D4AF37; margin: 0 auto; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-gavel" style="color: #4A0E17; font-size: 2rem;"></i>
                        </div>
                    <?php endif; ?>
                    <h6>Client Portal</h6>
                    <small><?php echo htmlspecialchars($user_name); ?></small>
                </div>
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="client_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="my_cases.php">
                            <i class="fas fa-briefcase"></i> My Cases
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../invoices.php">
                            <i class="fas fa-file-invoice-dollar"></i> Billing Portal
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../documents.php">
                            <i class="fas fa-folder-open"></i> Shared Documents
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../messages.php">
                            <i class="fas fa-comments"></i> Message Board
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="chatbot.php">
                            <i class="fas fa-robot"></i> AI Legal Assistant
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <hr style="border-color: rgba(212,175,55,0.3);">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-circle"></i> Profile Settings
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="page-container">
            <div class="container">
                <!-- Page Header -->
                <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                    <div>
                        <h1 class="display-5 fw-bold" style="color: #4A0E17;">My <span style="color: #D4AF37;">Cases</span></h1>
                        <p class="text-muted">Track and manage all your legal cases</p>
                    </div>
                    <div class="text-end">
                        <span class="badge-primary-custom">
                            <i class="fas fa-briefcase me-1"></i> Total Cases: <?php echo $stats['total_cases']; ?>
                        </span>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-briefcase"></i>
                            </div>
                            <h3 class="mb-0" style="color: #4A0E17;"><?php echo $stats['total_cases']; ?></h3>
                            <p class="text-muted mb-0">Total Cases</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-play-circle"></i>
                            </div>
                            <h3 class="mb-0" style="color: #4A0E17;"><?php echo $stats['active_cases']; ?></h3>
                            <p class="text-muted mb-0">Active Cases</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-gavel"></i>
                            </div>
                            <h3 class="mb-0" style="color: #4A0E17;"><?php echo $stats['upcoming_hearings']; ?></h3>
                            <p class="text-muted mb-0">Upcoming Hearings</p>
                        </div>
                    </div>
                </div>

                <!-- Cases List -->
                <?php if($cases && $cases->num_rows > 0): ?>
                    <?php while($case = $cases->fetch_assoc()): ?>
                        <div class="case-card">
                            <div class="case-header">
                                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                    <div>
                                        <div class="case-number">
                                            <i class="fas fa-hashtag"></i> <?php echo htmlspecialchars($case['case_number']); ?>
                                        </div>
                                        <div class="case-title">
                                            <?php echo htmlspecialchars($case['title']); ?>
                                        </div>
                                    </div>
                                    <div>
                                        <span class="status-badge status-<?php echo $case['status']; ?>">
                                            <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                            <?php echo ucfirst($case['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="case-body">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="info-row">
                                            <span class="info-label"><i class="fas fa-calendar-alt"></i> Filed On</span>
                                            <span class="info-value"><?php echo date('F d, Y', strtotime($case['created_at'])); ?></span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="fas fa-user-tie"></i> Assigned Lawyer</span>
                                            <span class="info-value">
                                                <?php if($case['lawyer_name']): ?>
                                                    <?php echo htmlspecialchars($case['lawyer_name']); ?>
                                                    <br><small class="text-muted"><?php echo htmlspecialchars($case['lawyer_email']); ?></small>
                                                <?php else: ?>
                                                    <span class="text-warning">Not yet assigned</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="fas fa-gavel"></i> Upcoming Hearings</span>
                                            <span class="info-value">
                                                <?php if($case['upcoming_hearings'] > 0): ?>
                                                    <span class="badge" style="background: #D4AF37; color: #4A0E17;"><?php echo $case['upcoming_hearings']; ?> scheduled</span>
                                                <?php else: ?>
                                                    <span class="text-muted">No upcoming hearings</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="fas fa-file-alt"></i> Shared Documents</span>
                                            <span class="info-value"><?php echo $case['shared_documents']; ?> documents</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="fas fa-envelope"></i> Unread Messages</span>
                                            <span class="info-value">
                                                <?php if($case['unread_messages'] > 0): ?>
                                                    <span class="badge" style="background: #C72A2A; color: white;"><?php echo $case['unread_messages']; ?> new</span>
                                                <?php else: ?>
                                                    <span class="text-muted">No new messages</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        
                                        <div class="progress-section">
                                            <div class="progress-label">
                                                <span>Case Progress</span>
                                                <span><?php echo $case['progress']; ?>%</span>
                                            </div>
                                            <div class="progress-bar-custom">
                                                <div class="progress-fill" style="width: <?php echo $case['progress']; ?>%"></div>
                                            </div>
                                        </div>
                                        
                                        <?php if($case['description']): ?>
                                            <div class="mt-3">
                                                <strong><i class="fas fa-align-left" style="color: #D4AF37;"></i> Description:</strong>
                                                <p class="text-muted small mt-1"><?php echo nl2br(htmlspecialchars(substr($case['description'], 0, 200))); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <?php if($case['lawyer_name']): ?>
                                            <div class="lawyer-card">
                                                <div class="d-flex align-items-center mb-3">
                                                    <div class="rounded-circle bg-white text-center me-3" style="width: 50px; height: 50px; line-height: 50px;">
                                                        <i class="fas fa-user-tie fa-2x"></i>
                                                    </div>
                                                    <div>
                                                        <h6 class="mb-0">Your Lawyer</h6>
                                                        <small><?php echo htmlspecialchars($case['lawyer_name']); ?></small>
                                                    </div>
                                                </div>
                                                <div class="small">
                                                    <div><i class="fas fa-envelope me-2"></i> <?php echo htmlspecialchars($case['lawyer_email']); ?></div>
                                                    <?php if($case['lawyer_phone']): ?>
                                                        <div class="mt-1"><i class="fas fa-phone me-2"></i> <?php echo htmlspecialchars($case['lawyer_phone']); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="case-footer">
                                <a href="../case_details.php?id=<?php echo $case['id']; ?>" class="btn btn-custom" style="background: #D4AF37; color: #4A0E17;">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                                <a href="../messages.php?user=<?php echo $case['assigned_lawyer_id']; ?>" class="btn btn-custom btn-outline-custom">
                                    <i class="fas fa-comment"></i> Message Lawyer
                                </a>
                                <a href="../documents.php?case_id=<?php echo $case['id']; ?>" class="btn btn-custom" style="border: 1px solid #cbd5e0; background: transparent; color: #4A0E17;">
                                    <i class="fas fa-folder-open"></i> View Documents
                                </a>
                                <a href="../hearings.php?case_id=<?php echo $case['id']; ?>" class="btn btn-custom" style="border: 1px solid #cbd5e0; background: transparent; color: #4A0E17;">
                                    <i class="fas fa-calendar"></i> View Hearings
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <div class="mb-4">
                            <i class="fas fa-folder-open fa-5x" style="color: #D4AF37; opacity: 0.5;"></i>
                        </div>
                        <h3 style="color: #4A0E17;">No Cases Found</h3>
                        <p class="text-muted">You don't have any cases registered yet.</p>
                        <a href="../contact.php" class="btn" style="background: #D4AF37; color: #4A0E17; border-radius: 50px; padding: 10px 30px; text-decoration: none;">
                            <i class="fas fa-phone-alt me-2"></i>Contact Us for Legal Help
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Mobile sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    let overlay = document.getElementById('overlay');
    
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '99';
        overlay.style.display = 'none';
        document.body.appendChild(overlay);
    }
    
    if (window.innerWidth <= 768) {
        const navbarBrand = document.querySelector('.navbar-logo');
        if (navbarBrand && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'btn btn-sm ms-2 mobile-menu-btn';
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.style.background = '#D4AF37';
            menuBtn.style.color = '#4A0E17';
            menuBtn.style.border = 'none';
            menuBtn.style.borderRadius = '8px';
            menuBtn.style.padding = '5px 10px';
            menuBtn.onclick = function() {
                sidebar.classList.toggle('show');
                overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
            };
            navbarBrand.parentElement.insertBefore(menuBtn, navbarBrand.nextSibling);
        }
    }
    
    if (sidebar && overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
    }
</script>

</body>
</html>