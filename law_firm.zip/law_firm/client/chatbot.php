<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "AI Legal Assistant";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'client';

// Get chat history for the user
$history = $conn->query("
    SELECT question, answer, created_at 
    FROM chatbot_conversations 
    WHERE user_id = $user_id 
    ORDER BY created_at DESC 
    LIMIT 20
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>AI Legal Assistant | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .navbar-logo-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #D4AF37;
        }

        .navbar-logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .navbar-logo-text i {
            color: #D4AF37;
            margin-right: 5px;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Page Container */
        .page-container {
            background: #FDF8F0;
            min-height: 100vh;
            padding: 30px 0;
            margin-top: 70px;
        }

        .chat-container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            display: flex;
            height: 85vh;
        }

        /* Sidebar */
        .chat-sidebar {
            width: 320px;
            background: linear-gradient(180deg, #4A0E17 0%, #6B1A2A 100%);
            color: white;
            display: flex;
            flex-direction: column;
        }

        .logo-area {
            padding: 30px;
            text-align: center;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .logo-icon {
            width: 70px;
            height: 70px;
            background: rgba(212, 175, 55, 0.2);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }

        .logo-icon i {
            font-size: 35px;
            color: #D4AF37;
        }

        .quick-actions {
            flex: 1;
            padding: 20px;
        }

        .quick-actions h6 {
            color: #D4AF37;
            font-weight: 600;
        }

        .quick-btn {
            width: 100%;
            background: rgba(212, 175, 55, 0.1);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 12px;
            margin-bottom: 10px;
            text-align: left;
            transition: all 0.3s;
        }

        .quick-btn:hover {
            background: rgba(212, 175, 55, 0.25);
            transform: translateX(5px);
        }

        .quick-btn i {
            color: #D4AF37;
        }

        /* Chat Area */
        .chat-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #FDF8F0;
        }

        .chat-header {
            padding: 20px 30px;
            background: white;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .chat-header h2 {
            font-size: 22px;
            font-weight: 700;
            margin: 0;
            color: #4A0E17;
        }

        .chat-header h2 i {
            color: #D4AF37;
        }

        .chat-header p {
            font-size: 13px;
            color: #718096;
            margin: 5px 0 0;
        }

        .messages-area {
            flex: 1;
            overflow-y: auto;
            padding: 30px;
        }

        .message {
            display: flex;
            margin-bottom: 20px;
            animation: fadeInUp 0.3s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.user {
            justify-content: flex-end;
        }

        .message.bot {
            justify-content: flex-start;
        }

        .message-content {
            max-width: 70%;
            padding: 12px 20px;
            border-radius: 20px;
            position: relative;
        }

        .message.user .message-content {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            color: #4A0E17;
            border-bottom-right-radius: 5px;
        }

        .message.bot .message-content {
            background: white;
            color: #2d3748;
            border-bottom-left-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
        }

        .message.user .message-content i {
            color: #4A0E17;
        }

        .message.bot .message-content i {
            color: #D4AF37;
        }

        .message-time {
            font-size: 10px;
            margin-top: 5px;
            opacity: 0.7;
        }

        .typing-indicator {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 12px 20px;
            background: white;
            border-radius: 20px;
            width: fit-content;
            border: 1px solid rgba(212, 175, 55, 0.2);
        }

        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #D4AF37;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }

        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }

        .input-area {
            padding: 20px 30px;
            background: white;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
        }

        .input-group-custom {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .input-group-custom textarea {
            flex: 1;
            border: 2px solid #e2e8f0;
            border-radius: 20px;
            padding: 12px 20px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            resize: none;
            transition: all 0.3s;
        }

        .input-group-custom textarea:focus {
            outline: none;
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }

        .send-btn {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            color: #4A0E17;
            transition: all 0.3s;
        }

        .send-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .suggestion-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 15px;
        }

        .suggestion-chip {
            background: #f1f3f5;
            border: none;
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .suggestion-chip:hover {
            background: #D4AF37;
            color: #4A0E17;
            transform: translateY(-2px);
        }

        /* Scrollbar */
        .messages-area::-webkit-scrollbar {
            width: 6px;
        }

        .messages-area::-webkit-scrollbar-track {
            background: #e2e8f0;
            border-radius: 3px;
        }

        .messages-area::-webkit-scrollbar-thumb {
            background: #D4AF37;
            border-radius: 3px;
        }

        @media (max-width: 768px) {
            .chat-sidebar {
                display: none;
            }
            
            .message-content {
                max-width: 85%;
            }
            
            .chat-container {
                margin: 10px;
                height: 90vh;
            }
            
            .chat-header {
                padding: 15px 20px;
            }
            
            .messages-area {
                padding: 15px;
            }
            
            .input-area {
                padding: 15px 20px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-logo" href="index.php">
            <?php 
            $logo_path = 'assets/logo.jpeg';
            if (file_exists($logo_path)): 
            ?>
                <img src="<?php echo $logo_path; ?>" alt="Sisodiya Associates Logo" class="navbar-logo-img">
            
            <?php endif; ?>
            <span class="navbar-logo-text"></i>Sisodiya Associates</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="my_cases.php"><i class="fas fa-briefcase me-1"></i> My Cases</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="page-container">
    <div class="container-fluid">
        <div class="chat-container">
            <!-- Sidebar -->
            <div class="chat-sidebar">
                <div class="logo-area">
                    <div class="logo-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h4 class="mb-1">AI Legal Assistant</h4>
                    <small class="opacity-75">Powered by Advanced AI</small>
                </div>
                
                <div class="quick-actions">
                    <h6 class="mb-3"><i class="fas fa-bolt me-2"></i> Quick Questions</h6>
                    <button class="quick-btn" onclick="askQuickQuestion('How do I check my case status?')">
                        <i class="fas fa-chart-line me-2"></i> Case Status
                    </button>
                    <button class="quick-btn" onclick="askQuickQuestion('How can I contact my lawyer?')">
                        <i class="fas fa-envelope me-2"></i> Contact Lawyer
                    </button>
                    <button class="quick-btn" onclick="askQuickQuestion('What documents do I need to upload?')">
                        <i class="fas fa-file-alt me-2"></i> Required Documents
                    </button>
                    <button class="quick-btn" onclick="askQuickQuestion('How are legal fees calculated?')">
                        <i class="fas fa-rupee-sign me-2"></i> Fee Structure
                    </button>
                    <button class="quick-btn" onclick="askQuickQuestion('When is my next hearing?')">
                        <i class="fas fa-gavel me-2"></i> Next Hearing
                    </button>
                    <button class="quick-btn" onclick="askQuickQuestion('How to schedule an appointment?')">
                        <i class="fas fa-calendar-check me-2"></i> Book Appointment
                    </button>
                </div>
                
                <div class="p-3 border-top" style="border-color: rgba(212, 175, 55, 0.2) !important;">
                    <small class="d-block mb-2">
                        <i class="fas fa-shield-alt me-1" style="color: #D4AF37;"></i> Secure & Confidential
                    </small>
                    <small class="opacity-75">Responses are for informational purposes only. For legal advice, consult your attorney.</small>
                </div>
            </div>

            <!-- Main Chat Area -->
            <div class="chat-main">
                <div class="chat-header">
                    <h2><i class="fas fa-comment-dots me-2"></i> Legal Assistant</h2>
                    <p>Ask me anything about your case, legal procedures, documents, or billing</p>
                </div>

                <div class="messages-area" id="messagesArea">
                    <div class="message bot">
                        <div class="message-content">
                            <i class="fas fa-robot me-2"></i>
                            Hello! I'm your AI Legal Assistant. I can help you with:
                            <ul class="mt-2 mb-0">
                                <li>Checking your case status and updates</li>
                                <li>Finding information about hearings</li>
                                <li>Document requirements and uploads</li>
                                <li>Fee structure and billing inquiries</li>
                                <li>Appointment scheduling</li>
                            </ul>
                            <div class="message-time"><?php echo date('g:i A'); ?></div>
                        </div>
                    </div>

                    <?php 
                    if ($history && $history->num_rows > 0) {
                        $history_arr = array_reverse(iterator_to_array($history));
                        foreach($history_arr as $msg): 
                    ?>
                        <div class="message user">
                            <div class="message-content">
                                <?php echo htmlspecialchars($msg['question']); ?>
                                <div class="message-time"><?php echo date('g:i A', strtotime($msg['created_at'])); ?></div>
                            </div>
                        </div>
                        <div class="message bot">
                            <div class="message-content">
                                <i class="fas fa-robot me-1"></i>
                                <?php echo nl2br(htmlspecialchars($msg['answer'])); ?>
                                <div class="message-time"><?php echo date('g:i A', strtotime($msg['created_at'])); ?></div>
                            </div>
                        </div>
                    <?php 
                        endforeach;
                    } 
                    ?>
                </div>

                <div class="input-area">
                    <div class="input-group-custom">
                        <textarea id="questionInput" rows="2" placeholder="Type your legal question here... (e.g., 'How do I check my case status?')"></textarea>
                        <button class="send-btn" onclick="sendMessage()">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                    <div class="suggestion-chips">
                        <button class="suggestion-chip" onclick="askQuickQuestion('What is the status of my case?')">📋 Case status</button>
                        <button class="suggestion-chip" onclick="askQuickQuestion('How to upload documents?')">📄 Upload documents</button>
                        <button class="suggestion-chip" onclick="askQuickQuestion('When is my next hearing?')">⚖️ Next hearing</button>
                        <button class="suggestion-chip" onclick="askQuickQuestion('How to pay my invoice?')">💰 Pay invoice</button>
                        <button class="suggestion-chip" onclick="askQuickQuestion('Contact my lawyer')">📞 Contact lawyer</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const messagesArea = document.getElementById('messagesArea');
    const questionInput = document.getElementById('questionInput');
    let sessionId = '<?php echo session_id(); ?>';
    
    // Auto-scroll to bottom
    function scrollToBottom() {
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }
    scrollToBottom();
    
    // Send message on Enter (Shift+Enter for new line)
    questionInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    function askQuickQuestion(question) {
        questionInput.value = question;
        sendMessage();
    }
    
    function sendMessage() {
        const question = questionInput.value.trim();
        if (!question) return;
        
        // Add user message to chat
        addMessage(question, 'user');
        questionInput.value = '';
        
        // Show typing indicator
        showTypingIndicator();
        
        // Send to backend
        fetch('chatbot_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                session_id: sessionId
            })
        })
        .then(response => response.json())
        .then(data => {
            removeTypingIndicator();
            if (data.success) {
                addMessage(data.answer, 'bot');
            } else {
                addMessage("I'm having trouble connecting. Please try again or contact support.", 'bot');
            }
        })
        .catch(error => {
            removeTypingIndicator();
            addMessage("Sorry, I encountered an error. Please try again.", 'bot');
            console.error('Error:', error);
        });
    }
    
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageDiv.innerHTML = `
            <div class="message-content">
                ${sender === 'bot' ? '<i class="fas fa-robot me-1"></i> ' : ''}
                ${text.replace(/\n/g, '<br>')}
                <div class="message-time">${time}</div>
            </div>
        `;
        
        messagesArea.appendChild(messageDiv);
        scrollToBottom();
    }
    
    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
                <span class="ms-2" style="font-size: 12px;">AI is thinking...</span>
            </div>
        `;
        messagesArea.appendChild(typingDiv);
        scrollToBottom();
    }
    
    function removeTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) indicator.remove();
    }
    
    // Auto-resize textarea
    questionInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });
</script>

</body>
</html>