<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'client') {
    header("Location: login.php");
    exit();
}

$page_title = "Client Dashboard";
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Client';

// Get client's cases with progress
$cases = $conn->query("SELECT c.*, u.full_name as lawyer_name, 
                       (SELECT COUNT(*) FROM hearings WHERE case_id = c.id AND hearing_date >= CURDATE()) as upcoming_hearings
                       FROM cases c 
                       LEFT JOIN users u ON c.assigned_lawyer_id = u.id 
                       WHERE c.client_id = $user_id 
                       ORDER BY c.created_at DESC");

// Get upcoming hearing with countdown
$next_hearing = $conn->query("SELECT h.*, c.case_number, c.title 
                              FROM hearings h 
                              JOIN cases c ON h.case_id = c.id 
                              WHERE c.client_id = $user_id AND h.hearing_date >= CURDATE() 
                              ORDER BY h.hearing_date LIMIT 1")->fetch_assoc();

// Get unpaid invoices
$invoices = $conn->query("SELECT * FROM invoices WHERE client_id = $user_id AND status != 'paid' ORDER BY due_date ASC");

// Get all invoices for payment summary
$all_invoices = $conn->query("SELECT * FROM invoices WHERE client_id = $user_id");

// Get payment summary
$payment_summary = $conn->query("
    SELECT 
        COALESCE(SUM(amount), 0) as total_billed,
        COALESCE(SUM(paid_amount), 0) as total_paid,
        COALESCE(SUM(amount) - SUM(paid_amount), 0) as total_due,
        COUNT(*) as invoice_count,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count
    FROM invoices 
    WHERE client_id = $user_id
");
$ps = $payment_summary->fetch_assoc();

// Get payment history
$payment_history = $conn->query("
    SELECT p.*, i.invoice_number, c.case_number
    FROM payments p
    JOIN invoices i ON p.invoice_id = i.id
    LEFT JOIN cases c ON p.case_id = c.id
    WHERE p.client_id = $user_id
    ORDER BY p.payment_date DESC
    LIMIT 10
");

// Get shared documents
$documents = $conn->query("SELECT d.*, c.case_number 
                          FROM documents d 
                          JOIN cases c ON d.case_id = c.id 
                          WHERE c.client_id = $user_id AND d.is_shared = 1 
                          ORDER BY d.uploaded_at DESC LIMIT 5");

// Get unread messages
$unread_messages = $conn->query("SELECT COUNT(*) as total FROM messages WHERE to_user_id = $user_id AND is_read = 0")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Client Dashboard | Sisodiya Associates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: #D4AF37;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, #4A0E17 0%, #6B1A2A 100%);
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 60px;
            left: 0;
            width: 250px;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255,255,255,0.85) !important;
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 12px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar .nav-link:hover {
            background: rgba(212, 175, 55, 0.15);
            color: #D4AF37 !important;
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            color: #4A0E17 !important;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .sidebar .nav-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            margin-top: 70px;
            padding: 20px 30px;
            min-height: 100vh;
        }

        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-bottom: 3px solid transparent;
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-bottom-color: #D4AF37;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }

        .stat-icon i {
            font-size: 24px;
            color: #4A0E17;
        }

        .stat-number {
            font-size: 28px;
            font-weight: 800;
            color: #4A0E17;
        }

        /* Case Cards */
        .case-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .case-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            border-left-color: #D4AF37;
        }

        .case-header {
            padding: 20px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
        }

        .case-number {
            font-size: 18px;
            font-weight: 700;
            color: #D4AF37;
            margin-bottom: 5px;
        }

        .case-title {
            font-size: 20px;
            font-weight: 600;
            color: #4A0E17;
            margin-bottom: 10px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-closed { background: #d1ecf1; color: #0c5460; }
        .status-archived { background: #e2e3e5; color: #383d41; }

        .case-body {
            padding: 20px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }

        .info-label {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
        }

        .info-value {
            font-size: 14px;
            color: #4A0E17;
            font-weight: 600;
        }

        .progress-section {
            margin: 15px 0;
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #718096;
            margin-bottom: 5px;
        }

        .progress-bar-custom {
            height: 8px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #D4AF37, #F5D76E);
            border-radius: 10px;
            transition: width 0.5s ease;
        }

        .case-footer {
            padding: 15px 20px;
            background: #FDF8F0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .btn-custom {
            padding: 8px 16px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
        }

        .btn-outline-custom {
            border: 1px solid #D4AF37;
            background: transparent;
            color: #4A0E17;
        }

        .btn-outline-custom:hover {
            background: #D4AF37;
            color: #4A0E17;
        }

        /* Payment Cards */
        .payment-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .payment-card:hover {
            transform: translateY(-3px);
            border-left-color: #D4AF37;
        }

        .payment-progress {
            height: 8px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .payment-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 10px;
            transition: width 0.5s ease;
        }

        /* Payment History Table */
        .payment-table {
            width: 100%;
        }

        .payment-table thead th {
            background: #4A0E17;
            color: white;
            font-weight: 600;
            padding: 12px;
            border: none;
        }

        .payment-table tbody tr {
            border-bottom: 1px solid rgba(212, 175, 55, 0.1);
        }

        .payment-table tbody td {
            padding: 12px;
            color: #4A0E17;
        }

        /* AI Assistant Card */
        .ai-assistant-card {
            background: linear-gradient(135deg, #D4AF37 0%, #F5D76E 100%);
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .ai-assistant-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
        }
        
        .ai-assistant-card .card-body {
            color: #4A0E17;
            text-align: center;
        }
        
        .ai-icon {
            width: 60px;
            height: 60px;
            background: rgba(74, 14, 23, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            transition: all 0.3s;
        }
        
        .ai-assistant-card:hover .ai-icon {
            transform: scale(1.1);
            background: rgba(74, 14, 23, 0.3);
        }
        
        .ai-icon i {
            font-size: 30px;
            color: #4A0E17;
        }
        
        .online-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            background: #4cd964;
            border-radius: 50%;
            margin-left: 8px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* Quick Tips Card */
        .quick-tips-card {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            border: none;
        }

        .quick-tips-card .card-header {
            background: rgba(255,255,255,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }

        /* Card Headers */
        .card-header {
            background: white;
            border-bottom: 2px solid rgba(212, 175, 55, 0.2);
        }

        .card-header h5 {
            color: #4A0E17;
            font-weight: 600;
        }

        /* Invoice Alert */
        .invoice-alert {
            border-radius: 12px;
            padding: 12px 15px;
            margin-bottom: 12px;
        }

        .invoice-alert-pending {
            background: #fff3cd;
            border-left: 4px solid #f59e0b;
        }

        .invoice-alert-overdue {
            background: #f8d7da;
            border-left: 4px solid #ef4444;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .case-footer {
                flex-direction: column;
                align-items: stretch;
            }
            .btn-custom {
                text-align: center;
            }
            .info-row {
                flex-direction: column;
                gap: 5px;
            }
            .payment-table thead {
                display: none;
            }
            .payment-table tbody tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid rgba(212, 175, 55, 0.2);
                border-radius: 12px;
            }
            .payment-table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
            }
            .payment-table tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                color: #4A0E17;
                margin-right: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Dashboard Content -->
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-md-block sidebar">
            <div class="position-sticky pt-3">
                <div class="text-center mb-4 pb-2 border-bottom" style="border-color: rgba(212,175,55,0.3) !important;">
                    <div class="logo-icon-small mb-2" style="width: 50px; height: 50px; background: #D4AF37; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fas fa-gavel" style="color: #4A0E17; font-size: 1.5rem;"></i>
                    </div>
                    <h6 class="text-white mb-0">Client Portal</h6>
                    <small class="text-white-50">Welcome, <?php echo htmlspecialchars($user_name); ?></small>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_cases.php">
                            <i class="fas fa-briefcase"></i> My Cases
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../invoices.php">
                            <i class="fas fa-file-invoice-dollar"></i> Billing Portal
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../documents.php">
                            <i class="fas fa-folder-open"></i> Shared Documents
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../messages.php">
                            <i class="fas fa-comments"></i> Message Board
                            <?php if($unread_messages > 0): ?>
                                <span class="badge float-end" style="background: #D4AF37; color: #4A0E17;"><?php echo $unread_messages; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="chatbot.php">
                            <i class="fas fa-robot"></i> AI Legal Assistant
                        </a>
                    </li>
                    
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-10 ms-sm-auto px-md-4 main-content">
            <div class="pt-3 pb-2 mb-3">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div>
                        <h1 class="h2" style="color: #4A0E17;">Welcome, <?php echo htmlspecialchars($user_name); ?></h1>
                        <p class="text-muted">Track your cases and communicate with your legal team</p>
                    </div>
                    <div>
                        <span class="badge" style="background: #D4AF37; color: #4A0E17; padding: 8px 15px;">
                            <i class="fas fa-gavel"></i> Client Portal
                        </span>
                    </div>
                </div>
            </div>

            <!-- Hearing Alert with Countdown -->
            <?php if($next_hearing): ?>
                <div class="alert alert-warning alert-dismissible fade show" style="background: #fff3cd; border-left: 4px solid #D4AF37; border-radius: 15px;" role="alert">
                    <strong><i class="fas fa-gavel" style="color: #D4AF37;"></i> Upcoming Court Appearance!</strong>
                    <div id="countdown-timer" class="mt-2"></div>
                    <hr>
                    <strong>Case:</strong> <?php echo htmlspecialchars($next_hearing['case_number']); ?> - <?php echo htmlspecialchars($next_hearing['title']); ?><br>
                    <strong>Date:</strong> <?php echo date('F j, Y', strtotime($next_hearing['hearing_date'])); ?> at <?php echo $next_hearing['hearing_time']; ?><br>
                    <strong>Venue:</strong> <?php echo htmlspecialchars($next_hearing['venue']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- My Cases Status with Progress Bars -->
                <div class="col-lg-7">
                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fas fa-briefcase"></i>
                                </div>
                                <div class="stat-number"><?php echo $cases->num_rows; ?></div>
                                <p class="text-muted mb-0">Total Cases</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fas fa-gavel"></i>
                                </div>
                                <div class="stat-number"><?php echo $next_hearing ? '1' : '0'; ?></div>
                                <p class="text-muted mb-0">Upcoming Hearing</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fas fa-file-alt"></i>
                                </div>
                                <div class="stat-number"><?php echo $documents->num_rows; ?></div>
                                <p class="text-muted mb-0">Shared Docs</p>
                            </div>
                        </div>
                    </div>

                    <!-- My Cases -->
                    <div class="card">
                        <div class="card-header bg-white">
                            <h5><i class="fas fa-chart-line" style="color: #D4AF37;"></i> My Cases Status</h5>
                        </div>
                        <div class="card-body">
                            <?php if($cases->num_rows > 0): ?>
                                <?php while($case = $cases->fetch_assoc()): ?>
                                    <div class="case-card">
                                        <div class="case-header">
                                            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                                <div>
                                                    <div class="case-number">
                                                        <i class="fas fa-hashtag"></i> <?php echo htmlspecialchars($case['case_number']); ?>
                                                    </div>
                                                    <div class="case-title">
                                                        <?php echo htmlspecialchars($case['title']); ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <span class="status-badge status-<?php echo $case['status']; ?>">
                                                        <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                                        <?php echo ucfirst($case['status']); ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="case-body">
                                            <div class="info-row">
                                                <span class="info-label"><i class="fas fa-calendar-alt"></i> Filed On</span>
                                                <span class="info-value"><?php echo date('F d, Y', strtotime($case['created_at'])); ?></span>
                                            </div>
                                            <div class="info-row">
                                                <span class="info-label"><i class="fas fa-user-tie"></i> Assigned Lawyer</span>
                                                <span class="info-value">
                                                    <?php if($case['lawyer_name']): ?>
                                                        <?php echo htmlspecialchars($case['lawyer_name']); ?>
                                                    <?php else: ?>
                                                        <span class="text-warning">Not yet assigned</span>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            <div class="info-row">
                                                <span class="info-label"><i class="fas fa-gavel"></i> Upcoming Hearings</span>
                                                <span class="info-value">
                                                    <?php if($case['upcoming_hearings'] > 0): ?>
                                                        <span class="badge" style="background: #D4AF37; color: #4A0E17;"><?php echo $case['upcoming_hearings']; ?> scheduled</span>
                                                    <?php else: ?>
                                                        <span class="text-muted">No upcoming hearings</span>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            
                                            <!-- Progress Bar -->
                                            <div class="progress-section">
                                                <div class="progress-label">
                                                    <span>Case Progress</span>
                                                    <span><?php echo $case['progress']; ?>%</span>
                                                </div>
                                                <div class="progress-bar-custom">
                                                    <div class="progress-fill" style="width: <?php echo $case['progress']; ?>%"></div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="case-footer">
                                            <a href="../case_details.php?id=<?php echo $case['id']; ?>" class="btn btn-sm btn-custom" style="background: #D4AF37; color: #4A0E17;">
                                                <i class="fas fa-eye"></i> View Details
                                            </a>
                                            <?php if($case['assigned_lawyer_id']): ?>
                                                <a href="../messages.php?user=<?php echo $case['assigned_lawyer_id']; ?>" class="btn btn-sm btn-outline-custom">
                                                    <i class="fas fa-comment"></i> Message Lawyer
                                                </a>
                                            <?php endif; ?>
                                            <a href="../documents.php?case_id=<?php echo $case['id']; ?>" class="btn btn-sm btn-custom" style="border: 1px solid #cbd5e0; background: transparent; color: #4A0E17;">
                                                <i class="fas fa-folder-open"></i> View Documents
                                            </a>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-muted text-center py-4">No cases assigned yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Shared Documents -->
                    <div class="card mt-4">
                        <div class="card-header bg-white">
                            <h5><i class="fas fa-folder-open" style="color: #D4AF37;"></i> Shared Documents</h5>
                        </div>
                        <div class="card-body">
                            <?php if($documents->num_rows > 0): ?>
                                <div class="list-group">
                                    <?php while($doc = $documents->fetch_assoc()): ?>
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <div>
                                                <i class="fas fa-file-pdf text-danger"></i>
                                                <strong><?php echo htmlspecialchars($doc['file_name']); ?></strong>
                                                <br>
                                                <small class="text-muted">Case: <?php echo htmlspecialchars($doc['case_number']); ?></small>
                                            </div>
                                            <a href="<?php echo $doc['file_path']; ?>" download class="btn btn-sm" style="background: #D4AF37; color: #4A0E17;">
                                                <i class="fas fa-download"></i> Download
                                            </a>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center py-4">No shared documents yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <!-- Billing Portal Summary with Payment Tracking -->
                    <div class="card">
                        <div class="card-header bg-white">
                            <h5><i class="fas fa-file-invoice-dollar" style="color: #D4AF37;"></i> Billing Summary</h5>
                        </div>
                        <div class="card-body">
                            <!-- Payment Progress -->
                            <div class="mb-3">
                                <div class="d-flex justify-content-between small mb-1">
                                    <span>Payment Progress</span>
                                    <span><?php echo $ps['total_billed'] > 0 ? round(($ps['total_paid'] / $ps['total_billed']) * 100, 1) : 0; ?>% Paid</span>
                                </div>
                                <div class="payment-progress">
                                    <div class="payment-progress-fill" style="width: <?php echo $ps['total_billed'] > 0 ? ($ps['total_paid'] / $ps['total_billed']) * 100 : 0; ?>%"></div>
                                </div>
                            </div>
                            
                            <div class="row text-center mb-3">
                                <div class="col-4">
                                    <small class="text-muted">Total Billed</small>
                                    <h6 class="mb-0">₹<?php echo number_format($ps['total_billed'], 2); ?></h6>
                                </div>
                                <div class="col-4">
                                    <small class="text-muted">Paid</small>
                                    <h6 class="mb-0 text-success">₹<?php echo number_format($ps['total_paid'], 2); ?></h6>
                                </div>
                                <div class="col-4">
                                    <small class="text-muted">Due</small>
                                    <h6 class="mb-0 text-danger">₹<?php echo number_format($ps['total_due'], 2); ?></h6>
                                </div>
                            </div>
                            
                            <?php if($invoices->num_rows > 0): ?>
                                <?php while($invoice = $invoices->fetch_assoc()): ?>
                                    <div class="invoice-alert <?php echo $invoice['status'] == 'overdue' ? 'invoice-alert-overdue' : 'invoice-alert-pending'; ?>">
                                        <div class="d-flex justify-content-between align-items-center flex-wrap">
                                            <div>
                                                <strong>Invoice #<?php echo $invoice['invoice_number']; ?></strong><br>
                                                Amount: ₹<?php echo number_format($invoice['amount'], 2); ?><br>
                                                Paid: ₹<?php echo number_format($invoice['paid_amount'] ?? 0, 2); ?><br>
                                                Due Date: <?php echo date('M d, Y', strtotime($invoice['due_date'])); ?>
                                            </div>
                                            <a href="../get_invoice.php?id=<?php echo $invoice['id']; ?>" target="_blank" class="btn btn-sm mt-2 mt-sm-0" style="background: #D4AF37; color: #4A0E17;">
                                                <i class="fas fa-download"></i> Download
                                            </a>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-muted text-center py-3">No pending invoices.</p>
                            <?php endif; ?>
                            
                            <a href="../invoices.php" class="btn w-100 mt-2" style="border: 1px solid #D4AF37; color: #4A0E17;">
                                <i class="fas fa-history me-2"></i> View Payment History
                            </a>
                        </div>
                    </div>

                    <!-- Payment History -->
                    <?php if($payment_history && $payment_history->num_rows > 0): ?>
                        <div class="card mt-4">
                            <div class="card-header bg-white">
                                <h5><i class="fas fa-history" style="color: #D4AF37;"></i> Recent Payments</h5>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="payment-table table">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Invoice</th>
                                                <th>Amount</th>
                                                <th>Method</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($payment = $payment_history->fetch_assoc()): ?>
                                                <tr>
                                                    <td data-label="Date"><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                                    <td data-label="Invoice"><?php echo $payment['invoice_number']; ?></td>
                                                    <td data-label="Amount" class="text-success">₹<?php echo number_format($payment['amount'], 2); ?></td>
                                                    <td data-label="Method"><?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Message Board -->
                    <div class="card mt-4">
                        <div class="card-header bg-white">
                            <h5><i class="fas fa-comments" style="color: #D4AF37;"></i> Quick Message</h5>
                        </div>
                        <div class="card-body">
                            <form action="../send_message.php" method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Send to</label>
                                    <select class="form-select" name="to_user_id" required>
                                        <option value="">Select recipient...</option>
                                        <?php
                                        $recipients = $conn->query("SELECT id, full_name, role FROM users WHERE role IN ('lawyer', 'paralegal') AND is_active = 1");
                                        while($recipient = $recipients->fetch_assoc()):
                                        ?>
                                            <option value="<?php echo $recipient['id']; ?>">
                                                <?php echo htmlspecialchars($recipient['full_name']); ?> (<?php echo ucfirst($recipient['role']); ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <textarea class="form-control" name="message" rows="3" placeholder="Type your message here..." required></textarea>
                                </div>
                                <button type="submit" class="btn w-100" style="background: #D4AF37; color: #4A0E17;">Send Message</button>
                            </form>
                        </div>
                    </div>

                    <!-- AI Legal Assistant Card -->
                    <div class="card mt-4 ai-assistant-card" onclick="window.location.href='chatbot.php'">
                        <div class="card-body">
                            <div class="ai-icon">
                                <i class="fas fa-robot"></i>
                            </div>
                            <h5 class="mb-2">
                                AI Legal Assistant 
                                <span class="online-indicator"></span>
                            </h5>
                            <p class="small mb-2">24/7 Available | Instant Responses</p>
                            <p class="mb-3">Ask me about your case status, documents, hearings, or billing!</p>
                            <div class="d-flex justify-content-center gap-2">
                                <span class="badge" style="background: rgba(74,14,23,0.2); color: #4A0E17;">Case Status</span>
                                <span class="badge" style="background: rgba(74,14,23,0.2); color: #4A0E17;">Documents</span>
                                <span class="badge" style="background: rgba(74,14,23,0.2); color: #4A0E17;">Hearings</span>
                                <span class="badge" style="background: rgba(74,14,23,0.2); color: #4A0E17;">Billing</span>
                            </div>
                            <hr class="my-3" style="background: rgba(74,14,23,0.2);">
                            <div class="d-flex justify-content-between align-items-center">
                                <small><i class="fas fa-comment-dots"></i> Start a conversation</small>
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Tips Card -->
                    <div class="card mt-4 quick-tips-card text-white">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-lightbulb"></i> Quick Tips</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #D4AF37;"></i> Check your case progress regularly</li>
                                <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #D4AF37;"></i> Upload documents as soon as possible</li>
                                <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #D4AF37;"></i> Respond to lawyer messages promptly</li>
                                <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #D4AF37;"></i> Keep your contact info updated</li>
                                <li><i class="fas fa-check-circle me-2" style="color: #D4AF37;"></i> Use AI Assistant for quick questions</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Countdown timer for next hearing
    <?php if($next_hearing): ?>
    function updateCountdown() {
        const hearingDate = new Date('<?php echo $next_hearing['hearing_date'] . ' ' . $next_hearing['hearing_time']; ?>').getTime();
        const now = new Date().getTime();
        const distance = hearingDate - now;
        
        if(distance < 0) {
            document.getElementById('countdown-timer').innerHTML = "Hearing has passed";
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('countdown-timer').innerHTML = 
            `<strong>Time until hearing:</strong> ${days}d ${hours}h ${minutes}m ${seconds}s`;
    }
    
    setInterval(updateCountdown, 1000);
    updateCountdown();
    <?php endif; ?>
</script>

</body>
</html>