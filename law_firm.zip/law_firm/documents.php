<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Document Management";
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$user_name = $_SESSION['user_name'] ?? 'User';

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['document'])) {
    $case_id = $_POST['case_id'];
    $is_shared = isset($_POST['is_shared']) ? 1 : 0;
    
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_name = time() . '_' . basename($_FILES["document"]["name"]);
    $target_file = $target_dir . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $file_size = $_FILES["document"]["size"];
    
    if (move_uploaded_file($_FILES["document"]["tmp_name"], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO documents (case_id, uploaded_by, file_name, file_path, file_type, file_size, is_shared) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissiii", $case_id, $user_id, $file_name, $target_file, $file_type, $file_size, $is_shared);
        $stmt->execute();
        $upload_success = "Document uploaded successfully!";
    } else {
        $upload_error = "Error uploading file.";
    }
}

// Handle file deletion
if (isset($_GET['delete'])) {
    $doc_id = $_GET['delete'];
    $result = $conn->query("SELECT file_path FROM documents WHERE id = $doc_id");
    $doc = $result->fetch_assoc();
    
    if ($doc && unlink($doc['file_path'])) {
        $conn->query("DELETE FROM documents WHERE id = $doc_id");
        $delete_success = "Document deleted successfully!";
    }
}

// Get documents based on role
switch($user_role) {
    case 'client':
        $docs_query = "SELECT d.*, c.case_number, u.full_name as uploaded_by_name 
                      FROM documents d 
                      JOIN cases c ON d.case_id = c.id 
                      JOIN users u ON d.uploaded_by = u.id 
                      WHERE c.client_id = $user_id AND (d.is_shared = 1 OR d.uploaded_by = $user_id)
                      ORDER BY d.uploaded_at DESC";
        break;
    default:
        $docs_query = "SELECT d.*, c.case_number, u.full_name as uploaded_by_name 
                      FROM documents d 
                      JOIN cases c ON d.case_id = c.id 
                      JOIN users u ON d.uploaded_by = u.id 
                      ORDER BY d.uploaded_at DESC";
}
$documents = $conn->query($docs_query);

// Get cases for dropdown
$cases_query = "SELECT id, case_number, title FROM cases";
if($user_role == 'lawyer') {
    $cases_query .= " WHERE assigned_lawyer_id = $user_id";
} elseif($user_role == 'client') {
    $cases_query .= " WHERE client_id = $user_id";
}
$cases = $conn->query($cases_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Document Management | ABT Law Firm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #FDF8F0;
        }

        /* Navbar */
        .navbar-main {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar-main .navbar-brand {
            color: white !important;
            font-weight: 700;
        }

        .navbar-main .navbar-brand i {
            color: #D4AF37;
        }

        .navbar-main .nav-link {
            color: rgba(255,255,255,0.85) !important;
            transition: all 0.3s;
        }

        .navbar-main .nav-link:hover {
            color: #D4AF37 !important;
        }

        /* Page Container */
        .page-container {
            background: #FDF8F0;
            min-height: 100vh;
            padding: 30px 0 50px;
            margin-top: 70px;
        }

        .upload-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .upload-card .card-header {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            color: white;
            border: none;
            padding: 15px 20px;
        }

        .upload-card .card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .upload-card .card-header i {
            color: #D4AF37;
            margin-right: 8px;
        }

        .library-card {
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .library-card .card-header {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            color: white;
            border: none;
            padding: 15px 20px;
        }

        .library-card .card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .library-card .card-header i {
            color: #D4AF37;
            margin-right: 8px;
        }

        .form-label {
            color: #4A0E17;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 10px 15px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }

        .btn-upload {
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            padding: 12px;
            border-radius: 12px;
            color: #4A0E17;
            font-weight: 700;
            transition: all 0.3s;
        }

        .btn-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: #4A0E17;
        }

        .btn-download {
            background: #D4AF37;
            border: none;
            padding: 5px 10px;
            border-radius: 8px;
            color: #4A0E17;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-download:hover {
            background: #F5D76E;
            transform: translateY(-2px);
            color: #4A0E17;
        }

        .btn-delete {
            background: #C72A2A;
            border: none;
            padding: 5px 10px;
            border-radius: 8px;
            color: white;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-delete:hover {
            background: #8B2635;
            transform: translateY(-2px);
            color: white;
        }

        .badge-file {
            background: rgba(212, 175, 55, 0.15);
            color: #D4AF37;
            padding: 4px 10px;
            border-radius: 50px;
            font-weight: 600;
        }

        .shared-yes {
            color: #10b981;
        }

        .shared-no {
            color: #C72A2A;
        }

        /* DataTables Customization */
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #D4AF37 !important;
            color: #4A0E17 !important;
            border-color: #D4AF37 !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #F5D76E !important;
            color: #4A0E17 !important;
        }

        .dataTables_wrapper .dataTables_filter input {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 6px 12px;
        }

        .dataTables_wrapper .dataTables_filter input:focus {
            border-color: #D4AF37;
            outline: none;
        }

        /* Alert Styles */
        .alert-success-custom {
            background: #d4edda;
            border-left: 4px solid #10b981;
            color: #155724;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .alert-danger-custom {
            background: #f8d7da;
            border-left: 4px solid #C72A2A;
            color: #721c24;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .page-container {
                padding: 20px 0 30px;
            }
            
            .table-responsive {
                font-size: 12px;
            }
            
            .btn-download, .btn-delete {
                padding: 4px 8px;
                font-size: 11px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index.php">
            <i class="fas fa-gavel me-2"></i>Sisodiya Associates
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="lawyer/lawyer_dashboard.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a>
                </li>
               
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-id-card me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="page-container">
    <div class="container">
        <!-- Page Header -->
        <div class="mb-4">
            <h1 class="display-5 fw-bold" style="color: #4A0E17;">Document <span style="color: #D4AF37;">Management</span></h1>
            <p class="text-muted">Upload, view, and manage your legal documents</p>
        </div>

        <div class="row">
            <!-- Upload Section -->
            <div class="col-md-4 mb-4">
                <div class="upload-card">
                    <div class="card-header">
                        <h5><i class="fas fa-upload"></i> Upload Document</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if(isset($upload_success)): ?>
                            <div class="alert-success-custom">
                                <i class="fas fa-check-circle me-2"></i> <?php echo $upload_success; ?>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($upload_error)): ?>
                            <div class="alert-danger-custom">
                                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $upload_error; ?>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($delete_success)): ?>
                            <div class="alert-success-custom">
                                <i class="fas fa-check-circle me-2"></i> <?php echo $delete_success; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="fas fa-briefcase" style="color: #D4AF37;"></i> Select Case
                                </label>
                                <select class="form-select" name="case_id" required>
                                    <option value="">Choose case...</option>
                                    <?php if($cases && $cases->num_rows > 0): ?>
                                        <?php while($case = $cases->fetch_assoc()): ?>
                                            <option value="<?php echo $case['id']; ?>">
                                                <?php echo htmlspecialchars($case['case_number']); ?> - <?php echo htmlspecialchars(substr($case['title'], 0, 40)); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <option value="" disabled>No cases available</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="fas fa-file-alt" style="color: #D4AF37;"></i> Document File
                                </label>
                                <input type="file" class="form-control" name="document" required accept=".pdf,.doc,.docx,.txt,.jpg,.png">
                                <small class="text-muted">Supported formats: PDF, DOC, DOCX, TXT, JPG, PNG</small>
                            </div>
                            
                            <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" name="is_shared" value="1" id="is_shared" checked>
                                    <label class="form-check-label" for="is_shared">
                                        <i class="fas fa-share-alt" style="color: #D4AF37;"></i> Share with client
                                    </label>
                                </div>
                            <?php endif; ?>
                            
                            <button type="submit" class="btn btn-upload w-100">
                                <i class="fas fa-cloud-upload-alt me-2"></i> Upload Document
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Document Library -->
            <div class="col-md-8">
                <div class="library-card">
                    <div class="card-header">
                        <h5><i class="fas fa-folder-open"></i> Document Library</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="table-responsive">
                            <table id="docsTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>File Name</th>
                                        <th>Case</th>
                                        <th>Uploaded By</th>
                                        <th>Type</th>
                                        <th>Size</th>
                                        <th>Date</th>
                                        <th>Shared</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($documents && $documents->num_rows > 0): ?>
                                        <?php while($doc = $documents->fetch_assoc()): ?>
                                            <tr>
                                                <td>
                                                    <i class="fas fa-file-pdf" style="color: #C72A2A;"></i>
                                                    <strong><?php echo htmlspecialchars($doc['file_name']); ?></strong>
                                                 </td>
                                                <td><?php echo htmlspecialchars($doc['case_number']); ?></td>
                                                <td><?php echo htmlspecialchars($doc['uploaded_by_name']); ?></td>
                                                <td>
                                                    <span class="badge-file">
                                                        <?php echo strtoupper(htmlspecialchars($doc['file_type'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo round($doc['file_size'] / 1024, 2); ?> KB</td>
                                                <td><?php echo date('M d, Y', strtotime($doc['uploaded_at'])); ?></td>
                                                <td>
                                                    <?php if($doc['is_shared']): ?>
                                                        <i class="fas fa-check-circle shared-yes"></i> Yes
                                                    <?php else: ?>
                                                        <i class="fas fa-times-circle shared-no"></i> No
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" download class="btn btn-download btn-sm">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <?php if($user_role != 'client' || $doc['uploaded_by'] == $user_id): ?>
                                                        <a href="?delete=<?php echo $doc['id']; ?>" class="btn btn-delete btn-sm" onclick="return confirm('Are you sure you want to delete this document?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-4">
                                                <i class="fas fa-folder-open fa-3x mb-3" style="color: #D4AF37; opacity: 0.3;"></i>
                                                <p class="text-muted">No documents found. Upload your first document!</p>
                                             </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        if ($('#docsTable tbody tr').length > 0 && $('#docsTable tbody tr td').length > 1) {
            $('#docsTable').DataTable({
                order: [[5, 'desc']],
                pageLength: 10,
                language: {
                    search: "Search documents:",
                    lengthMenu: "Show _MENU_ documents",
                    info: "Showing _START_ to _END_ of _TOTAL_ documents",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "→",
                        previous: "←"
                    }
                }
            });
        }
    });
</script>

</body>
</html>