<?php
// footer.php - Common footer for all pages
?>
<!-- Footer -->
<footer class="footer" style="background: #2D0A10; color: white; padding: 50px 0 20px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="d-flex align-items-center mb-3">
                    <div class="logo-icon" style="width: 38px; height: 38px; background: var(--secondary, #D4AF37); border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; margin-right: 10px;">
                        <i class="fas fa-gavel" style="color: var(--primary-dark, #4A0E17);"></i>
                    </div>
                    <div class="fw-bold fs-4">ABT Law Firm</div>
                </div>
                <p class="text-white-50">Delivering justice with excellence and integrity for over 25 years.</p>
                <div class="d-flex gap-2">
                    <a href="#" class="social-icon" style="width: 36px; height: 36px; background: rgba(212,175,55,0.12); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; transition: all 0.3s; color: white;"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon" style="width: 36px; height: 36px; background: rgba(212,175,55,0.12); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; transition: all 0.3s; color: white;"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon" style="width: 36px; height: 36px; background: rgba(212,175,55,0.12); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; transition: all 0.3s; color: white;"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="social-icon" style="width: 36px; height: 36px; background: rgba(212,175,55,0.12); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; transition: all 0.3s; color: white;"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5 class="text-white mb-3">Quick Links</h5>
                <div class="d-flex flex-column gap-2">
                    <a href="index.php" class="text-white-50 text-decoration-none">Home</a>
                    <a href="practice.php" class="text-white-50 text-decoration-none">Practice Areas</a>
                    <a href="attorneys.php" class="text-white-50 text-decoration-none">Attorneys</a>
                    <a href="contact.php" class="text-white-50 text-decoration-none">Contact</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-white mb-3">Practice Areas</h5>
                <div class="d-flex flex-column gap-2">
                    <a href="#" class="text-white-50 text-decoration-none">Corporate Law</a>
                    <a href="#" class="text-white-50 text-decoration-none">Real Estate</a>
                    <a href="#" class="text-white-50 text-decoration-none">Criminal Defense</a>
                    <a href="#" class="text-white-50 text-decoration-none">Family Law</a>
                    <a href="#" class="text-white-50 text-decoration-none">Immigration Law</a>
                </div>
            </div>
            <div class="col-lg-3 mb-4">
                <h5 class="text-white mb-3">Newsletter</h5>
                <p class="text-white-50">Subscribe for legal updates</p>
                <div class="d-flex">
                    <input type="email" class="form-control" placeholder="Your email" style="border-radius: 50px 0 0 50px; background: rgba(255,255,255,0.1); border: 1px solid rgba(212,175,55,0.3); color: white;">
                    <button class="btn" style="background: linear-gradient(135deg, #D4AF37, #F5D76E); border-radius: 0 50px 50px 0; color: #4A0E17; font-weight: 600;">→</button>
                </div>
            </div>
        </div>
        <hr class="my-4" style="background: rgba(212,175,55,0.2);">
        <div class="text-center">
            <p class="mb-0 text-white-50">&copy; <?php echo date('Y'); ?> ABT Law Firm. All rights reserved. | <a href="#" class="text-decoration-none" style="color: #D4AF37;">Privacy Policy</a> | <a href="#" class="text-decoration-none" style="color: #D4AF37;">Terms of Service</a></p>
        </div>
    </div>
</footer>

<style>
    .social-icon:hover {
        background: var(--secondary, #D4AF37) !important;
        color: var(--primary-dark, #4A0E17) !important;
        transform: translateY(-3px);
    }
    
    .footer a.text-white-50:hover {
        color: #D4AF37 !important;
        transform: translateX(5px);
        display: inline-block;
        transition: all 0.3s;
    }
    
    .footer .form-control:focus {
        border-color: #D4AF37;
        box-shadow: 0 0 0 0.2rem rgba(212,175,55,0.25);
        outline: none;
    }
    
    .footer .form-control::placeholder {
        color: rgba(255,255,255,0.5);
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // Initialize AOS
    AOS.init({
        duration: 800,
        once: true,
        offset: 100
    });

    // Counter Animation Function
    function initCounters() {
        const counters = document.querySelectorAll('.counter');
        if (counters.length > 0) {
            const counterObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const counter = entry.target;
                        const target = parseInt(counter.getAttribute('data-target'));
                        let current = 0;
                        const increment = target / 50;
                        const updateCounter = () => {
                            current += increment;
                            if (current < target) {
                                counter.innerText = Math.ceil(current);
                                setTimeout(updateCounter, 20);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCounter();
                        counterObserver.unobserve(counter);
                    }
                });
            }, { threshold: 0.5 });
            
            counters.forEach(counter => counterObserver.observe(counter));
        }
    }

    // Scroll Reveal Animation
    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.scroll-reveal');
        if (revealElements.length > 0) {
            const revealObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('revealed');
                        revealObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            revealElements.forEach(element => revealObserver.observe(element));
        }
    }

    // Run on page load
    document.addEventListener('DOMContentLoaded', function() {
        initCounters();
        initScrollReveal();
    });
</script>
</body>
</html>