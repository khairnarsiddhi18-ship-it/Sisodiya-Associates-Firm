<?php
// session_start(); // UNCOMMENT THIS LINE - It's commented!

// Check if user has agreed to disclaimer - EXCLUDE disclaimer.php page itself
$current_page = basename($_SERVER['PHP_SELF']);


// Define base URL for consistent navigation
$base_url = ''; // Leave empty if files are in root directory

// header.php - Common header for all pages
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title><?php echo $page_title ?? 'ABT Law Firm'; ?> | Excellence in Legal Services</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
            background: #ffffff;
        }

        /* ========== BURGUNDY & GOLD COLOR THEME ========== */
        :root {
            --primary-dark: #4A0E17;
            --primary: #6B1A2A;
            --secondary: #D4AF37;
            --secondary-light: #F5D76E;
            --accent: #8B2635;
            --light: #FDF8F0;
            --dark: #2D0A10;
        }

        /* ========== SINGLE LINE HEADER ========== */
        .header-wrapper {
            background: var(--primary-dark);
            position: sticky;
            top: 0;
            z-index: 10;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .simple-header {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding: 0.6rem 0;
            gap: 20px;
            flex-wrap: nowrap;
        }

        /* Logo Section with Round Image Logo - LEFT ALIGNED */
        .logo-section {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            text-decoration: none;
        }

        .logo-section:hover {
            opacity: 0.9;
        }

        /* Round Logo Container */
        .logo-container {
            width: 45px;
            height: 45px;
            position: relative;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            overflow: hidden;
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            padding: 2px;
        }

        .logo-container:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(212, 175, 55, 0.4);
        }

        /* Round Image Logo Style */
        .logo-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        /* Inner circle for better look */
        .logo-inner {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-dark);
        }

        .logo-text {
            font-size: 1.2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff, var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            white-space: nowrap;
        }

        /* Gold ring animation */
        @keyframes ringPulse {
            0% {
                box-shadow: 0 0 0 0 rgba(212, 175, 55, 0.4);
            }
            70% {
                box-shadow: 0 0 0 5px rgba(212, 175, 55, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(212, 175, 55, 0);
            }
        }

        .logo-container {
            animation: ringPulse 2s infinite;
        }

        /* Case Status Search - Desktop */
        .case-search {
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.1);
            border-radius: 40px;
            padding: 3px;
            border: 1px solid rgba(212,175,55,0.3);
            flex-shrink: 1;
            margin-left: auto;
        }

        .case-search-input {
            background: transparent;
            border: none;
            padding: 6px 12px;
            color: white;
            font-size: 0.8rem;
            width: 170px;
            outline: none;
        }

        .case-search-input::placeholder {
            color: rgba(255,255,255,0.6);
            font-size: 0.75rem;
        }

        .case-search-btn {
            background: var(--secondary);
            border: none;
            border-radius: 40px;
            padding: 4px 14px;
            color: var(--primary-dark);
            font-weight: 600;
            font-size: 0.75rem;
            transition: all 0.3s;
            cursor: pointer;
            white-space: nowrap;
        }

        .case-search-btn:hover {
            background: var(--secondary-light);
            transform: scale(1.02);
        }

        /* Mobile Search Bar - Below Header */
        .mobile-search-container {
            background: var(--primary-dark);
            padding: 0 15px 12px 15px;
            display: none;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .mobile-search-wrapper {
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.1);
            border-radius: 40px;
            padding: 5px;
            border: 1px solid rgba(212,175,55,0.3);
        }

        .mobile-search-wrapper .case-search-input {
            flex: 1;
            background: transparent;
            border: none;
            padding: 10px 15px;
            color: white;
            font-size: 0.9rem;
            outline: none;
            width: auto;
        }

        .mobile-search-wrapper .case-search-input::placeholder {
            color: rgba(255,255,255,0.6);
        }

        .mobile-search-wrapper .case-search-btn {
            padding: 8px 20px;
            font-size: 0.85rem;
        }

        /* Navigation */
        .nav-section {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            flex-wrap: nowrap;
            flex-shrink: 0;
        }

        .nav-link-premium {
            color: white !important;
            font-weight: 500;
            padding: 0.4rem 0.8rem !important;
            transition: all 0.3s;
            border-radius: 6px;
            font-size: 0.85rem;
            text-decoration: none;
            white-space: nowrap;
        }

        .nav-link-premium:hover {
            background: rgba(212, 175, 55, 0.15);
            color: var(--secondary) !important;
        }

        .nav-link-premium.active {
            color: var(--secondary) !important;
            background: rgba(212, 175, 55, 0.15);
        }

        /* Login & Register Button Styles */
        .btn-login {
            background: transparent;
            border: 1.5px solid var(--secondary);
            color: white !important;
            padding: 0.4rem 1.2rem !important;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.8rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
            white-space: nowrap;
        }

        .btn-login:hover {
            background: var(--secondary);
            color: var(--primary-dark) !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
        }

        .btn-register {
            background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
            border: none;
            color: var(--primary-dark) !important;
            padding: 0.4rem 1.2rem !important;
            border-radius: 40px;
            font-weight: 700;
            font-size: 0.8rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
            white-space: nowrap;
        }

        .btn-register:hover {
            background: linear-gradient(135deg, var(--secondary-light), var(--secondary));
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.4);
            color: var(--primary-dark) !important;
        }

        /* Hamburger Menu - Mobile */
        .hamburger {
            display: none;
            cursor: pointer;
            background: rgba(212, 175, 55, 0.15);
            border-radius: 8px;
            padding: 6px;
            transition: all 0.3s;
            border: none;
        }

        .hamburger:hover {
            background: rgba(212, 175, 55, 0.25);
        }

        .hamburger span {
            display: block;
            width: 20px;
            height: 2px;
            background: var(--secondary);
            margin: 4px 0;
            transition: all 0.3s ease;
            border-radius: 2px;
        }

        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }

        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }

        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(5px, -5px);
        }

        /* Mobile Menu */
        .mobile-menu {
            position: fixed;
            top: 0;
            right: -100%;
            width: 75%;
            max-width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 1rem;
            z-index: 1000;
            transition: right 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: -5px 0 30px rgba(0,0,0,0.3);
            display: none;
        }

        .mobile-menu.active {
            right: 0;
            display: flex;
        }

        .mobile-menu .nav-link-premium {
            font-size: 1rem;
            padding: 0.6rem 1.5rem !important;
            width: 100%;
            text-align: center;
        }

        .mobile-menu .btn-login,
        .mobile-menu .btn-register {
            width: 80%;
            text-align: center;
            margin: 4px 0;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            z-index: 999;
        }

        .overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* Case Status Modal */
        .case-modal .modal-content {
            border-radius: 20px;
            overflow: hidden;
        }

        .case-modal .modal-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            border: none;
        }

        .case-modal .modal-header .btn-close {
            background: white;
            opacity: 1;
        }

        .case-result-card {
            background: #FDF8F0;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid var(--secondary);
        }

        .case-result-title {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 10px;
        }

        .case-result-detail {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(212,175,55,0.15);
        }

        .case-result-label {
            font-weight: 600;
            color: #4a5568;
        }

        .case-result-value {
            color: var(--primary-dark);
            font-weight: 500;
        }

        .status-badge-search {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-badge-search-active { background: #d4edda; color: #155724; }
        .status-badge-search-pending { background: #fff3cd; color: #856404; }
        .status-badge-search-closed { background: #d1ecf1; color: #0c5460; }

        .progress-bar-search {
            height: 6px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill-search {
            height: 100%;
            background: linear-gradient(90deg, var(--secondary), var(--secondary-light));
            border-radius: 10px;
        }

        /* Responsive Breakpoints */
        @media (max-width: 1100px) {
            .case-search {
                min-width: auto;
            }
            .case-search-input {
                width: 130px;
            }
            .nav-link-premium {
                padding: 0.4rem 0.6rem !important;
                font-size: 0.8rem;
            }
            .btn-login, .btn-register {
                padding: 0.4rem 1rem !important;
                font-size: 0.75rem;
            }
        }

        @media (max-width: 950px) {
            .case-search-input {
                width: 100px;
            }
            .nav-link-premium {
                padding: 0.3rem 0.5rem !important;
                font-size: 0.75rem;
            }
        }

        @media (max-width: 850px) {
            .nav-section {
                display: none;
            }
            .hamburger {
                display: block;
            }
            .logo-text {
                font-size: 1rem;
            }
            .logo-container {
                width: 35px;
                height: 35px;
            }
            /* Hide desktop search on mobile */
            .case-search {
                display: none;
            }
            /* Show mobile search container */
            .mobile-search-container {
                display: block;
            }
        }

        @media (min-width: 851px) {
            .mobile-search-container {
                display: none !important;
            }
        }

        /* Loading Spinner */
        .loading-spinner {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #4A0E17;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }

        .loading-spinner.hide {
            opacity: 0;
            visibility: hidden;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid rgba(212, 175, 55, 0.2);
            border-top-color: var(--secondary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Scroll Reveal */
        .scroll-reveal {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }

        .scroll-reveal.revealed {
            opacity: 1;
            transform: translateY(0);
        }

        /* Fix for active page detection */
        .nav-link-premium.active {
            color: var(--secondary) !important;
            background: rgba(212, 175, 55, 0.15);
        }
    </style>
</head>
<body>

<!-- Simple Header - Single Line -->
<div class="header-wrapper">
    <div class="container">
        <div class="simple-header">
            <!-- Logo with Round Image - LEFT ALIGNED -->
            <a href="index.php" class="logo-section" style="text-decoration: none;">
                <div class="logo-container">
                    <div class="logo-inner">
                        <img src="assets/logo.jpeg" alt="Sisodiya Associates Logo" class="logo-image">
                    </div>
                </div>
                <span class="logo-text">Sisodiya Associates</span>
            </a>

            <!-- Case Status Search - Desktop Only (pushes to right with margin-left: auto) -->
            <div class="case-search">
                <input type="text" class="case-search-input" id="caseSearchInput" placeholder="Case No. or Title...">
                <button class="case-search-btn" onclick="searchCase()">
                    <i class="fas fa-search"></i> Track
                </button>
            </div>

            <!-- Navigation - Fixed Version -->
            <div class="nav-section">
                <?php 
                $current_page = basename($_SERVER['PHP_SELF']);
                ?>
                <a class="nav-link-premium <?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : ''; ?>" href="index.php">Home</a>
                <a class="nav-link-premium <?php echo $current_page == 'all_cases.php' ? 'active' : ''; ?>" href="all_cases.php">Cases</a>
                <a class="nav-link-premium <?php echo $current_page == 'practice.php' ? 'active' : ''; ?>" href="practice.php">Practice</a>
                <a class="nav-link-premium <?php echo $current_page == 'attorneys.php' ? 'active' : ''; ?>" href="attorneys.php">Attorneys</a>
                <a class="nav-link-premium <?php echo $current_page == 'contact.php' ? 'active' : ''; ?>" href="contact.php">Contact</a>
                
                <a class="btn-login" href="login.php">
                    <i class="fas fa-sign-in-alt me-1"></i> Login
                </a>
                <a class="btn-register" href="register.php">
                    <i class="fas fa-user-plus me-1"></i> Register
                </a>
            </div>
            
            <!-- Hamburger Menu Button (Mobile Only) -->
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
</div>

<!-- Mobile Search Bar - Below Header (Visible only on mobile) -->
<div class="mobile-search-container">
    <div class="container">
        <div class="mobile-search-wrapper">
            <input type="text" class="case-search-input" id="mobileCaseSearchInput" placeholder="Search by Case No. or Title...">
            <button class="case-search-btn" onclick="searchCaseMobile()">
                <i class="fas fa-search"></i> Track Case
            </button>
        </div>
    </div>
</div>

<!-- Mobile Menu - Fixed Version -->
<div class="mobile-menu" id="mobileMenu">
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    ?>
    <a class="nav-link-premium <?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : ''; ?>" href="index.php">Home</a>
    <a class="nav-link-premium <?php echo $current_page == 'all_cases.php' ? 'active' : ''; ?>" href="all_cases.php">Cases</a>
    <a class="nav-link-premium <?php echo $current_page == 'practice.php' ? 'active' : ''; ?>" href="practice.php">Practice Areas</a>
    <a class="nav-link-premium <?php echo $current_page == 'attorneys.php' ? 'active' : ''; ?>" href="attorneys.php">Attorneys</a>
    <a class="nav-link-premium <?php echo $current_page == 'contact.php' ? 'active' : ''; ?>" href="contact.php">Contact</a>
    
    <a class="btn-login" href="login.php">
        <i class="fas fa-sign-in-alt me-1"></i> Login
    </a>
    <a class="btn-register" href="register.php">
        <i class="fas fa-user-plus me-1"></i> Register
    </a>
</div>

<div class="overlay" id="overlay"></div>

<!-- Case Status Result Modal -->
<div class="modal fade case-modal" id="caseStatusModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-gavel" style="color: var(--secondary);"></i> Case Status Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="caseStatusResult">
                <div class="text-center py-4">
                    <p class="text-muted">Enter a case number or title to search.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Hide loading spinner
    window.addEventListener('load', function() {
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
            setTimeout(() => {
                spinner.classList.add('hide');
                setTimeout(() => {
                    spinner.style.display = 'none';
                }, 500);
            }, 500);
        }
    });

    // Header scroll effect
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header-wrapper');
        if (header) {
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 5px 20px rgba(0,0,0,0.1)';
            } else {
                header.style.boxShadow = 'none';
            }
        }
    });

    // Hamburger Menu Toggle
    const hamburger = document.getElementById('hamburger');
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('overlay');

    if (hamburger && mobileMenu && overlay) {
        function toggleMenu() {
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            overlay.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }

        hamburger.addEventListener('click', toggleMenu);
        overlay.addEventListener('click', toggleMenu);

        document.querySelectorAll('.mobile-menu .nav-link-premium, .mobile-menu .btn-login, .mobile-menu .btn-register').forEach(link => {
            link.addEventListener('click', () => {
                if (mobileMenu.classList.contains('active')) {
                    toggleMenu();
                }
            });
        });
    }

    // Search Case Functions
    function searchCase() {
        const searchTerm = document.getElementById('caseSearchInput').value.trim();
        if (searchTerm === '') {
            alert('Please enter a case number or case title to search.');
            return;
        }
        performCaseSearch(searchTerm);
    }

    function searchCaseMobile() {
        const searchTerm = document.getElementById('mobileCaseSearchInput').value.trim();
        if (searchTerm === '') {
            alert('Please enter a case number or case title to search.');
            return;
        }
        performCaseSearch(searchTerm);
    }

    function performCaseSearch(searchTerm) {
        const modalBody = document.getElementById('caseStatusResult');
        modalBody.innerHTML = '<div class="text-center py-4"><div class="spinner-border" style="color: #D4AF37;" role="status"></div><p class="mt-2">Searching...</p></div>';
        
        const modal = new bootstrap.Modal(document.getElementById('caseStatusModal'));
        modal.show();
        
        fetch('search_case.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'search=' + encodeURIComponent(searchTerm)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayCaseResult(data.case);
            } else {
                modalBody.innerHTML = `
                    <div class="text-center py-4">
                        <i class="fas fa-search fa-3x mb-3" style="color: #D4AF37; opacity: 0.5;"></i>
                        <p class="text-muted">${data.message}</p>
                        <button class="btn btn-sm mt-3" style="background: #D4AF37; color: #4A0E17;" onclick="location.reload()">Try Again</button>
                    </div>
                `;
            }
        })
        .catch(error => {
            modalBody.innerHTML = `
                <div class="text-center py-4">
                    <i class="fas fa-exclamation-triangle fa-3x mb-3" style="color: #C72A2A; opacity: 0.5;"></i>
                    <p class="text-muted">Error connecting to server. Please try again.</p>
                    <button class="btn btn-sm mt-3" style="background: #D4AF37; color: #4A0E17;" onclick="location.reload()">Retry</button>
                </div>
            `;
            console.error('Error:', error);
        });
    }

    function displayCaseResult(caseData) {
        const modalBody = document.getElementById('caseStatusResult');
        
        let statusClass = '';
        switch(caseData.status) {
            case 'active': statusClass = 'status-badge-search-active'; break;
            case 'pending': statusClass = 'status-badge-search-pending'; break;
            case 'closed': statusClass = 'status-badge-search-closed'; break;
            default: statusClass = 'status-badge-search-pending';
        }
        
        modalBody.innerHTML = `
            <div class="case-result-card">
                <div class="case-result-title">
                    <i class="fas fa-balance-scale" style="color: #D4AF37;"></i> ${escapeHtml(caseData.case_number)}
                </div>
                <div class="case-result-detail">
                    <span class="case-result-label">Case Title:</span>
                    <span class="case-result-value">${escapeHtml(caseData.title)}</span>
                </div>
                <div class="case-result-detail">
                    <span class="case-result-label">Status:</span>
                    <span class="case-result-value">
                        <span class="status-badge-search ${statusClass}">${caseData.status.toUpperCase()}</span>
                    </span>
                </div>
                <div class="case-result-detail">
                    <span class="case-result-label">Assigned Lawyer:</span>
                    <span class="case-result-value">${caseData.lawyer_name ? escapeHtml(caseData.lawyer_name) : 'Not Assigned Yet'}</span>
                </div>
                <div class="case-result-detail">
                    <span class="case-result-label">Filed On:</span>
                    <span class="case-result-value">${caseData.filed_date}</span>
                </div>
                <div class="mt-3">
                    <div class="d-flex justify-content-between small mb-1">
                        <span>Case Progress</span>
                        <span>${caseData.progress}%</span>
                    </div>
                    <div class="progress-bar-search">
                        <div class="progress-fill-search" style="width: ${caseData.progress}%"></div>
                    </div>
                </div>
                ${caseData.next_hearing ? `
                <div class="mt-3 p-2" style="background: rgba(212,175,55,0.1); border-radius: 10px;">
                    <small><i class="fas fa-gavel" style="color: #D4AF37;"></i> Next Hearing: ${caseData.next_hearing}</small>
                </div>
                ` : ''}
                ${caseData.description ? `
                <div class="mt-3">
                    <small class="text-muted">${escapeHtml(caseData.description.substring(0, 150))}${caseData.description.length > 150 ? '...' : ''}</small>
                </div>
                ` : ''}
            </div>
            <div class="text-center mt-3">
                <small class="text-muted">
                    <i class="fas fa-lock"></i> For detailed case information, please <a href="login.php" style="color: #D4AF37; text-decoration: none;">login to your account</a>.
                </small>
            </div>
        `;
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Enter key press for search
    const searchInput = document.getElementById('caseSearchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchCase();
            }
        });
    }
    
    const mobileSearchInput = document.getElementById('mobileCaseSearchInput');
    if (mobileSearchInput) {
        mobileSearchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchCaseMobile();
            }
        });
    }

    // Scroll Reveal Animation
    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.scroll-reveal');
        if (revealElements.length > 0) {
            const revealObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('revealed');
                        revealObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            revealElements.forEach(element => revealObserver.observe(element));
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        initScrollReveal();
    });
</script>
</body>
</html>