<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Profile Settings";
$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    // Handle profile picture upload
    $profile_pic = $user['profile_pic'];
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/profiles/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        
        $ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        $profile_pic = $user_id . '_' . time() . '.' . $ext;
        $target_file = $target_dir . $profile_pic;
        
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file);
    }
    
    // Update password if provided
    $password_update = "";
    if (!empty($_POST['new_password'])) {
        if (password_verify($_POST['current_password'], $user['password_hash'])) {
            $new_hash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $password_update = ", password_hash = '$new_hash'";
        } else {
            $error = "Current password is incorrect!";
        }
    }
    
    if (!isset($error)) {
        $stmt = $conn->prepare("UPDATE users SET full_name=?, phone=?, address=?, profile_pic=? $password_update WHERE id=?");
        $stmt->bind_param("ssssi", $full_name, $phone, $address, $profile_pic, $user_id);
        
        if ($stmt->execute()) {
            $_SESSION['user_name'] = $full_name;
            $success = "Profile updated successfully!";
            header("Refresh:2");
        }
    }
}

require_once 'includes/header.php';
?>

<style>
    /* Page Specific Styles */
    .page-container {
        background: #FDF8F0;
        min-height: 100vh;
        padding: 30px 0 50px;
        margin-top: 70px;
    }

    .profile-card {
        background: white;
        border-radius: 25px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        overflow: hidden;
        border: none;
    }

    .profile-card .card-header {
        background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
        color: white;
        border: none;
        padding: 20px 25px;
    }

    .profile-card .card-header h4 {
        margin: 0;
        font-weight: 700;
    }

    .profile-card .card-header h4 i {
        color: #D4AF37;
        margin-right: 10px;
    }

    .profile-card .card-body {
        padding: 30px;
    }

    /* Profile Image */
    .profile-image-container {
        text-align: center;
        margin-bottom: 30px;
        position: relative;
    }

    .profile-avatar {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid #D4AF37;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }

    .profile-avatar:hover {
        transform: scale(1.02);
        border-color: #F5D76E;
    }

    .profile-name {
        color: #4A0E17;
        font-weight: 800;
        margin-top: 15px;
        margin-bottom: 5px;
    }

    .profile-meta {
        color: #718096;
        font-size: 14px;
    }

    .profile-meta i {
        color: #D4AF37;
        margin-right: 5px;
    }

    /* Form Styles */
    .form-label {
        font-weight: 600;
        color: #4A0E17;
        margin-bottom: 8px;
    }

    .form-label i {
        color: #D4AF37;
        margin-right: 8px;
    }

    .form-control {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px 15px;
        transition: all 0.3s;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    .form-control:focus {
        border-color: #D4AF37;
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        outline: none;
    }

    .form-control[disabled] {
        background: #f8f9fa;
        color: #6c757d;
    }

    textarea.form-control {
        resize: vertical;
    }

    /* Password Section */
    .password-section {
        background: #FDF8F0;
        border-radius: 15px;
        padding: 20px;
        margin: 20px 0;
        border: 1px solid rgba(212, 175, 55, 0.2);
    }

    .password-section h5 {
        color: #4A0E17;
        font-weight: 700;
        margin-bottom: 15px;
    }

    .password-section h5 i {
        color: #D4AF37;
        margin-right: 8px;
    }

    /* Buttons */
    .btn-save {
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border: none;
        padding: 12px 30px;
        border-radius: 12px;
        font-weight: 700;
        color: #4A0E17;
        transition: all 0.3s;
        margin-right: 10px;
    }

    .btn-save:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        color: #4A0E17;
    }

    .btn-back {
        background: transparent;
        border: 2px solid #D4AF37;
        padding: 10px 28px;
        border-radius: 12px;
        font-weight: 600;
        color: #4A0E17;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-back:hover {
        background: #D4AF37;
        color: #4A0E17;
        transform: translateY(-2px);
    }

    /* Alerts */
    .alert-success-custom {
        background: #d4edda;
        border-left: 4px solid #10b981;
        color: #155724;
        border-radius: 12px;
        padding: 12px 20px;
        margin-bottom: 20px;
    }

    .alert-danger-custom {
        background: #f8d7da;
        border-left: 4px solid #C72A2A;
        color: #721c24;
        border-radius: 12px;
        padding: 12px 20px;
        margin-bottom: 20px;
    }

    /* Divider */
    hr {
        background: rgba(212, 175, 55, 0.2);
        margin: 20px 0;
    }

    @media (max-width: 768px) {
        .profile-card .card-body {
            padding: 20px;
        }

        .btn-save, .btn-back {
            width: 100%;
            margin-bottom: 10px;
            text-align: center;
        }

        .btn-save {
            margin-right: 0;
        }
    }
</style>

<div class="page-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="profile-card">
                    <div class="card-header">
                        <h4><i class="fas fa-user-circle"></i> Profile Settings</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($success)): ?>
                            <div class="alert-success-custom">
                                <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($error)): ?>
                            <div class="alert-danger-custom">
                                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Profile Image -->
                        <div class="profile-image-container">
                            <img src="<?php echo (!empty($user['profile_pic']) && $user['profile_pic'] != 'default.png') ? 'uploads/profiles/' . $user['profile_pic'] : 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name']) . '&background=D4AF37&color=4A0E17&size=150'; ?>" 
                                 class="profile-avatar" 
                                 alt="Profile Picture">
                            <h3 class="profile-name"><?php echo htmlspecialchars($user['full_name']); ?></h3>
                            <p class="profile-meta">
                                <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?> | 
                                <i class="fas fa-user-tag"></i> <?php echo ucfirst($user['role']); ?>
                            </p>
                        </div>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><i class="fas fa-user"></i> Username</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><i class="fas fa-envelope"></i> Email</label>
                                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-user-tie"></i> Full Name</label>
                                <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-phone-alt"></i> Phone Number</label>
                                <input type="tel" class="form-control" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-map-marker-alt"></i> Address</label>
                                <textarea class="form-control" name="address" rows="2"><?php echo htmlspecialchars($user['address']); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-camera"></i> Profile Picture</label>
                                <input type="file" class="form-control" name="profile_pic" accept="image/*">
                                <small class="text-muted">Upload a JPG, PNG or GIF image (Max 2MB)</small>
                            </div>
                            
                            <div class="password-section">
                                <h5><i class="fas fa-lock"></i> Change Password</h5>
                                
                                <div class="mb-3">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" class="form-control" name="current_password">
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">New Password</label>
                                        <input type="password" class="form-control" name="new_password" id="new_password">
                                        <small class="text-muted" id="passwordStrength"></small>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" name="confirm_password" id="confirm_password">
                                        <small class="text-muted" id="confirmMatch"></small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex flex-wrap">
                                <button type="submit" class="btn-save">
                                    <i class="fas fa-save me-2"></i> Save Changes
                                </button>
                                <a href="<?php 
                                    if($_SESSION['user_role'] == 'client') {
                                        echo 'client/client_dashboard.php';
                                    } elseif($_SESSION['user_role'] == 'admin') {
                                        echo 'admin/admin_dashboard.php';
                                    } elseif($_SESSION['user_role'] == 'lawyer') {
                                        echo 'lawyer/lawyer_dashboard.php';
                                    } elseif($_SESSION['user_role'] == 'paralegal') {
                                        echo 'paralegal/paralegal_dashboard.php';
                                    } else {
                                        echo 'dashboard.php';
                                    }
                                ?>" class="btn-back">
                                    <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Password strength checker
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');
    const strengthText = document.getElementById('passwordStrength');
    const confirmMatch = document.getElementById('confirmMatch');

    if (newPassword) {
        newPassword.addEventListener('input', function() {
            const password = this.value;
            let strength = '';
            
            if (password.length === 0) {
                strength = '';
            } else if (password.length < 6) {
                strength = '<span style="color: #ef4444;">❌ Weak - Minimum 6 characters</span>';
            } else if (password.length >= 6 && password.length < 8) {
                strength = '<span style="color: #f59e0b;">⚠️ Fair - Add more characters</span>';
            } else if (password.length >= 8 && /[A-Z]/.test(password) && /[0-9]/.test(password)) {
                strength = '<span style="color: #10b981;">✅ Strong password!</span>';
            } else {
                strength = '<span style="color: #10b981;">✓ Good password</span>';
            }
            
            strengthText.innerHTML = strength;
            checkConfirmMatch();
        });
    }

    function checkConfirmMatch() {
        if (confirmPassword && confirmPassword.value.length > 0) {
            if (newPassword && newPassword.value === confirmPassword.value) {
                confirmMatch.innerHTML = '<span style="color: #10b981;">✓ Passwords match</span>';
            } else {
                confirmMatch.innerHTML = '<span style="color: #ef4444;">✗ Passwords do not match</span>';
            }
        } else if (confirmMatch) {
            confirmMatch.innerHTML = '';
        }
    }

    if (confirmPassword) {
        confirmPassword.addEventListener('input', checkConfirmMatch);
    }
</script>

<?php require_once 'includes/footer.php'; ?>