<?php
session_start();
require_once 'config/database.php';

$page_title = "Contact Us";

// Fetch contact information from database
$contact_info = [];
$result = $conn->query("SELECT type, value FROM contact_info");
while($row = $result->fetch_assoc()) {
    $contact_info[$row['type']] = $row['value'];
}

// Set default values if not found
$address = $contact_info['address'] ?? '123 Legal Street, Suite 100, New York, NY 10001';
$phone = $contact_info['phone'] ?? 'Phone: (555) 123-4567<br>Fax: (555) 123-4568<br>24/7 Emergency: (555) 123-4569';
$email = $contact_info['email'] ?? 'General: info@abtlaw.com<br>Support: support@abtlaw.com<br>Billing: billing@abtlaw.com';
$hours = $contact_info['hours'] ?? 'Monday - Friday: 9:00 AM - 6:00 PM<br>Saturday: 10:00 AM - 2:00 PM<br>Sunday: Closed<br>Emergency: 24/7 Available';
$map_embed = $contact_info['map_embed'] ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bbafd23%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1699999999999!5m2!1sen!2sus';

require_once 'includes/header.php';
?>

<style>
    /* Page Specific Styles */
    .page-header {
        background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
        padding: 150px 0 80px;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .page-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(212,175,55,0.05)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        background-size: cover;
        animation: wave 15s ease-in-out infinite;
    }

    @keyframes wave {
        0%, 100% { transform: translateX(0) translateY(0); }
        50% { transform: translateX(-5%) translateY(10px); }
    }

    .contact-card {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        text-align: center;
        transition: all 0.3s;
        height: 100%;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border-bottom: 3px solid transparent;
    }

    .contact-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.12);
        border-bottom-color: #D4AF37;
    }

    .contact-icon-circle {
        width: 70px;
        height: 70px;
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
        transition: all 0.3s;
    }

    .contact-card:hover .contact-icon-circle {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
    }

    .contact-icon-circle i {
        font-size: 2rem;
        color: #4A0E17;
    }

    .contact-card h4 {
        color: #4A0E17;
        font-weight: 700;
        margin-bottom: 1rem;
    }

    .contact-card p {
        color: #4a5568;
        line-height: 1.6;
    }

    .contact-form {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(212, 175, 55, 0.2);
    }

    .contact-form h3 {
        color: #4A0E17;
        font-weight: 700;
    }

    .form-control-custom {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 12px 15px;
        transition: all 0.3s;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    .form-control-custom:focus {
        border-color: #D4AF37;
        box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.1);
        outline: none;
    }

    .btn-submit {
        background: linear-gradient(135deg, #D4AF37, #F5D76E);
        border: none;
        padding: 12px 40px;
        border-radius: 50px;
        font-weight: 700;
        color: #4A0E17;
        transition: all 0.3s;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
        color: #4A0E17;
    }

    .map-container {
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(212, 175, 55, 0.2);
    }

    .office-hours {
        list-style: none;
        padding: 0;
    }

    .office-hours li {
        padding: 10px 0;
        border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        display: flex;
        justify-content: space-between;
        color: #4a5568;
    }

    .office-hours li strong {
        color: #4A0E17;
    }

    .text-primary {
        color: #D4AF37 !important;
    }

    hr {
        background: rgba(212, 175, 55, 0.2);
        margin: 15px 0;
    }

    .social-icon-circle {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        background: rgba(212, 175, 55, 0.1);
        border-radius: 50%;
        color: #D4AF37;
        transition: all 0.3s;
        text-decoration: none;
        margin: 0 5px;
    }

    .social-icon-circle:hover {
        background: #D4AF37;
        color: #4A0E17;
        transform: translateY(-3px);
    }

    /* FAQ Section */
    .faq-section {
        background: #FDF8F0;
        padding: 80px 0;
    }

    .faq-card {
        background: white;
        border-radius: 20px;
        padding: 1.5rem;
        transition: all 0.3s;
        height: 100%;
        border-left: 3px solid #D4AF37;
    }

    .faq-card:hover {
        transform: translateX(5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }

    .faq-card h5 {
        color: #4A0E17;
        font-weight: 700;
        margin-bottom: 0.8rem;
    }

    .faq-card h5 i {
        color: #D4AF37;
        margin-right: 10px;
    }

    .faq-card p {
        color: #4a5568;
        margin-bottom: 0;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .page-header {
            padding: 120px 0 60px;
        }
        
        .page-header h1 {
            font-size: 2rem;
        }
        
        .contact-card {
            padding: 1.5rem;
        }
        
        .contact-icon-circle {
            width: 60px;
            height: 60px;
        }
        
        .contact-icon-circle i {
            font-size: 1.5rem;
        }
        
        .contact-form {
            padding: 1.5rem;
        }
    }
</style>

<!-- Page Header -->
<section class="page-header">
    <div class="container text-center position-relative" style="z-index: 2;">
        <h1 class="display-3 fw-bold" data-aos="fade-down">Contact <span style="color: #D4AF37;">Us</span></h1>
        <p class="lead" data-aos="fade-up">Get in touch with our legal experts today</p>
    </div>
</section>

<!-- Contact Info Cards -->
<section class="py-5" style="background: #FDF8F0;">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="contact-card">
                    <div class="contact-icon-circle">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h4>Visit Us</h4>
                    <p><?php echo nl2br(htmlspecialchars($address)); ?></p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="contact-card">
                    <div class="contact-icon-circle">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h4>Call Us</h4>
                    <p><?php echo $phone; ?></p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
                <div class="contact-card">
                    <div class="contact-icon-circle">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h4>Email Us</h4>
                    <p><?php echo $email; ?></p>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Contact Form -->
            <div class="col-lg-6" data-aos="fade-right">
                <div class="contact-form">
                    <h3 class="mb-4">Send Us a Message</h3>
                    <form action="send_contact.php" method="POST">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control form-control-custom" name="first_name" placeholder="First Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control form-control-custom" name="last_name" placeholder="Last Name" required>
                            </div>
                            <div class="col-12">
                                <input type="email" class="form-control form-control-custom" name="email" placeholder="Email Address" required>
                            </div>
                            <div class="col-12">
                                <input type="tel" class="form-control form-control-custom" name="phone" placeholder="Phone Number">
                            </div>
                            <div class="col-12">
                                <select class="form-select form-control-custom" name="practice_area">
                                    <option value="">Select Practice Area</option>
                                    <option>Corporate Law</option>
                                    <option>Real Estate</option>
                                    <option>Medical Malpractice</option>
                                    <option>Criminal Defense</option>
                                    <option>Family Law</option>
                                    <option>Immigration Law</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <textarea class="form-control form-control-custom" name="message" rows="5" placeholder="Describe your legal matter..." required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-submit w-100">
                                    <i class="fas fa-paper-plane me-2"></i>Send Message
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Map & Office Hours -->
            <div class="col-lg-6" data-aos="fade-left">
                <div class="map-container mb-4">
                    <iframe src="<?php echo htmlspecialchars($map_embed); ?>" 
                            width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
                <div class="contact-card text-start">
                    <h4 class="mb-3">Office Hours</h4>
                    <?php
                    // Parse office hours from database
                    $hours_lines = explode('<br>', $hours);
                    ?>
                    <ul class="office-hours">
                        <?php foreach($hours_lines as $line): ?>
                            <?php if(strpos($line, ':') !== false): 
                                $parts = explode(':', $line, 2);
                            ?>
                                <li><span><?php echo trim($parts[0]); ?>:</span> <strong><?php echo trim($parts[1]); ?></strong></li>
                            <?php else: ?>
                                <li><span><?php echo trim($line); ?></span></li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                    <hr>
                    <h4 class="mb-3">Follow Us</h4>
                    <div class="d-flex gap-3 justify-content-center">
                        <a href="#" class="social-icon-circle"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-icon-circle"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-icon-circle"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-icon-circle"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <h2 class="display-5 fw-bold" style="color: #4A0E17;">Frequently Asked <span style="color: #D4AF37;">Questions</span></h2>
            <p class="lead text-muted">Quick answers to common questions</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
                <div class="faq-card">
                    <h5><i class="fas fa-question-circle"></i> How do I schedule a consultation?</h5>
                    <p>You can call our office, email us, or fill out the contact form above. We'll respond within 24 hours.</p>
                </div>
            </div>
            <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div class="faq-card">
                    <h5><i class="fas fa-dollar-sign"></i> What are your fees?</h5>
                    <p>We offer flexible fee structures including hourly rates, contingency fees, and flat fees depending on the case type.</p>
                </div>
            </div>
            <div class="col-md-6" data-aos="fade-up" data-aos-delay="300">
                <div class="faq-card">
                    <h5><i class="fas fa-clock"></i> How long will my case take?</h5>
                    <p>Case duration varies based on complexity. We'll provide a realistic timeline during your initial consultation.</p>
                </div>
            </div>
            <div class="col-md-6" data-aos="fade-up" data-aos-delay="400">
                <div class="faq-card">
                    <h5><i class="fas fa-lock"></i> Is my information confidential?</h5>
                    <p>Yes, all communications are protected by attorney-client privilege and strict confidentiality policies.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5" style="background: linear-gradient(135deg, #4A0E17, #6B1A2A);">
    <div class="container text-center">
        <h2 class="display-5 fw-bold text-white mb-4">Need Immediate Legal Help?</h2>
        <p class="lead text-white-50 mb-4">Our attorneys are available 24/7 for emergency legal matters</p>
        <div class="d-flex gap-3 justify-content-center flex-wrap">
            <?php
            // Extract emergency number from phone field
            preg_match('/Emergency:?\s*\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})/', $phone, $matches);
            $emergency_phone = !empty($matches) ? $matches[1] . $matches[2] . $matches[3] : '5551234569';
            ?>
            <a href="tel:+1<?php echo $emergency_phone; ?>" class="btn-premium-primary" style="background: linear-gradient(135deg, #D4AF37, #F5D76E); color: #4A0E17; border-radius: 50px; padding: 12px 30px; font-weight: 700; text-decoration: none;">
                <i class="fas fa-phone-alt me-2"></i>Call Emergency Line
            </a>
            <a href="register.php" class="btn-premium-outline" style="border: 2px solid #D4AF37; color: white; border-radius: 50px; padding: 12px 30px; font-weight: 600; text-decoration: none;">
                <i class="fas fa-calendar-check me-2"></i>Schedule Consultation
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>