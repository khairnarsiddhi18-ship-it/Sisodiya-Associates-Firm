<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Case Details";
$case_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Fetch case details with proper permissions
$query = "SELECT c.*, 
          cl.full_name as client_name, cl.email as client_email, cl.phone as client_phone,
          l.full_name as lawyer_name, l.email as lawyer_email,
          (SELECT COUNT(*) FROM hearings WHERE case_id = c.id) as total_hearings,
          (SELECT COUNT(*) FROM documents WHERE case_id = c.id) as total_documents,
          (SELECT COALESCE(SUM(hours), 0) FROM timesheets WHERE case_id = c.id) as total_hours
          FROM cases c 
          LEFT JOIN users cl ON c.client_id = cl.id 
          LEFT JOIN users l ON c.assigned_lawyer_id = l.id 
          WHERE c.id = $case_id";

// Add role-based restrictions
if ($user_role == 'client') {
    $query .= " AND c.client_id = $user_id";
} elseif ($user_role == 'lawyer') {
    $query .= " AND c.assigned_lawyer_id = $user_id";
}

$result = $conn->query($query);
$case = $result->fetch_assoc();

if (!$case) {
    header("Location: cases.php?error=access_denied");
    exit();
}

// Fetch hearings for this case
$hearings = $conn->query("SELECT * FROM hearings WHERE case_id = $case_id ORDER BY hearing_date DESC");

// Fetch documents for this case
$documents = $conn->query("SELECT d.*, u.full_name as uploaded_by_name 
                           FROM documents d 
                           JOIN users u ON d.uploaded_by = u.id 
                           WHERE d.case_id = $case_id 
                           ORDER BY d.uploaded_at DESC");

// Fetch timesheets (for lawyers)
$timesheets = null;
if ($user_role == 'lawyer' || $user_role == 'admin') {
    $timesheets = $conn->query("SELECT t.*, u.full_name as lawyer_name 
                                FROM timesheets t 
                                JOIN users u ON t.user_id = u.id 
                                WHERE t.case_id = $case_id 
                                ORDER BY t.date DESC");
}

// Fetch progress notes
$progress_notes = $conn->query("SELECT cp.*, u.full_name as user_name 
                                FROM case_progress cp 
                                JOIN users u ON cp.user_id = u.id 
                                WHERE cp.case_id = $case_id 
                                ORDER BY cp.created_at DESC");

// Add progress note
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_progress'])) {
    $note = $_POST['progress_note'];
    $stmt = $conn->prepare("INSERT INTO case_progress (case_id, user_id, note) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $case_id, $user_id, $note);
    $stmt->execute();
    header("Location: case_details.php?id=$case_id&msg=progress_added");
    exit();
}

// Update case status
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    $progress = $_POST['progress'];
    $stmt = $conn->prepare("UPDATE cases SET status = ?, progress = ? WHERE id = ?");
    $stmt->bind_param("sii", $new_status, $progress, $case_id);
    $stmt->execute();
    header("Location: case_details.php?id=$case_id&msg=status_updated");
    exit();
}

require_once 'includes/header.php';
?>

<style>
    /* Page Specific Styles */
    :root {
        --primary-dark: #4A0E17;
        --primary: #6B1A2A;
        --secondary: #D4AF37;
        --secondary-light: #F5D76E;
        --light: #FDF8F0;
        --dark: #2D0A10;
    }

    .case-header {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        color: white;
        padding: 40px 0;
        margin-top: 70px;
    }

    .stat-card {
        background: white;
        border-radius: 20px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        transition: all 0.3s;
        border-bottom: 3px solid transparent;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        border-bottom-color: var(--secondary);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 10px;
    }

    .stat-icon i {
        font-size: 1.5rem;
        color: var(--primary-dark);
    }

    .timeline {
        position: relative;
        padding-left: 30px;
    }

    .timeline::before {
        content: '';
        position: absolute;
        left: 10px;
        top: 0;
        bottom: 0;
        width: 2px;
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
    }

    .timeline-item {
        position: relative;
        margin-bottom: 25px;
        padding: 15px;
        background: var(--light);
        border-radius: 12px;
        border-left: 3px solid var(--secondary);
    }

    .timeline-item::before {
        content: '';
        position: absolute;
        left: -24px;
        top: 20px;
        width: 12px;
        height: 12px;
        background: var(--secondary);
        border-radius: 50%;
        border: 2px solid white;
    }

    .progress-status {
        width: 100%;
        height: 8px;
        background: #e2e8f0;
        border-radius: 10px;
        overflow: hidden;
        margin: 10px 0;
    }

    .progress-bar-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--secondary), var(--secondary-light));
        transition: width 0.5s ease;
        border-radius: 10px;
    }

    .status-badge {
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .status-active { background: #d4edda; color: #155724; }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-closed { background: #d1ecf1; color: #0c5460; }
    .status-archived { background: #e2e3e5; color: #383d41; }

    /* Card Styles */
    .info-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        margin-bottom: 25px;
        border: none;
    }

    .info-card .card-header {
        background: white;
        border-bottom: 2px solid rgba(212, 175, 55, 0.2);
        padding: 15px 20px;
    }

    .info-card .card-header h5 {
        color: var(--primary-dark);
        font-weight: 700;
        margin: 0;
    }

    .info-card .card-header h5 i {
        color: var(--secondary);
        margin-right: 8px;
    }

    .info-card .card-body {
        padding: 20px;
    }

    .btn-primary-custom {
        background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
        border: none;
        color: var(--primary-dark);
        font-weight: 600;
        transition: all 0.3s;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }

    .btn-outline-custom {
        border: 1px solid var(--secondary);
        color: var(--primary-dark);
        background: transparent;
        transition: all 0.3s;
    }

    .btn-outline-custom:hover {
        background: var(--secondary);
        color: var(--primary-dark);
        transform: translateY(-2px);
    }

    @media (max-width: 768px) {
        .case-header h1 {
            font-size: 1.8rem;
        }
        
        .stat-card h3 {
            font-size: 1.5rem;
        }
    }
</style>

<!-- Case Header -->
<div class="case-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <a href="cases.php" class="text-white text-decoration-none mb-2 d-inline-block">
                    <i class="fas fa-arrow-left"></i> Back to Cases
                </a>
                <h1 class="display-5 fw-bold"><?php echo htmlspecialchars($case['case_number']); ?></h1>
                <p class="lead mb-0"><?php echo htmlspecialchars($case['title']); ?></p>
            </div>
            <div class="col-md-4 text-md-end">
                <span class="status-badge status-<?php echo $case['status']; ?>">
                    <i class="fas fa-circle me-1"></i> <?php echo ucfirst($case['status']); ?>
                </span>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <!-- Alert Messages -->
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" style="background: #d4edda; border-left: 4px solid #10b981; border-radius: 12px;">
            <i class="fas fa-check-circle me-2"></i>
            <?php 
                if($_GET['msg'] == 'progress_added') echo "Progress note added successfully!";
                if($_GET['msg'] == 'status_updated') echo "Case status updated successfully!";
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistics Row -->
    <div class="row mb-4 mt-4">
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-gavel"></i>
                </div>
                <h3 style="color: var(--primary-dark);"><?php echo $case['total_hearings']; ?></h3>
                <p class="text-muted mb-0">Total Hearings</p>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <h3 style="color: var(--primary-dark);"><?php echo $case['total_documents']; ?></h3>
                <p class="text-muted mb-0">Documents</p>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3 style="color: var(--primary-dark);"><?php echo number_format($case['total_hours'], 1); ?></h3>
                <p class="text-muted mb-0">Billable Hours</p>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <h3 style="color: var(--primary-dark);"><?php echo date('M d, Y', strtotime($case['created_at'])); ?></h3>
                <p class="text-muted mb-0">Created Date</p>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <!-- Case Information -->
            <div class="info-card">
                <div class="card-header">
                    <h5><i class="fas fa-info-circle"></i> Case Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong><i class="fas fa-user" style="color: var(--secondary);"></i> Client:</strong><br>
                            <?php echo htmlspecialchars($case['client_name']); ?><br>
                            <small class="text-muted"><?php echo htmlspecialchars($case['client_email']); ?> | <?php echo htmlspecialchars($case['client_phone']); ?></small></p>
                            
                            <p><strong><i class="fas fa-user-tie" style="color: var(--secondary);"></i> Assigned Lawyer:</strong><br>
                            <?php echo htmlspecialchars($case['lawyer_name'] ?: 'Not Assigned'); ?><br>
                            <?php if($case['lawyer_email']): ?>
                                <small class="text-muted"><?php echo htmlspecialchars($case['lawyer_email']); ?></small>
                            <?php endif; ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><i class="fas fa-align-left" style="color: var(--secondary);"></i> Description:</strong><br>
                            <?php echo nl2br(htmlspecialchars($case['description'])); ?></p>
                            
                            <div class="mt-3">
                                <strong><i class="fas fa-chart-line" style="color: var(--secondary);"></i> Case Progress:</strong>
                                <div class="progress-status">
                                    <div class="progress-bar-fill" style="width: <?php echo $case['progress']; ?>%"></div>
                                </div>
                                <div class="text-end small"><?php echo $case['progress']; ?>% Complete</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Progress Timeline -->
            <div class="info-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5><i class="fas fa-history"></i> Progress Timeline</h5>
                    <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                        <button class="btn btn-primary-custom btn-sm" data-bs-toggle="modal" data-bs-target="#addProgressModal">
                            <i class="fas fa-plus"></i> Add Note
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if($progress_notes && $progress_notes->num_rows > 0): ?>
                        <div class="timeline">
                            <?php while($note = $progress_notes->fetch_assoc()): ?>
                                <div class="timeline-item">
                                    <div class="d-flex justify-content-between">
                                        <strong><?php echo date('M d, Y g:i A', strtotime($note['created_at'])); ?></strong>
                                        <small class="text-muted">By: <?php echo htmlspecialchars($note['user_name']); ?></small>
                                    </div>
                                    <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($note['note'])); ?></p>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center py-3">No progress notes yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Hearings -->
            <div class="info-card">
                <div class="card-header">
                    <h5><i class="fas fa-gavel"></i> Hearings</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Venue</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($hearings && $hearings->num_rows > 0): ?>
                                    <?php while($hearing = $hearings->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($hearing['hearing_date'])); ?></td>
                                            <td><?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($hearing['venue']); ?></td>
                                            <td><?php echo substr(htmlspecialchars($hearing['notes']), 0, 50); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted">No hearings scheduled</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="hearings.php?case_id=<?php echo $case_id; ?>" class="btn btn-outline-custom btn-sm mt-2">
                        <i class="fas fa-calendar-plus"></i> Schedule Hearing
                    </a>
                </div>
            </div>

            <!-- Documents -->
            <div class="info-card">
                <div class="card-header">
                    <h5><i class="fas fa-folder-open"></i> Documents</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>File Name</th>
                                    <th>Uploaded By</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($documents && $documents->num_rows > 0): ?>
                                    <?php while($doc = $documents->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($doc['file_name']); ?></td>
                                            <td><?php echo htmlspecialchars($doc['uploaded_by_name']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($doc['uploaded_at'])); ?></td>
                                            <td>
                                                <a href="<?php echo $doc['file_path']; ?>" download class="btn btn-sm btn-primary-custom">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                                <?php if($user_role != 'client'): ?>
                                                    <a href="documents.php?delete=<?php echo $doc['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this document?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted">No documents uploaded</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="documents.php?case_id=<?php echo $case_id; ?>" class="btn btn-outline-custom btn-sm mt-2">
                        <i class="fas fa-upload"></i> Upload Document
                    </a>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Update Status Card -->
            <?php if(in_array($user_role, ['admin', 'lawyer'])): ?>
                <div class="info-card">
                    <div class="card-header">
                        <h5><i class="fas fa-edit"></i> Update Status</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Case Status</label>
                                <select class="form-select" name="status">
                                    <option value="pending" <?php echo $case['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="active" <?php echo $case['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="closed" <?php echo $case['status'] == 'closed' ? 'selected' : ''; ?>>Closed</option>
                                    <option value="archived" <?php echo $case['status'] == 'archived' ? 'selected' : ''; ?>>Archived</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Progress (%)</label>
                                <input type="range" class="form-range" name="progress" min="0" max="100" value="<?php echo $case['progress']; ?>" oninput="this.nextElementSibling.value = this.value">
                                <output class="mt-2 d-block text-center"><?php echo $case['progress']; ?>%</output>
                            </div>
                            <button type="submit" name="update_status" class="btn btn-primary-custom w-100">Update Case</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Case Actions -->
            <div class="info-card">
                <div class="card-header">
                    <h5><i class="fas fa-cog"></i> Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <?php if($user_role == 'client'): ?>
                            <a href="messages.php?user=<?php echo $case['assigned_lawyer_id']; ?>" class="btn btn-outline-custom">
                                <i class="fas fa-envelope"></i> Message Lawyer
                            </a>
                            <a href="appointments.php?case_id=<?php echo $case_id; ?>" class="btn btn-outline-custom">
                                <i class="fas fa-calendar-check"></i> Book Appointment
                            </a>
                        <?php endif; ?>
                        
                        <?php if($user_role == 'lawyer'): ?>
                            <a href="timesheets.php?case_id=<?php echo $case_id; ?>" class="btn btn-outline-custom">
                                <i class="fas fa-clock"></i> Log Billable Hours
                            </a>
                        <?php endif; ?>
                        
                        <?php if(in_array($user_role, ['admin', 'lawyer', 'paralegal'])): ?>
                            <a href="edit_case.php?id=<?php echo $case_id; ?>" class="btn btn-outline-custom">
                                <i class="fas fa-edit"></i> Edit Case Details
                            </a>
                        <?php endif; ?>
                        
                        <?php if($user_role == 'admin'): ?>
                            <a href="delete_case.php?id=<?php echo $case_id; ?>" class="btn btn-outline-custom" style="border-color: #C72A2A; color: #C72A2A;" onclick="return confirm('Delete this case permanently?')">
                                <i class="fas fa-trash"></i> Delete Case
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Progress Modal -->
<div class="modal fade" id="addProgressModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #4A0E17, #6B1A2A); color: white;">
                <h5 class="modal-title"><i class="fas fa-plus-circle" style="color: #D4AF37;"></i> Add Progress Note</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <textarea class="form-control" name="progress_note" rows="5" placeholder="Enter case progress notes..." required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_progress" class="btn btn-primary-custom">Add Note</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php require_once 'includes/footer.php'; ?>