<?php
session_start();
require_once 'config/database.php';

$page_title = "All Cases & Hearings - ABT Law Firm";

// Get today's date
$today = date('Y-m-d');

// Get all upcoming hearings (today and future)
$query = "
    SELECT 
        h.*,
        c.case_number,
        c.title as case_title,
        c.description as case_description,
        c.status as case_status,
        c.progress as case_progress,
        cl.full_name as client_name,
        cl.email as client_email,
        cl.phone as client_phone,
        l.full_name as lawyer_name,
        l.email as lawyer_email
    FROM hearings h
    JOIN cases c ON h.case_id = c.id
    JOIN users cl ON c.client_id = cl.id
    LEFT JOIN users l ON c.assigned_lawyer_id = l.id
    WHERE h.hearing_date >= CURDATE()
    ORDER BY h.hearing_date ASC, h.hearing_time ASC
";

$hearings_result = $conn->query($query);

// Separate today's hearings and upcoming hearings
$today_hearings = [];
$upcoming_hearings = [];

if ($hearings_result && $hearings_result->num_rows > 0) {
    while ($hearing = $hearings_result->fetch_assoc()) {
        if ($hearing['hearing_date'] == $today) {
            $today_hearings[] = $hearing;
        } else {
            $upcoming_hearings[] = $hearing;
        }
    }
}

// Get recent past hearings (last 7 days)
$past_hearings_query = "
    SELECT 
        h.*,
        c.case_number,
        c.title as case_title,
        cl.full_name as client_name,
        l.full_name as lawyer_name
    FROM hearings h
    JOIN cases c ON h.case_id = c.id
    JOIN users cl ON c.client_id = cl.id
    LEFT JOIN users l ON c.assigned_lawyer_id = l.id
    WHERE h.hearing_date < CURDATE() 
    AND h.hearing_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ORDER BY h.hearing_date DESC
";
$past_hearings_result = $conn->query($past_hearings_query);

// Get statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_hearings,
        SUM(CASE WHEN hearing_date = CURDATE() THEN 1 ELSE 0 END) as today_hearings,
        SUM(CASE WHEN hearing_date > CURDATE() THEN 1 ELSE 0 END) as upcoming_hearings,
        SUM(CASE WHEN hearing_date < CURDATE() AND hearing_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as past_week_hearings
    FROM hearings
    WHERE hearing_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

require_once 'includes/header.php';
?>

<style>
    /* Full Page Background Image */
    body {
        background: url('https://images.pexels.com/photos/9129178/pexels-photo-9129178.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop') no-repeat center center fixed;
        background-size: cover;
        position: relative;
    }

    body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(253, 248, 240, 0.92);
        z-index: -1;
    }

    .hearings-page {
        background: transparent;
        min-height: 100vh;
        padding: 40px 0;
    }

    .page-header {
        background: linear-gradient(135deg, rgba(74, 14, 23, 0.95) 0%, rgba(107, 26, 42, 0.95) 100%);
        padding: 60px 0 40px;
        margin-bottom: 40px;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .page-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(212,175,55,0.05)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        background-size: cover;
        animation: wave 15s ease-in-out infinite;
    }

    @keyframes wave {
        0%, 100% { transform: translateX(0) translateY(0); }
        50% { transform: translateX(-5%) translateY(10px); }
    }

    .page-header h1 {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        position: relative;
        z-index: 2;
    }

    .page-header p {
        opacity: 0.9;
        font-size: 1.1rem;
        position: relative;
        z-index: 2;
    }

    /* Stats Cards - Slightly transparent */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 40px;
    }

    .stat-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        transition: transform 0.3s;
        backdrop-filter: blur(5px);
    }

    .stat-card:hover {
        transform: translateY(-5px);
        background: white;
    }

    .stat-card .stat-icon {
        width: 50px;
        height: 50px;
        background: rgba(212, 175, 55, 0.1);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
    }

    .stat-card .stat-icon i {
        font-size: 24px;
        color: var(--secondary);
    }

    .stat-card .stat-number {
        font-size: 32px;
        font-weight: 800;
        color: var(--primary-dark);
    }

    .stat-card .stat-label {
        color: #6c757d;
        font-size: 14px;
        margin-top: 5px;
    }

    /* Section Title */
    .section-title {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--secondary);
        display: inline-block;
        background: rgba(255,255,255,0.8);
        padding: 8px 20px;
        border-radius: 50px;
    }

    /* Hearing Cards - White with slight transparency */
    .hearing-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 16px;
        margin-bottom: 20px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        transition: all 0.3s;
        border-left: 4px solid transparent;
        backdrop-filter: blur(5px);
    }

    .hearing-card:hover {
        transform: translateX(5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        background: white;
    }

    .hearing-card.today {
        border-left-color: #ef4444;
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.98) 0%, rgba(255, 245, 245, 0.98) 100%);
    }

    .hearing-card.upcoming {
        border-left-color: var(--secondary);
    }

    .hearing-card-header {
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 15px;
        border-bottom: 1px solid #eef2f6;
    }

    .hearing-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 5px;
    }

    .hearing-case-number {
        font-size: 0.85rem;
        color: var(--secondary);
        font-weight: 600;
    }

    .hearing-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .badge-today {
        background: #ef4444;
        color: white;
    }

    .badge-upcoming {
        background: var(--secondary);
        color: var(--primary-dark);
    }

    .hearing-body {
        padding: 20px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
    }

    .info-item {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .info-icon {
        width: 35px;
        height: 35px;
        background: rgba(212, 175, 55, 0.1);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .info-icon i {
        color: var(--secondary);
        font-size: 1rem;
    }

    .info-content {
        flex: 1;
    }

    .info-label {
        font-size: 0.7rem;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .info-value {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--primary-dark);
    }

    .hearing-footer {
        padding: 15px 20px;
        background: rgba(248, 249, 250, 0.9);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
    }

    .btn-view {
        background: transparent;
        border: 1px solid var(--secondary);
        padding: 6px 16px;
        border-radius: 8px;
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--primary-dark);
        text-decoration: none;
        transition: all 0.3s;
    }

    .btn-view:hover {
        background: var(--secondary);
        color: var(--primary-dark);
        transform: translateY(-2px);
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 16px;
        backdrop-filter: blur(5px);
    }

    .empty-state i {
        font-size: 60px;
        color: var(--secondary);
        opacity: 0.3;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: var(--primary-dark);
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #6c757d;
    }

    /* Table Styles */
    .table-responsive {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 16px;
        overflow: hidden;
        backdrop-filter: blur(5px);
    }

    .table {
        margin-bottom: 0;
    }

    .table thead {
        background: var(--primary-dark);
        color: white;
    }

    .table tbody tr {
        transition: all 0.3s;
    }

    .table tbody tr:hover {
        background: rgba(212, 175, 55, 0.1);
    }

    @media (max-width: 768px) {
        .page-header h1 {
            font-size: 1.8rem;
        }
        
        .hearing-body {
            grid-template-columns: 1fr;
        }
        
        .hearing-card-header {
            flex-direction: column;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .section-title {
            font-size: 1.2rem;
        }
    }
</style>

<div class="page-header">
    <div class="container">
        <h1><i class="fas fa-gavel me-3" style="color: var(--secondary);"></i>All Hearings</h1>
        <p>Track all scheduled hearings - today, upcoming, and recent past hearings</p>
    </div>
</div>

<div class="hearings-page">
    <div class="container">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="stat-number"><?php echo $stats['today_hearings'] ?? 0; ?></div>
                <div class="stat-label">Today's Hearings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-week"></i>
                </div>
                <div class="stat-number"><?php echo $stats['upcoming_hearings'] ?? 0; ?></div>
                <div class="stat-label">Upcoming Hearings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-history"></i>
                </div>
                <div class="stat-number"><?php echo $stats['past_week_hearings'] ?? 0; ?></div>
                <div class="stat-label">Past 7 Days</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_hearings'] ?? 0; ?></div>
                <div class="stat-label">Total (Next 7 Days)</div>
            </div>
        </div>

        <!-- Today's Hearings Section -->
        <div class="mb-5">
            <h3 class="section-title">
                <i class="fas fa-sun me-2" style="color: var(--secondary);"></i>
                Today's Hearings
                <span class="badge ms-2" style="background: #ef4444; color: white;"><?php echo count($today_hearings); ?></span>
            </h3>
            
            <?php if (!empty($today_hearings)): ?>
                <?php foreach ($today_hearings as $hearing): ?>
                    <div class="hearing-card today">
                        <div class="hearing-card-header">
                            <div>
                                <div class="hearing-title">
                                    <?php echo htmlspecialchars($hearing['case_title']); ?>
                                </div>
                                <div class="hearing-case-number">
                                    Case #: <?php echo htmlspecialchars($hearing['case_number']); ?>
                                </div>
                            </div>
                            <div>
                                <span class="hearing-badge badge-today">
                                    <i class="fas fa-clock me-1"></i> TODAY
                                </span>
                            </div>
                        </div>
                        
                        <div class="hearing-body">
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-hourglass-half"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Time</div>
                                    <div class="info-value"><?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Venue</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['venue']); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-user-tie"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Lawyer</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['lawyer_name'] ?? 'Not Assigned'); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Client</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['client_name']); ?></div>
                                </div>
                            </div>
                            
                            <?php if ($hearing['hearing_type']): ?>
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Hearing Type</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['hearing_type']); ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="hearing-footer">
                            <a href="case_details.php?id=<?php echo $hearing['case_id']; ?>" class="btn-view">
                                <i class="fas fa-eye me-1"></i> View Case Details
                            </a>
                            <small class="text-muted">
                                <i class="fas fa-gavel"></i> Case Status: 
                                <span class="badge" style="background: <?php echo $hearing['case_status'] == 'active' ? '#10b981' : ($hearing['case_status'] == 'pending' ? '#f59e0b' : '#6c757d'); ?>; color: white;">
                                    <?php echo ucfirst($hearing['case_status']); ?>
                                </span>
                            </small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-check"></i>
                    <h4>No Hearings Today</h4>
                    <p>No hearings scheduled for today. Enjoy your day!</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Upcoming Hearings Section -->
        <div class="mb-5">
            <h3 class="section-title">
                <i class="fas fa-calendar-alt me-2" style="color: var(--secondary);"></i>
                Upcoming Hearings
                <span class="badge ms-2" style="background: var(--secondary); color: var(--primary-dark);"><?php echo count($upcoming_hearings); ?></span>
            </h3>
            
            <?php if (!empty($upcoming_hearings)): ?>
                <?php foreach ($upcoming_hearings as $hearing): ?>
                    <?php
                    $days_left = ceil((strtotime($hearing['hearing_date']) - time()) / (60 * 60 * 24));
                    $day_text = '';
                    if ($days_left == 1) $day_text = 'Tomorrow';
                    elseif ($days_left <= 7) $day_text = $days_left . ' days left';
                    else $day_text = date('M d, Y', strtotime($hearing['hearing_date']));
                    ?>
                    <div class="hearing-card upcoming">
                        <div class="hearing-card-header">
                            <div>
                                <div class="hearing-title">
                                    <?php echo htmlspecialchars($hearing['case_title']); ?>
                                </div>
                                <div class="hearing-case-number">
                                    Case #: <?php echo htmlspecialchars($hearing['case_number']); ?>
                                </div>
                            </div>
                            <div>
                                <span class="hearing-badge badge-upcoming">
                                    <i class="fas fa-calendar me-1"></i> <?php echo $day_text; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="hearing-body">
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-calendar-day"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Date</div>
                                    <div class="info-value"><?php echo date('l, F j, Y', strtotime($hearing['hearing_date'])); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-hourglass-half"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Time</div>
                                    <div class="info-value"><?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Venue</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['venue']); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-user-tie"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Lawyer</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['lawyer_name'] ?? 'Not Assigned'); ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Client</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['client_name']); ?></div>
                                </div>
                            </div>
                            
                            <?php if ($hearing['hearing_type']): ?>
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Hearing Type</div>
                                    <div class="info-value"><?php echo htmlspecialchars($hearing['hearing_type']); ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="hearing-footer">
                            <a href="case_details.php?id=<?php echo $hearing['case_id']; ?>" class="btn-view">
                                <i class="fas fa-eye me-1"></i> View Case Details
                            </a>
                            <?php if ($hearing['case_progress'] > 0): ?>
                            <small class="text-muted">
                                <i class="fas fa-chart-line"></i> Case Progress: <?php echo $hearing['case_progress']; ?>%
                            </small>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-plus"></i>
                    <h4>No Upcoming Hearings</h4>
                    <p>No future hearings scheduled at this time.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Recent Past Hearings Section -->
        <?php if ($past_hearings_result && $past_hearings_result->num_rows > 0): ?>
        <div class="mb-5">
            <h3 class="section-title">
                <i class="fas fa-history me-2" style="color: var(--secondary);"></i>
                Recent Hearings (Last 7 Days)
            </h3>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Case Number</th>
                            <th>Case Title</th>
                            <th>Client</th>
                            <th>Lawyer</th>
                            <th>Time</th>
                            <th>Venue</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($hearing = $past_hearings_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date('M d, Y', strtotime($hearing['hearing_date'])); ?></td>
                            <td><strong><?php echo htmlspecialchars($hearing['case_number']); ?></strong></td>
                            <td><?php echo htmlspecialchars(substr($hearing['case_title'], 0, 30)); ?></td>
                            <td><?php echo htmlspecialchars($hearing['client_name']); ?></td>
                            <td><?php echo htmlspecialchars($hearing['lawyer_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('g:i A', strtotime($hearing['hearing_time'])); ?></td>
                            <td><?php echo htmlspecialchars(substr($hearing['venue'], 0, 20)); ?></td>
                            <td>
                                <a href="case_details.php?id=<?php echo $hearing['case_id']; ?>" class="btn-view" style="padding: 4px 12px; font-size: 0.75rem;">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>