<?php
// Complete Hero Section for Law Firm Website
// File: hero_home.php - To be included after header.php

// Configuration array for dynamic content
$heroConfig = [
    'badge_text' => 'Top Rated Law Firm 2026',
    'badge_icon' => 'fa-gavel',
    'title_first' => 'Justice isn\'t just a word,',
    'title_highlight' => 'our mission',
    'description' => 'With over 50 years of combined experience, our award-winning attorneys deliver exceptional results for clients nationwide. We fight for your rights with integrity, excellence, and unwavering dedication.',
    'btn_primary_text' => 'Free Consultation',
    'btn_primary_icon' => 'fa-calendar-check',
    'btn_secondary_text' => 'Explore Services',
    'btn_secondary_icon' => 'fa-play-circle',
    'stats' => [
        ['value' => 5000, 'label' => 'Cases Won', 'suffix' => '+'],
        ['value' => 98, 'label' => 'Success Rate', 'suffix' => '%'],
        ['value' => 50, 'label' => 'Expert Lawyers', 'suffix' => '+']
    ],
    'hero_image' => 'https://images.pexels.com/photos/5669602/pexels-photo-5669602.jpeg',
    'bg_image' => 'https://images.pexels.com/photos/7648022/pexels-photo-7648022.jpeg',
    'contact_phone' => '+1 (888) 123-4567'
];
?>

<style>
/* ==================== HERO SECTION STYLES ==================== */
.hero-section {
    min-height: 90vh;
    position: relative;
    display: flex;
    align-items: center;
    overflow: hidden;
    margin-top: 0;
}

/* Background Image with NO FADE - Fully visible */
.hero-bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: url('<?php echo $heroConfig['bg_image']; ?>');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    z-index: 0;
    /* NO opacity - image is 100% visible */
}

/* Light Gradient Overlay - Only to make text readable, NOT to fade the image */
.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, 
        rgba(74, 14, 23, 0.85) 0%,
        rgba(107, 26, 42, 0.8) 40%,
        rgba(139, 38, 53, 0.75) 100%);
    z-index: 1;
}

/* Gold Pattern Overlay - Very subtle */
.hero-pattern {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" opacity="0.05"><path fill="none" stroke="%23D4AF37" stroke-width="0.5" d="M10,10 L90,10 M10,30 L90,30 M10,50 L90,50 M10,70 L90,70 M10,90 L90,90 M10,10 L10,90 M30,10 L30,90 M50,10 L50,90 M70,10 L70,90 M90,10 L90,90"/><circle cx="50" cy="50" r="8" fill="none" stroke="%23D4AF37" stroke-width="0.5"/><circle cx="50" cy="50" r="4" fill="%23D4AF37" opacity="0.2"/></svg>');
    background-repeat: repeat;
    background-size: 60px;
    z-index: 1;
    pointer-events: none;
}

/* Animated Particles - Subtle */
.particles-container {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 1;
    overflow: hidden;
    pointer-events: none;
}

.particle {
    position: absolute;
    background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
    border-radius: 50%;
    opacity: 0.1;
    animation: floatParticle linear infinite;
    pointer-events: none;
}

@keyframes floatParticle {
    0% {
        transform: translateY(100vh) translateX(0) rotate(0deg);
        opacity: 0;
    }
    10% {
        opacity: 0.15;
    }
    90% {
        opacity: 0.15;
    }
    100% {
        transform: translateY(-20vh) translateX(100px) rotate(360deg);
        opacity: 0;
    }
}

/* Wave Divider - Semi-transparent */
.hero-wave {
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 100%;
    overflow: hidden;
    line-height: 0;
    z-index: 2;
}

.hero-wave svg {
    position: relative;
    display: block;
    width: calc(100% + 1.3px);
    height: 80px;
}

/* Content Container */
.hero-container {
    position: relative;
    z-index: 3;
    width: 100%;
    padding: 80px 0 60px;
}

@media (max-width: 768px) {
    .hero-container {
        padding: 60px 0 40px;
        text-align: center;
    }
    .hero-wave svg {
        height: 50px;
    }
}

/* Badge */
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(212, 175, 55, 0.15);
    backdrop-filter: blur(10px);
    padding: 0.6rem 1.8rem;
    border-radius: 60px;
    font-size: 0.85rem;
    font-weight: 600;
    letter-spacing: 0.5px;
    color: var(--secondary);
    margin-bottom: 1.8rem;
    border: 1px solid rgba(212, 175, 55, 0.3);
    transition: all 0.3s ease;
}

.hero-badge i {
    font-size: 0.9rem;
}

.hero-badge:hover {
    background: rgba(212, 175, 55, 0.25);
    border-color: rgba(212, 175, 55, 0.5);
    transform: translateY(-2px);
}

/* Title Styles */
.hero-title {
    font-family: 'Plus Jakarta Sans', sans-serif;
    font-size: 4.2rem;
    font-weight: 800;
    line-height: 1.1;
    margin-bottom: 1.2rem;
    color: #ffffff;
    letter-spacing: -0.02em;
}

.hero-title .highlight {
    color: var(--secondary);
    position: relative;
    display: inline-block;
}

.hero-title .highlight::after {
    content: '';
    position: absolute;
    bottom: 8px;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, var(--secondary), transparent);
    border-radius: 2px;
}

@media (max-width: 992px) {
    .hero-title {
        font-size: 3rem;
    }
}

@media (max-width: 768px) {
    .hero-title {
        font-size: 2.2rem;
    }
    .hero-title .highlight::after {
        bottom: 4px;
    }
}

/* Description */
.hero-description {
    font-size: 1.1rem;
    line-height: 1.6;
    color: rgba(255, 255, 255, 0.9);
    margin-bottom: 2rem;
    max-width: 90%;
}

@media (max-width: 768px) {
    .hero-description {
        max-width: 100%;
        font-size: 1rem;
    }
}

/* Buttons */
.hero-btn-primary {
    background: linear-gradient(135deg, var(--secondary) 0%, var(--secondary-light) 50%, var(--secondary) 100%);
    background-size: 200% auto;
    border: none;
    padding: 14px 36px;
    border-radius: 50px;
    font-weight: 700;
    font-size: 1rem;
    color: var(--primary-dark);
    transition: all 0.4s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 5px 20px rgba(212, 175, 55, 0.3);
    position: relative;
    overflow: hidden;
    text-decoration: none;
}

.hero-btn-primary:hover {
    background-position: right center;
    transform: translateY(-3px);
    box-shadow: 0 12px 30px rgba(212, 175, 55, 0.4);
    color: var(--primary-dark);
}

.hero-btn-outline {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(8px);
    border: 1.5px solid var(--secondary);
    padding: 12px 34px;
    border-radius: 50px;
    font-weight: 600;
    font-size: 1rem;
    color: #ffffff;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
}

.hero-btn-outline:hover {
    background: var(--secondary);
    color: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
}

/* Stats Cards */
.hero-stat-card {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(8px);
    border-radius: 20px;
    padding: 15px 10px;
    text-align: center;
    border: 1px solid rgba(212, 175, 55, 0.15);
    transition: all 0.3s ease;
}

.hero-stat-card:hover {
    background: rgba(212, 175, 55, 0.15);
    border-color: rgba(212, 175, 55, 0.35);
    transform: translateY(-5px);
}

.hero-stat-number {
    font-size: 2.4rem;
    font-weight: 800;
    color: var(--secondary);
    display: block;
    line-height: 1;
    font-family: 'Plus Jakarta Sans', monospace;
}

.hero-stat-label {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.85rem;
    font-weight: 500;
    margin-top: 8px;
    letter-spacing: 0.5px;
}

/* Hero Image Frame */
.hero-image-frame {
    position: relative;
    border-radius: 30px;
    overflow: hidden;
    box-shadow: 0 30px 50px rgba(0, 0, 0, 0.3);
}

.hero-image-frame img {
    width: 100%;
    height: auto;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.hero-image-frame:hover img {
    transform: scale(1.03);
}

.hero-image-frame::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(212, 175, 55, 0.1), transparent 70%);
    z-index: 1;
    pointer-events: none;
}

/* Gold Border Animation */
.hero-gold-border {
    position: absolute;
    top: -15px;
    left: -15px;
    right: -15px;
    bottom: -15px;
    border: 2px solid rgba(212, 175, 55, 0.3);
    border-radius: 40px;
    z-index: -1;
    animation: borderPulse 3s infinite;
}

@keyframes borderPulse {
    0%, 100% { opacity: 0.3; transform: scale(1); }
    50% { opacity: 0.6; transform: scale(1.01); }
}

/* Floating Animation */
@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-15px); }
}

.hero-float-animation {
    animation: float 6s ease-in-out infinite;
}

/* Trust Badge */
.hero-trust-badge {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.hero-trust-stars i {
    color: var(--secondary);
    font-size: 0.8rem;
    margin-right: 2px;
}

.hero-trust-text {
    font-size: 0.75rem;
    color: rgba(255, 255, 255, 0.7);
}

@media (max-width: 768px) {
    .hero-trust-badge {
        justify-content: center;
    }
}

/* Scroll Reveal Animation */
.hero-fade-up {
    opacity: 0;
    transform: translateY(30px);
    transition: all 0.8s cubic-bezier(0.2, 0.9, 0.4, 1.1);
}

.hero-fade-up.revealed {
    opacity: 1;
    transform: translateY(0);
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .hero-image-frame {
        margin-top: 40px;
    }
}

/* Button Ripple Effect */
.hero-btn-primary, .hero-btn-outline {
    position: relative;
    overflow: hidden;
}

.ripple-effect {
    position: absolute;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.4);
    transform: scale(0);
    animation: rippleAnim 0.6s linear forwards;
    pointer-events: none;
}

@keyframes rippleAnim {
    to {
        transform: scale(4);
        opacity: 0;
    }
}
</style>

<!-- Hero Section Start -->
<section class="hero-section">
    <!-- Background Image - FULLY VISIBLE, NO FADE -->
    <div class="hero-bg"></div>
    
    <!-- Gradient Overlay - Only for text readability, NOT fading the image -->
    <div class="hero-overlay"></div>
    
    <!-- Pattern Overlay - Very subtle -->
    <div class="hero-pattern"></div>
    
    <!-- Animated Particles -->
    <div class="particles-container" id="heroParticlesContainer"></div>
    
    <!-- Wave Divider -->
    <div class="hero-wave">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C45.52,108.92,100,115.28,144.47,110.86c58.41-5.81,110.5-35.27,176.92-54.42Z" 
                  fill="rgba(212,175,55,0.08)"></path>
        </svg>
    </div>
    
    <div class="container hero-container">
        <div class="row align-items-center">
            <!-- Left Content -->
            <div class="col-lg-7 hero-fade-up" data-delay="0">
                <!-- Badge -->
                <div class="hero-badge" data-aos="fade-up" data-aos-duration="800">
                    <i class="fas <?php echo $heroConfig['badge_icon']; ?>"></i>
                    <span><?php echo $heroConfig['badge_text']; ?></span>
                    <i class="fas fa-star-of-life"></i>
                </div>
                
                <!-- Title -->
                <h1 class="hero-title" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <?php echo $heroConfig['title_first']; ?><br>
                    It's <span class="highlight"><?php echo $heroConfig['title_highlight']; ?></span>
                </h1>
                
                <!-- Description -->
                <p class="hero-description" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <?php echo $heroConfig['description']; ?>
                </p>
                
                <!-- Buttons -->
                <div class="d-flex gap-3 flex-wrap mb-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <a href="register.php" class="hero-btn-primary">
                        <i class="fas <?php echo $heroConfig['btn_primary_icon']; ?>"></i>
                        <?php echo $heroConfig['btn_primary_text']; ?>
                    </a>
                    <a href="practice.php" class="hero-btn-outline">
                        <i class="fas <?php echo $heroConfig['btn_secondary_icon']; ?>"></i>
                        <?php echo $heroConfig['btn_secondary_text']; ?>
                    </a>
                </div>
                
                <!-- Statistics -->
                <div class="row g-3 mt-2">
                    <?php foreach ($heroConfig['stats'] as $index => $stat): ?>
                    <div class="col-4" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="<?php echo 400 + ($index * 100); ?>">
                        <div class="hero-stat-card">
                            <span class="hero-stat-number hero-counter" data-target="<?php echo $stat['value']; ?>" 
                                  data-suffix="<?php echo $stat['suffix']; ?>">0</span>
                            <p class="hero-stat-label"><?php echo $stat['label']; ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Trust Badge -->
                <div class="hero-trust-badge mt-4" data-aos="fade-up" data-aos-duration="600" data-aos-delay="700">
                    <div class="hero-trust-stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="hero-trust-text">
                        Rated 5.0 ★ by 1,500+ clients • 98% Recommended
                    </div>
                </div>
            </div>
            
            <!-- Right Image -->
            <div class="col-lg-5 d-none d-lg-block hero-fade-up" data-delay="200">
                <div class="hero-image-frame hero-float-animation" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="300">
                    <div class="hero-gold-border"></div>
                    <img src="<?php echo $heroConfig['hero_image']; ?>" 
                         alt="Senior Attorney at Law Firm" 
                         class="img-fluid rounded-4"
                         loading="lazy">
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Hero Section Specific JavaScript

// Create Floating Particles
function createHeroParticles() {
    const container = document.getElementById('heroParticlesContainer');
    if (!container) return;
    
    const particleCount = 20;
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        const size = Math.random() * 4 + 1;
        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 15 + 's';
        particle.style.animationDuration = Math.random() * 12 + 8 + 's';
        container.appendChild(particle);
    }
}

// Hero Counter Animation
function initHeroCounters() {
    const counters = document.querySelectorAll('.hero-counter');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-target'));
                const suffix = counter.getAttribute('data-suffix') || '';
                let current = 0;
                const duration = 2000;
                const stepTime = 20;
                const steps = duration / stepTime;
                const increment = target / steps;
                
                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.textContent = Math.floor(current);
                        setTimeout(updateCounter, stepTime);
                    } else {
                        counter.textContent = target + suffix;
                    }
                };
                
                updateCounter();
                observer.unobserve(counter);
            }
        });
    }, { threshold: 0.4 });
    
    counters.forEach(counter => observer.observe(counter));
}

// Hero Scroll Reveal Animation
function initHeroScrollReveal() {
    const fadeElements = document.querySelectorAll('.hero-fade-up');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });
    
    fadeElements.forEach(el => {
        const delay = el.getAttribute('data-delay') || 0;
        if (delay > 0) {
            setTimeout(() => {
                revealObserver.observe(el);
            }, parseInt(delay));
        } else {
            revealObserver.observe(el);
        }
    });
}

// Initialize all hero functions when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    createHeroParticles();
    initHeroCounters();
    initHeroScrollReveal();
});
</script>