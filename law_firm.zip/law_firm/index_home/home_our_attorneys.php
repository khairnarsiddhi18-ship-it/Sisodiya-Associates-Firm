<!-- Attorneys Section -->
<section class="attorneys-section">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge-custom">Our Team</span>
            <h2 class="section-title">Meet Our <span>Attorneys</span></h2>
            <p class="section-subtitle">Dedicated professionals committed to your success</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-4 scroll-reveal">
                <div class="attorney-card">
                    <div class="attorney-image">
                        <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Attorney">
                    </div>
                    <div class="attorney-info">
                        <h4>John Anderson</h4>
                        <p class="attorney-title">Senior Partner</p>
                        <p class="attorney-bio">Harvard Law Graduate, 20+ years</p>
                        <div class="social-links">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="100">
                <div class="attorney-card">
                    <div class="attorney-image">
                        <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Attorney">
                    </div>
                    <div class="attorney-info">
                        <h4>Sarah Williams</h4>
                        <p class="attorney-title">Managing Partner</p>
                        <p class="attorney-bio">Yale Law School, 15+ years</p>
                        <div class="social-links">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="200">
                <div class="attorney-card">
                    <div class="attorney-image">
                        <img src="https://randomuser.me/api/portraits/men/52.jpg" alt="Attorney">
                    </div>
                    <div class="attorney-info">
                        <h4>Michael Chen</h4>
                        <p class="attorney-title">Criminal Defense</p>
                        <p class="attorney-bio">Former Prosecutor, 15+ years</p>
                        <div class="social-links">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-5">
            <a href="attorneys.php" class="btn-view-all">View All Attorneys →</a>
        </div>
    </div>
</section>

<style>
.attorneys-section {
    padding: 80px 0;
    background: #FDF8F0;
}

.badge-custom {
    background: rgba(212, 175, 55, 0.1);
    color: #D4AF37;
    padding: 6px 18px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 15px;
}

.section-title {
    font-size: 2.8rem;
    font-weight: 800;
    color: #4A0E17;
    margin-bottom: 15px;
}

.section-title span {
    color: #D4AF37;
}

.section-subtitle {
    color: #6c757d;
    font-size: 1.1rem;
}

.attorney-card {
    border-radius: 20px;
    overflow: hidden;
    background: white;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    transition: all 0.3s;
}

.attorney-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.12);
}

.attorney-image {
    height: 280px;
    overflow: hidden;
}

.attorney-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s;
}

.attorney-card:hover .attorney-image img {
    transform: scale(1.05);
}

.attorney-info {
    padding: 20px;
    text-align: center;
}

.attorney-info h4 {
    font-size: 1.3rem;
    font-weight: 700;
    color: #4A0E17;
    margin-bottom: 5px;
}

.attorney-title {
    color: #D4AF37;
    font-weight: 600;
    margin-bottom: 8px;
}

.attorney-bio {
    color: #6c757d;
    font-size: 0.85rem;
    margin-bottom: 15px;
}

.social-links a {
    display: inline-block;
    width: 35px;
    height: 35px;
    background: rgba(212, 175, 55, 0.1);
    border-radius: 50%;
    line-height: 35px;
    text-align: center;
    color: #D4AF37;
    margin: 0 5px;
    transition: all 0.3s;
}

.social-links a:hover {
    background: #D4AF37;
    color: #4A0E17;
    transform: translateY(-3px);
}

.btn-view-all {
    background: linear-gradient(135deg, #D4AF37, #F5D76E);
    border: none;
    padding: 12px 30px;
    border-radius: 50px;
    font-weight: 600;
    color: #4A0E17;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-view-all:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
    color: #4A0E17;
}

@media (max-width: 768px) {
    .attorneys-section {
        padding: 50px 0;
    }
    .section-title {
        font-size: 2rem;
    }
}
</style>