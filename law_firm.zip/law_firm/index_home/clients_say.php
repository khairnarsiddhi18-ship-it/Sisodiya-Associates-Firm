<!-- Testimonials Section -->
<section class="testimonials-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="testimonials-title">What Our <span>Clients</span> Say</h2>
            <p class="testimonials-subtitle">Trusted by thousands of satisfied clients</p>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 scroll-reveal">
                <div class="testimonial-card">
                    <i class="fas fa-quote-left quote-icon"></i>
                    <div class="stars">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p>"Excellent service! They handled my case with utmost professionalism and got me the best possible outcome."</p>
                    <div class="client-info">
                        <img src="https://randomuser.me/api/portraits/women/2.jpg" alt="Client">
                        <div>
                            <h6>Emily Rodriguez</h6>
                            <span>Corporate Client</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="100">
                <div class="testimonial-card">
                    <i class="fas fa-quote-left quote-icon"></i>
                    <div class="stars">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p>"The team at ABT Law Firm is exceptional. They guided me through every step of my real estate transaction."</p>
                    <div class="client-info">
                        <img src="https://randomuser.me/api/portraits/men/3.jpg" alt="Client">
                        <div>
                            <h6>David Thompson</h6>
                            <span>Real Estate Client</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="200">
                <div class="testimonial-card">
                    <i class="fas fa-quote-left quote-icon"></i>
                    <div class="stars">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p>"Highly recommend! They won my case and the communication throughout was outstanding."</p>
                    <div class="client-info">
                        <img src="https://randomuser.me/api/portraits/men/4.jpg" alt="Client">
                        <div>
                            <h6>Robert Martinez</h6>
                            <span>Personal Injury</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.testimonials-section {
    padding: 80px 0;
    background: linear-gradient(135deg, #4A0E17, #6B1A2A);
}

.testimonials-title {
    font-size: 2.8rem;
    font-weight: 800;
    color: white;
    margin-bottom: 15px;
}

.testimonials-title span {
    color: #D4AF37;
}

.testimonials-subtitle {
    color: rgba(255,255,255,0.7);
    font-size: 1.1rem;
}

.testimonial-card {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    height: 100%;
    transition: all 0.3s;
}

.testimonial-card:hover {
    transform: translateY(-5px);
}

.quote-icon {
    color: #D4AF37;
    font-size: 2rem;
    opacity: 0.3;
    margin-bottom: 1rem;
    display: block;
}

.stars {
    margin-bottom: 1rem;
}

.stars i {
    color: #f5b042;
    margin-right: 3px;
}

.testimonial-card p {
    color: #4a5568;
    line-height: 1.6;
    margin-bottom: 1.5rem;
}

.client-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.client-info img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
}

.client-info h6 {
    color: #4A0E17;
    font-weight: 700;
    margin-bottom: 3px;
}

.client-info span {
    color: #6c757d;
    font-size: 0.8rem;
}

@media (max-width: 768px) {
    .testimonials-section {
        padding: 50px 0;
    }
    .testimonials-title {
        font-size: 2rem;
    }
    .testimonial-card {
        padding: 1.5rem;
    }
}
</style>