<!-- CTA Section -->
<section class="cta-section">
    <div class="container text-center">
        <h2 class="cta-title">Need Legal Assistance?</h2>
        <p class="cta-text">Schedule a free consultation with our expert attorneys today</p>
        <div class="cta-buttons">
            <a href="register.php" class="btn-cta-primary">Get Free Consultation</a>
            <a href="contact.php" class="btn-cta-outline">Contact Us Now</a>
        </div>
    </div>
</section>

<style>
.cta-section {
    padding: 70px 0;
    background: linear-gradient(135deg, #4A0E17, #6B1A2A);
}

.cta-title {
    font-size: 2.8rem;
    font-weight: 800;
    color: white;
    margin-bottom: 15px;
}

.cta-text {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 30px;
}

.cta-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

.btn-cta-primary {
    background: linear-gradient(135deg, #D4AF37, #F5D76E);
    border: none;
    padding: 12px 30px;
    border-radius: 50px;
    font-weight: 600;
    color: #4A0E17;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-cta-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
    color: #4A0E17;
}

.btn-cta-outline {
    background: transparent;
    border: 1.5px solid #D4AF37;
    padding: 10px 28px;
    border-radius: 50px;
    font-weight: 600;
    color: white;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-cta-outline:hover {
    background: #D4AF37;
    color: #4A0E17;
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    .cta-section {
        padding: 50px 0;
    }
    .cta-title {
        font-size: 2rem;
    }
}
</style>