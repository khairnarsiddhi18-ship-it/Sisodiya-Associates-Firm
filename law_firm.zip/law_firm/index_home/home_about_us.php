<!-- About Section -->
<section class="about-us-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6 scroll-reveal">
               <img src="assets/court.jpg" 
     alt="Courtroom" 
     class="about-image" 
     style="background-color: #4A0E17;"
     onerror="this.src='https://placehold.co/600x450/4A0E17/D4AF37?text=Law+Office'">            
            </div>
            <div class="col-lg-6 scroll-reveal">
                <span class="badge-custom">About Us</span>
                <h2 class="about-title">Trusted Legal <span>Advisors</span> Since 1998</h2>
                <p class="about-lead">At ABT Law Firm, we combine legal expertise with personalized attention to deliver the best possible outcomes for our clients.</p>
                <p class="about-text">Our team of experienced attorneys is dedicated to providing exceptional legal representation across multiple practice areas.</p>
                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <div class="about-stats">
                            <i class="fas fa-check-circle"></i>
                            <div>
                                <strong>99% Success Rate</strong>
                                <p>In resolved cases</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="about-stats">
                            <i class="fas fa-users"></i>
                            <div>
                                <strong>50+ Experts</strong>
                                <p>Dedicated attorneys</p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="attorneys.php" class="btn-about">Meet Our Team →</a>
            </div>
        </div>
    </div>
</section>

<style>
.about-us-section {
    padding: 80px 0;
    background: white;
}

.badge-custom {
    background: rgba(212, 175, 55, 0.1);
    color: #D4AF37;
    padding: 6px 18px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 15px;
}

.about-title {
    font-size: 2.8rem;
    font-weight: 800;
    color: #4A0E17;
    margin-bottom: 20px;
}

.about-title span {
    color: #D4AF37;
}

.about-lead {
    font-size: 1.1rem;
    font-weight: 500;
    color: #4A0E17;
    margin-bottom: 20px;
}

.about-text {
    color: #6c757d;
    margin-bottom: 25px;
}

.about-stats {
    display: flex;
    align-items: center;
    gap: 15px;
}

.about-stats i {
    font-size: 1.5rem;
    color: #D4AF37;
}

.about-stats strong {
    display: block;
    color: #4A0E17;
    font-size: 1rem;
}

.about-stats p {
    margin: 0;
    font-size: 0.8rem;
    color: #6c757d;
}

.btn-about {
    background: linear-gradient(135deg, #D4AF37, #F5D76E);
    border: none;
    padding: 12px 30px;
    border-radius: 50px;
    font-weight: 600;
    color: #4A0E17;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-about:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
    color: #4A0E17;
}

.about-image {
    width: 100%;
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .about-us-section {
        padding: 50px 0;
    }
    .about-title {
        font-size: 2rem;
    }
}
</style>