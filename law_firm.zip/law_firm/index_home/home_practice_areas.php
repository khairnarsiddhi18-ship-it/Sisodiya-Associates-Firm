<!-- Practice Areas Section -->
<section class="practice-areas-section">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge-custom">What We Do</span>
            <h2 class="section-title">Our Practice <span>Areas</span></h2>
            <p class="section-subtitle">Comprehensive legal services tailored to your needs</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-4 scroll-reveal">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-balance-scale"></i></div>
                    <h4>Corporate Law</h4>
                    <p>Expert guidance for mergers, acquisitions, and business formation.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="100">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-home"></i></div>
                    <h4>Real Estate</h4>
                    <p>Property disputes, contracts, and smooth transactions.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="200">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-user-md"></i></div>
                    <h4>Medical Malpractice</h4>
                    <p>Protecting patient rights in negligence cases.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="300">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-gavel"></i></div>
                    <h4>Criminal Defense</h4>
                    <p>Aggressive representation for criminal cases.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="400">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-hand-holding-heart"></i></div>
                    <h4>Family Law</h4>
                    <p>Compassionate handling of divorce and custody.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 scroll-reveal" data-aos-delay="500">
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-passport"></i></div>
                    <h4>Immigration Law</h4>
                    <p>Expert visa and citizenship guidance.</p>
                    <a href="#" class="learn-more">Learn More →</a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.practice-areas-section {
    padding: 80px 0;
    background: #FDF8F0;
}

.badge-custom {
    background: rgba(212, 175, 55, 0.1);
    color: #D4AF37;
    padding: 6px 18px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 15px;
}

.section-title {
    font-size: 2.8rem;
    font-weight: 800;
    color: #4A0E17;
    margin-bottom: 15px;
}

.section-title span {
    color: #D4AF37;
}

.section-subtitle {
    color: #6c757d;
    font-size: 1.1rem;
}

.service-card {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    text-align: center;
    transition: all 0.3s;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    height: 100%;
    border-bottom: 3px solid transparent;
}

.service-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.1);
    border-bottom-color: #D4AF37;
}

.service-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, #D4AF37, #F5D76E);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.2rem;
}

.service-icon i {
    font-size: 2rem;
    color: #4A0E17;
}

.service-card h4 {
    font-size: 1.3rem;
    font-weight: 700;
    color: #4A0E17;
    margin-bottom: 15px;
}

.service-card p {
    color: #6c757d;
    margin-bottom: 20px;
}

.learn-more {
    color: #D4AF37;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
}

.learn-more:hover {
    color: #4A0E17;
}

@media (max-width: 768px) {
    .practice-areas-section {
        padding: 50px 0;
    }
    .section-title {
        font-size: 2rem;
    }
    .service-card {
        padding: 1.5rem;
    }
}
</style>