<?php
require_once 'config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $full_name = $_POST['full_name'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $phone = $_POST['phone'];
    
    // Validate password strength
    $password_strength = $_POST['password'];
    if (strlen($password_strength) < 6) {
        $error = "Password must be at least 6 characters long!";
    } else {
        // Check if user exists
        $check = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $check->bind_param("ss", $email, $username);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = "Username or email already exists!";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name, role, phone, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmt->bind_param("ssssss", $username, $email, $password, $full_name, $role, $phone);
            
            if ($stmt->execute()) {
                $success = "Registration successful! Please login.";
                echo '<script>setTimeout(function(){ window.location.href = "login.php?registered=1"; }, 2000);</script>';
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | ABT Law Firm</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 50%, #8B2635 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background */
        body::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            top: -50%;
            left: -50%;
            background: radial-gradient(circle, rgba(212,175,55,0.08) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: moveBackground 20s linear infinite;
            pointer-events: none;
        }

        @keyframes moveBackground {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        /* Floating Shapes */
        .shape {
            position: absolute;
            filter: blur(60px);
            opacity: 0.3;
            animation: float 10s ease-in-out infinite;
        }

        .shape-1 {
            top: 10%;
            left: 5%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, #D4AF37, #F5D76E);
            border-radius: 50%;
        }

        .shape-2 {
            bottom: 10%;
            right: 5%;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, #C72A2A, #8B2635);
            border-radius: 50%;
            animation-delay: -5s;
        }

        .shape-3 {
            top: 50%;
            right: 20%;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, #D4AF37, #F5D76E);
            border-radius: 50%;
            animation-delay: -3s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(10deg); }
        }

        /* Main Container */
        .register-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            position: relative;
            z-index: 1;
        }

        /* Register Card */
        .register-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            overflow: hidden;
            width: 100%;
            max-width: 550px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: slideUp 0.6s ease-out;
        }

        .register-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 30px 60px -12px rgba(0, 0, 0, 0.3);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card Header - Burgundy Theme */
        .card-header-custom {
            background: linear-gradient(135deg, #4A0E17 0%, #6B1A2A 100%);
            padding: 30px 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .card-header-custom::before {
            content: '⚖️';
            position: absolute;
            font-size: 120px;
            right: -20px;
            bottom: -40px;
            opacity: 0.1;
            transform: rotate(-15deg);
        }

        .logo-icon {
            width: 70px;
            height: 70px;
            background: rgba(212, 175, 55, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .logo-icon i {
            font-size: 32px;
            color: #D4AF37;
        }

        .card-header-custom h2 {
            color: white;
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .card-header-custom p {
            color: rgba(255, 255, 255, 0.9);
            font-size: 13px;
            margin: 0;
        }

        /* Card Body */
        .card-body-custom {
            padding: 35px 40px;
        }

        /* Form Groups */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #4A0E17;
            font-size: 13px;
        }

        .form-group label i {
            margin-right: 6px;
            color: #D4AF37;
            font-size: 12px;
        }

        .input-group-custom {
            position: relative;
        }

        .input-group-custom i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #a0aec0;
            font-size: 16px;
            transition: color 0.3s;
            z-index: 1;
        }

        .form-control-custom {
            width: 100%;
            padding: 12px 14px 12px 42px;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 14px;
            transition: all 0.3s;
            background: white;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .form-control-custom:focus {
            outline: none;
            border-color: #D4AF37;
            box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.1);
        }

        .form-control-custom:hover {
            border-color: #cbd5e0;
        }

        /* Select Dropdown */
        .select-custom {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%234A0E17'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 14px center;
            background-size: 18px;
            padding-right: 45px;
        }

        /* Password Strength Meter */
        .password-strength {
            margin-top: 8px;
            height: 4px;
            background: #e2e8f0;
            border-radius: 2px;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s, background 0.3s;
            border-radius: 2px;
        }

        .strength-text {
            font-size: 11px;
            margin-top: 5px;
            color: #718096;
        }

        /* Role Cards - Gold Theme */
        .role-cards {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-top: 5px;
        }

        .role-card {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
        }

        .role-card:hover {
            border-color: #D4AF37;
            background: #FDF8F0;
        }

        .role-card.selected {
            border-color: #D4AF37;
            background: linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(212,175,55,0.05) 100%);
        }

        .role-card i {
            font-size: 24px;
            color: #D4AF37;
            margin-bottom: 8px;
            display: block;
        }

        .role-card .role-name {
            font-weight: 600;
            font-size: 13px;
            color: #4A0E17;
        }

        .role-card .role-desc {
            font-size: 10px;
            color: #718096;
            margin-top: 4px;
        }

        /* Register Button - Gold Gradient */
        .btn-register {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #D4AF37, #F5D76E);
            border: none;
            border-radius: 14px;
            color: #4A0E17;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            margin-top: 10px;
        }

        .btn-register::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }

        .btn-register:hover::before {
            left: 100%;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(212, 175, 55, 0.4);
        }

        /* Alert Messages */
        .alert-custom {
            background: #fed7d7;
            border-left: 4px solid #C72A2A;
            color: #c53030;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            animation: shake 0.5s ease-out;
        }

        .alert-success-custom {
            background: #c6f6d5;
            border-left: 4px solid #38a169;
            color: #22543d;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Login Link */
        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .login-link a {
            color: #D4AF37;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .login-link a:hover {
            color: #4A0E17;
        }

        /* Terms */
        .terms {
            text-align: center;
            font-size: 11px;
            color: #a0aec0;
            margin-top: 20px;
        }

        .terms a {
            color: #D4AF37;
            text-decoration: none;
        }

        .terms a:hover {
            color: #4A0E17;
        }

        /* Responsive */
        @media (max-width: 560px) {
            .card-body-custom {
                padding: 25px 20px;
            }
            
            .card-header-custom {
                padding: 25px 20px;
            }
            
            .role-cards {
                grid-template-columns: 1fr;
                gap: 8px;
            }
            
            .role-card {
                padding: 10px;
            }
            
            .form-control-custom {
                padding: 10px 12px 10px 38px;
                font-size: 13px;
            }
        }

        /* Loading State */
        .btn-register.loading {
            pointer-events: none;
            opacity: 0.7;
        }

        .btn-register.loading::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            top: 50%;
            right: 20px;
            margin-top: -9px;
            border: 2px solid #4A0E17;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Tooltip */
        .tooltip-icon {
            cursor: help;
            color: #a0aec0;
            margin-left: 5px;
            font-size: 12px;
        }

        .tooltip-icon:hover {
            color: #D4AF37;
        }
    </style>
</head>
<body>

<div class="shape shape-1"></div>
<div class="shape shape-2"></div>
<div class="shape shape-3"></div>

<div class="register-container">
    <div class="register-card">
        <div class="card-header-custom">
            <div class="logo-icon">
                <i class="fas fa-user-plus"></i>
            </div>
            <h2>Create Account</h2>
            <p>Join ABT Law Firm's client portal</p>
        </div>
        
        <div class="card-body-custom">
            <?php if($success): ?>
                <div class="alert-custom alert-success-custom">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?> Redirecting to login...</span>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="alert-custom">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" id="registerForm">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="username">
                                <i class="fas fa-user"></i> Username
                            </label>
                            <div class="input-group-custom">
                                <i class="fas fa-user"></i>
                                <input type="text" class="form-control-custom" id="username" name="username" 
                                       placeholder="Choose a username" required autocomplete="off">
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i> Email
                            </label>
                            <div class="input-group-custom">
                                <i class="fas fa-envelope"></i>
                                <input type="email" class="form-control-custom" id="email" name="email" 
                                       placeholder="your@email.com" required>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="full_name">
                        <i class="fas fa-id-card"></i> Full Name
                    </label>
                    <div class="input-group-custom">
                        <i class="fas fa-user-tie"></i>
                        <input type="text" class="form-control-custom" id="full_name" name="full_name" 
                               placeholder="Enter your full name" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i> Password
                                <i class="fas fa-question-circle tooltip-icon" title="Minimum 6 characters, at least one letter and number"></i>
                            </label>
                            <div class="input-group-custom">
                                <i class="fas fa-lock"></i>
                                <input type="password" class="form-control-custom" id="password" name="password" 
                                       placeholder="Create a password" required>
                            </div>
                            <div class="password-strength">
                                <div class="strength-bar" id="strengthBar"></div>
                            </div>
                            <div class="strength-text" id="strengthText">Enter a strong password</div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="phone">
                                <i class="fas fa-phone"></i> Phone Number
                            </label>
                            <div class="input-group-custom">
                                <i class="fas fa-phone"></i>
                                <input type="tel" class="form-control-custom" id="phone" name="phone" 
                                       placeholder="+1 234 567 8900">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>
                        <i class="fas fa-user-tag"></i> Register As
                    </label>
                    <input type="hidden" name="role" id="roleInput" value="client">
                    <div class="role-cards">
                        <div class="role-card selected" data-role="client" onclick="selectRole('client')">
                            <i class="fas fa-user"></i>
                            <div class="role-name">Client</div>
                            <div class="role-desc">Access cases & documents</div>
                        </div>
                                           </div>
                </div>
                
                <button type="submit" class="btn-register" id="registerBtn">
                    <i class="fas fa-arrow-right-to-bracket"></i> Create Account
                </button>
            </form>
            
            <div class="login-link">
                <a href="login.php">
                    <i class="fas fa-sign-in-alt"></i> Already have an account? Sign in
                </a>
            </div>
            
            <div class="terms">
                By registering, you agree to our 
                <a href="#">Terms of Service</a> and 
                <a href="#">Privacy Policy</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Role selection
    function selectRole(role) {
        document.querySelectorAll('.role-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.querySelector(`.role-card[data-role="${role}"]`).classList.add('selected');
        document.getElementById('roleInput').value = role;
    }
    
    // Password strength meter
    const passwordInput = document.getElementById('password');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        let strength = 0;
        
        if (password.length >= 6) strength++;
        if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;
        
        const percentage = (strength / 4) * 100;
        strengthBar.style.width = percentage + '%';
        
        if (percentage <= 25) {
            strengthBar.style.background = '#e53e3e';
            strengthText.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Weak password';
            strengthText.style.color = '#e53e3e';
        } else if (percentage <= 50) {
            strengthBar.style.background = '#ed8936';
            strengthText.innerHTML = '<i class="fas fa-chart-line"></i> Fair password';
            strengthText.style.color = '#ed8936';
        } else if (percentage <= 75) {
            strengthBar.style.background = '#ecc94b';
            strengthText.innerHTML = '<i class="fas fa-smile"></i> Good password';
            strengthText.style.color = '#ecc94b';
        } else {
            strengthBar.style.background = '#38a169';
            strengthText.innerHTML = '<i class="fas fa-check-circle"></i> Strong password';
            strengthText.style.color = '#38a169';
        }
        
        if (password.length === 0) {
            strengthBar.style.width = '0%';
            strengthText.innerHTML = 'Enter a strong password';
            strengthText.style.color = '#718096';
        }
    });
    
    // Form validation before submit
    document.getElementById('registerForm').addEventListener('submit', function(e) {
        const password = document.getElementById('password').value;
        
        if (password.length < 6) {
            e.preventDefault();
            showError('Password must be at least 6 characters long!');
            return false;
        }
        
        const btn = document.getElementById('registerBtn');
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
    });
    
    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert-custom';
        errorDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i><span>' + message + '</span>';
        const form = document.getElementById('registerForm');
        form.insertBefore(errorDiv, form.firstChild);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 3000);
    }
    
    // Username availability check (optional)
    let usernameTimeout;
    document.getElementById('username').addEventListener('input', function() {
        clearTimeout(usernameTimeout);
        const username = this.value;
        if (username.length >= 3) {
            usernameTimeout = setTimeout(() => {
                // You can implement AJAX check here
                console.log('Check username:', username);
            }, 500);
        }
    });
    
    // Email validation
    document.getElementById('email').addEventListener('blur', function() {
        const email = this.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email && !emailRegex.test(email)) {
            this.style.borderColor = '#C72A2A';
            this.style.boxShadow = '0 0 0 4px rgba(199, 42, 42, 0.1)';
        } else {
            this.style.borderColor = '#e2e8f0';
            this.style.boxShadow = 'none';
        }
    });
    
    // Phone number formatting
    document.getElementById('phone').addEventListener('input', function(e) {
        let phone = this.value.replace(/\D/g, '');
        if (phone.length > 0) {
            if (phone.length <= 3) {
                phone = phone;
            } else if (phone.length <= 6) {
                phone = phone.slice(0, 3) + '-' + phone.slice(3);
            } else {
                phone = phone.slice(0, 3) + '-' + phone.slice(3, 6) + '-' + phone.slice(6, 10);
            }
            this.value = phone;
        }
    });
    
    // Add ripple effect on role cards
    document.querySelectorAll('.role-card').forEach(card => {
        card.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            ripple.classList.add('ripple');
            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 500);
        });
    });
</script>

<style>
    /* Ripple effect for role cards */
    .role-card {
        position: relative;
        overflow: hidden;
    }
    
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(212, 175, 55, 0.3);
        transform: scale(0);
        animation: ripple 0.5s linear;
        pointer-events: none;
    }
    
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    /* Smooth transitions */
    .form-control-custom, .btn-register, .role-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    /* Focus visible for accessibility */
    .form-control-custom:focus-visible {
        outline: 2px solid #D4AF37;
        outline-offset: 2px;
    }
</style>
</body>
</html>